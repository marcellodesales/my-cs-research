var
	showNumbers = false, 		
	backColor = "#F2F3F4",		
	normalColor = "#2F2F8F",	
	currentColor = "#4B528B",	
	titleColor = "#2B2B8B",		
	mLevel = 1,					
	textSizes = new Array(1, 0.7, 0.6, 0.8, 0.7),			
	fontTitle = "Helvetica,Arial", 
	fontLines = "Helvetica,Arial"; 