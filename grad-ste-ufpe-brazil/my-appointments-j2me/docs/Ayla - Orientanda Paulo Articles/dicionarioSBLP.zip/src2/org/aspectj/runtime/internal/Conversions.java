/* -*- Mode: Java; tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 4 -*-
 *
 * This file is part of the compiler and core tools for the AspectJ(tm)
 * programming language; see http://aspectj.org
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.1 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * either http://www.mozilla.org/MPL/ or http://aspectj.org/MPL/.
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is AspectJ.
 *
 * The Initial Developer of the Original Code is Xerox Corporation. Portions
 * created by Xerox Corporation are Copyright (C) 1999-2002 Xerox Corporation.
 * All Rights Reserved.
 *
 * Contributor(s):
 */

package org.aspectj.runtime.internal;

public final class Conversions {
	// Can't make instances of me
	private Conversions() {}

	public static int intValue(Object o) {
		if (o == null) {
			return 0;
		} else if (o instanceof Integer) {
			return ((Integer)o).intValue();
		} else if (o instanceof Byte){
 			return ((Byte)o).byteValue();
		} else if (o instanceof Short){
 			return ((Short)o).shortValue();
		} else if (o instanceof Long){
 			return (int) ((Long) o).longValue();
		}else {
			throw new ClassCastException(o.getClass().getName() +
										 " can not be converted to int");
		}
	}
	public static long longValue(Object o) {
		if (o == null) {
			return 0;
		} else if (o instanceof Integer) {
			return ((Integer)o).intValue();
		} else if (o instanceof Byte){
 			return ((Byte)o).byteValue();
		} else if (o instanceof Short){
 			return ((Short)o).shortValue();
		} else if (o instanceof Long){
 			return ((Long) o).longValue();
		} else {
			throw new ClassCastException(o.getClass().getName() +
										 " can not be converted to long");
		}
	}
//	public static float floatValue(Object o) {
//		if (o == null) {
//			return 0;
//		} else if (o instanceof Number) {
//			return ((Number)o).floatValue();
//		} else {
//			throw new ClassCastException(o.getClass().getName() +
//										 " can not be converted to float");
//		}
//	}
//	public static double doubleValue(Object o) {
//		if (o == null) {
//			return 0;
//		} else if (o instanceof Number) {
//			return ((Number)o).doubleValue();
//		} else {
//			throw new ClassCastException(o.getClass().getName() +
//										 " can not be converted to double");
//		}
//	}
	public static byte byteValue(Object o) {
		if (o == null) {
			return 0;
		} else if (o instanceof Integer) {
			return (byte)((Integer)o).intValue();
		} else if (o instanceof Byte){
 			return ((Byte)o).byteValue();
		} else if (o instanceof Short){
 			return (byte)((Short)o).shortValue();
		} else if (o instanceof Long){
 			return (byte)((Long) o).longValue();		
		} else {
			throw new ClassCastException(o.getClass().getName() +
										 " can not be converted to byte");
		}
	}
	public static short shortValue(Object o) {
		if (o == null) {
			return 0;
		} else if (o instanceof Integer) {
			return (short)((Integer)o).intValue();
		} else if (o instanceof Byte){
 			return ((Byte)o).byteValue();
		} else if (o instanceof Short){
 			return ((Short)o).shortValue();
		} else if (o instanceof Long){
 			return (short)((Long) o).longValue();
		} else {
			throw new ClassCastException(o.getClass().getName() +
										 " can not be converted to short");
		}
	}
	public static char charValue(Object o) {
		if (o == null) {
			return 0;
		} else if (o instanceof Character) {
			return ((Character)o).charValue();
		} else {
			throw new ClassCastException(o.getClass().getName() +
										 " can not be converted to char");
		}
	}
	public static boolean booleanValue(Object o) {
		if (o == null) {
			return false;
		} else if (o instanceof Boolean) {
			return ((Boolean)o).booleanValue();
		} else {
			throw new ClassCastException(o.getClass().getName() +
										 " can not be converted to boolean");
		}
	}
	
	/** 
	 * identity function for now.  This is not typed to "void" because we happen
	 * to know that in Java, any void context (i.e., {@link ExprStmt})
	 *  can also handle a return value.
	 */
	public static Object voidValue(Object o) {
		if (o == null) {
			return o;
		} else {
			// !!! this may be an error in the future
			return o;
		}
	}
}
