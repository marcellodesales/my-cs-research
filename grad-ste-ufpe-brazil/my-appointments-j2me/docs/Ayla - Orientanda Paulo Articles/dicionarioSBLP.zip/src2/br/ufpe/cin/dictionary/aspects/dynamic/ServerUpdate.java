package br.ufpe.cin.dictionary.aspects.dynamic;

import br.ufpe.cin.dictionary.*;
import br.ufpe.cin.dictionary.aspects.xml.XMLExtractor;

import java.io.DataInputStream;
import java.io.InputStreamReader;

/**
 * Class that looks for updates on the server.
 */
public class ServerUpdate implements UpdateObject{


	private ServerConnector connector = new ServerConnector();

    /**
     * Object used to extract application objects from XML files.
     */	
    private XMLExtractor xmlExtractor = new XMLExtractor();
    /**
     * Constructor.
     */
    public ServerUpdate() {
    }
    /**
     * Gets the new source and destination languages of the conversion.
     */
    public InputSearchData getInputSearchData(){
        return (InputSearchData) this.extractObjectFromXML(ServerConnector.LANGUAGE_URL, XMLExtractor.INPUT_SEARCH_DATA);
    }

    /**
     * Gets the search mechanism to be used
     * @return the EngineObject to be used on the search
     * according to the server.
     */
    public EngineObject getSearchMechanism(){
        return (EngineObject)this.extractObjectFromXML(ServerConnector.SEARCH_MECHANISM_URL, XMLExtractor.SEARCH_MECHANISM);
    }

    /**
     * Gets an enumeration of DictionaryEntries obtained by the server
     * @return an enumeration of DictionaryEntries obtained by the server
     */
    public DictionaryEntriesEnumeration getDictionaryEntries(){
        return (DictionaryEntriesEnumeration)this.extractObjectFromXML(ServerConnector.SERVER_ENTRIES_URL, XMLExtractor.DICTIONARY_ENTRIES);
    }

    /**
     * This method should see in a servlet or jsp page if the main menu should
     * be changed.
     * @return true if it should be changed, and false, otherwise.
     */
    public boolean changeMainMenu(){
        Object result = (this.extractObjectFromXML(ServerConnector.UPDATE_MENU_URL,XMLExtractor.BOOLEAN_ANSWER));
        if (result!=null){
            System.out.println("Result:"+ ((Boolean) result).booleanValue());
            return ((Boolean) result).booleanValue();
        } else {
        	System.out.println("Do not change main menu");
            return false;
        }
    }


    /**
     * Extracts a general object from an XML returned by a server page.
     * @param url The servlet or JSP url
     * @param objectType Indicates the kind of object to be returned
     * @return an object extracted from the XML
     */
    private Object extractObjectFromXML(String url, byte objectType){
        DataInputStream dis = connector.getServerDataInputStream(url);
        if (dis!=null){
            InputStreamReader isr = new InputStreamReader(dis);
            return this.xmlExtractor.extractObject(isr, objectType);
        } else {
            return null;
        }
    }
	

}

