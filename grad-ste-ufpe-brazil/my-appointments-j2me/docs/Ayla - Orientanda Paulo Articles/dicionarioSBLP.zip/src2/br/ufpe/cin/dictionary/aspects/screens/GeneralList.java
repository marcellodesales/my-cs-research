package br.ufpe.cin.dictionary.aspects.screens;


import br.ufpe.cin.dictionary.*;
import javax.microedition.lcdui.List;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Command;
/**
 * Class used to represent a List of the Dictionary application.
 */
public class GeneralList extends List implements CommandListener{

    public static final byte SOURCE_LANGUAGE_SELECTION      = 1;
    public static final byte DESTINATION_LANGUAGE_SELECTION = 2;
    public static final byte SEARCH_MECHANISM_SELECTION     = 3;
	/**
	 * The list options.
	 */
    private String [] options;
    /**
     * The code that represents the functionality represented by this
     * list options.
     */
    private byte functionalityCode;
	/**
	 * The controller class.
	 */
    DictionaryController controller;
    
    /**
     * Constructor.
     */
    public GeneralList(DictionaryController controller, String title, int listType, String [] options, byte functionalityCode) {
        super(title,listType);
        this.controller = controller;
        this.options = options;
        this.functionalityCode = functionalityCode;
        this.addCommand(DictionaryConstants.BACK_CMD);
        this.addCommand(DictionaryConstants.SELECT_CMD);
        this.setCommandListener(this);
        for (int k=0 ; k<options.length;k++){
            this.append(DictionaryConstants.getStringValue(options[k]),null);
        }
    }
    /**
     * Performs the actions ordered by Main menu screen.
     */
    public void commandAction(Command c, Displayable d){
        if (c==DictionaryConstants.SELECT_CMD){
            int index = ((List)d).getSelectedIndex();
            switch (functionalityCode){
                case SOURCE_LANGUAGE_SELECTION:
                    controller.getInputData().setSourceLanguage(options[index]);
                    break;
                case DESTINATION_LANGUAGE_SELECTION:
                    controller.getInputData().setDestinationLanguage(options[index]);
                    break;
                case SEARCH_MECHANISM_SELECTION:
                    EngineObject eo=null;
                    switch(index){
                        case 0: //Server
                            eo = new ServerSearcherEngineObject();
                            break;
                        case 1: //RMS
                            eo = new LocalPersistenceEngineObject();
                            break;
                        case 2: //Memory
                            eo = new VolatileEngineObject();
                            break;
                    }
                    controller.getEngine().setEngineObject(eo);
            }
        }
        DictionaryController.getInstance().showScreen(DictionaryController.MAIN_MENU_SCREEN);
    }

}