package br.ufpe.cin.dictionary.aspects.screens;

import br.ufpe.cin.dictionary.*;
import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.CommandListener;
import java.util.TimerTask;
/**
 * Colored main menu.
 */
public class AnimatedMenu extends Canvas implements CommandListener{
    /**
     * It represents the selected option of the menu.
     */
    private int selectedIndex;
    /**
     * Number of items on this menu.
     */
    private int numItems =0;
    /**
     * Default constructor.
     */
    public AnimatedMenu() {
        //this.animeTimer = new Timer();
        this.addCommand(DictionaryConstants.BACK_CMD);
        this.addCommand(DictionaryConstants.SELECT_CMD);
        this.setCommandListener(this);
        this.numItems = 2;
    }
    /**
     * Tells the way this screen must be drawn.
     * @param g The Graphics context.
     */
    public void paint(Graphics g){
        g.setColor(0xFFFFFF);
        g.fillRect(0,0,this.getWidth(),this.getHeight());
        g.setColor(0xFF0000);
        g.setFont(Font.getFont(Font.FACE_PROPORTIONAL,Font.STYLE_BOLD, Font.SIZE_MEDIUM));
        g.drawString(DictionaryConstants.APP_TITLE,this.getWidth()/2,0,Graphics.TOP|Graphics.HCENTER);
        int start = g.getFont().getHeight();
        g.setColor(0x000000);
        g.setFont(Font.getFont(Font.FACE_MONOSPACE, Font.STYLE_PLAIN, Font.SIZE_SMALL));
        g.drawString(DictionaryConstants.QUERY,10, start+4, Graphics.TOP|Graphics.LEFT);
        g.drawString(DictionaryConstants.INSTRUCTIONS,10, start+8+g.getFont().getHeight(), Graphics.TOP|Graphics.LEFT);
        g.setColor(0x0000FF);
        if (this.selectedIndex==0){
            g.drawRect(2, start+2, this.getWidth()-4, g.getFont().getHeight()+4);
        } else if (this.selectedIndex==1){
            g.drawRect(2, start+6+g.getFont().getHeight(), this.getWidth()-4, g.getFont().getHeight()+4);
        }
    }
    /**
     * Controlls the action associated with a key pressing.
     * @param keyCode The code represents the key that was pressed.
     */
    public void keyPressed(int keyCode){
        if (this.getGameAction(keyCode)==Canvas.DOWN){
            if (selectedIndex==(this.numItems-1)){
                this.selectedIndex = 0;
            } else{
                selectedIndex++;
            }
            this.repaint();
        } else if(this.getGameAction(keyCode)==Canvas.UP){
            if (selectedIndex==0){
                this.selectedIndex = this.numItems-1;
            } else{
                selectedIndex--;
            }
            this.repaint();
        }
    }
    /**
     * Performs the actions ordered by this screen.
     * @param c The pressed command
     * @param d The displayable from where the command was fired.
     */
    public void commandAction(Command c, Displayable d){
        if (c==DictionaryConstants.SELECT_CMD){
          if (this.selectedIndex==0){//Query option
            DictionaryController.getInstance().showScreen(DictionaryController.DICTIONARY_SCREEN);
          } else if (this.selectedIndex==1){ //Instructions option
            DictionaryController.getInstance().showScreen(DictionaryController.INSTRUCTIONS_SCREEN);
          }
        } else if (c==DictionaryConstants.BACK_CMD){
            DictionaryController.getInstance().showScreen(DictionaryController.PRESENTATION_SCREEN);
        }
    }
    /**
     * Class to be used to animate this menu.
     */
    class AnimeMenu extends TimerTask{
//TBD
        public void run(){
        }

    }
}