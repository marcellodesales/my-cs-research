package br.ufpe.cin.dictionary.aspects.util;

import br.ufpe.cin.dictionary.*;
/**
 * This aspect is used to capture some metrics.
 */
public aspect MeasuresAspect {

    /**
     * Temporary variable to provide the calculation of the amount of time
     * spent on a certain operation.
     */
    long storedTime=0;
    
    /**
     * Gets the start of the execution of the search(String, String, String)
     * method on a DictionaryEngine object.
     */
    pointcut searching(DictionaryEngine de):
        target(de) &&
        (execution(public DictionaryEntriesEnumeration search(String, String, String, boolean))
        || execution(public DictionaryEntriesEnumeration search(String, String, boolean)));
    /**
     * The default EngineObject of DictionaryEngine is VolatileEngineObject.
     */
    before(DictionaryEngine de) : searching(de){
        this.storedTime = System.currentTimeMillis();
    }
    /**
     * The amount of time spent on the search is displayed.
     */
    after(DictionaryEngine de) returning: searching(de){
        System.out.println("==>The search took "+(System.currentTimeMillis()-storedTime)+ " milliseconds");
    }
    
    pointcut showingScreen(): execution (public void showScreen(byte)) ;
    before(): showingScreen(){
    	System.out.println("A screen will be shown");
    }
}
