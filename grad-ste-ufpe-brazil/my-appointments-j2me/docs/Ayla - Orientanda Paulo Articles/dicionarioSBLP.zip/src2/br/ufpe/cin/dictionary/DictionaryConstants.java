package br.ufpe.cin.dictionary;

import javax.microedition.lcdui.Command;
import java.util.Hashtable;
/**
 * This class keeps the constants used in many places of the application.
 *
 */
public class DictionaryConstants {
    //String constants
    public static final String START             = "START";
    public static final String EXIT              = "EXIT";
    public static final String SELECT            = "SELECT";
    public static final String BACK              = "BACK";
    public static final String SEARCH            = "SEARCH";
    public static final String APP_TITLE         = "Dictionary";
    public static final String ENTER_WORD        = "Enter word:";
    public static final String QUERY             = "Query";
    public static final String INSTRUCTIONS      = "Instructions";
    public static final String LAN_PORTUGUESE    = "Portuguese";
    public static final String LAN_ENGLISH       = "English";
    public static final String LAN_SPANISH       = "Spanish";
    public static final String LAN_FRENCH        = "French";
    public static final String ALL_LANGUAGES     = "All";
    public static final String NO_RESULTS        = "No results found.";
    public static final String INSTRUCTIONS_MSG  = "To use your dictionary, you"
        + "simply have to chose 'Query' menu option on the main menu, "
        + "enter the word to be queried and press the SEARCH soft key";

    //String values associated with each constant
    public static Hashtable STRING_VALUES = new Hashtable();
    static{
        STRING_VALUES.put(START,  "START");
        STRING_VALUES.put(EXIT,   "EXIT");
        STRING_VALUES.put(SELECT, "SELECT");
        STRING_VALUES.put(BACK,   "BACK");
        STRING_VALUES.put(SEARCH, "SEARCH");
        STRING_VALUES.put(APP_TITLE,  "Dictionary");
        STRING_VALUES.put(ENTER_WORD,  "Enter word:");
        STRING_VALUES.put(QUERY,   "Query");
        STRING_VALUES.put(INSTRUCTIONS, "Instructions");
        STRING_VALUES.put(LAN_ENGLISH,   "English");
        STRING_VALUES.put(LAN_FRENCH, "French");
        STRING_VALUES.put(LAN_SPANISH, "Spanish");
        STRING_VALUES.put(ALL_LANGUAGES, "All");
        STRING_VALUES.put(LAN_PORTUGUESE,  "Portuguese");
        STRING_VALUES.put(NO_RESULTS,  "No results found.");
        STRING_VALUES.put(INSTRUCTIONS_MSG, "To use your dictionary, you"
        + "simply have to chose 'Query' menu option on the main menu, "
        + "enter the word to be queried and press the SEARCH soft key");
    }

    //Commands used by the application
    public static final Command SEARCH_CMD       = new Command(DictionaryConstants.getStringValue(SEARCH), Command.SCREEN, 1);
    public static final Command START_CMD        = new Command(DictionaryConstants.getStringValue(START), Command.SCREEN, 1);
    public static final Command BACK_CMD         = new Command(DictionaryConstants.getStringValue(BACK), Command.BACK, 1);
    public static final Command EXIT_CMD         = new Command(DictionaryConstants.getStringValue(EXIT), Command.EXIT, 1);
    public static final Command SELECT_CMD       = new Command(DictionaryConstants.getStringValue(SELECT), Command.SCREEN, 1);
    public static final Command EMPTY_CMD        = new Command("", Command.SCREEN, 1);

    /**
     * Gets the string value of a word represented by'key'
     * @param key The constant that represents a word
     * @return The value for a constant in a certain language.
     */
    public static String getStringValue(Object key){
        return (String) STRING_VALUES.get(key);
    }
    /**
     * Adds a new string value to represent a string constant.
     * @param key The string constant that represents a string.
     * @param value The value to be associated with a certain constant.
     */
    public static void addStringValue(Object key, Object value){
        STRING_VALUES.put(key,value);
    }
}