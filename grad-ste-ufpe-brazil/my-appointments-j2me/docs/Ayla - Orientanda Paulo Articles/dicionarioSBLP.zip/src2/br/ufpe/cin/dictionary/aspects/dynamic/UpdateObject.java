package br.ufpe.cin.dictionary.aspects.dynamic;

import br.ufpe.cin.dictionary.DictionaryEntriesEnumeration;
import br.ufpe.cin.dictionary.EngineObject;
import br.ufpe.cin.dictionary.InputSearchData;

/**
 * Interface representing an object that provides data for updates.
 */
public interface UpdateObject {

    /**
     * Gets the new source and destination languages of the conversion.
     */
    public InputSearchData getInputSearchData();

    /**
     * Gets the search mechanism to be used
     * @return the EngineObject to be used on the search
     * according to the UpdateObject being used.
     */
    public EngineObject getSearchMechanism();

    /**
     * Gets an enumeration of DictionaryEntries obtained by UpdateObject
     * @return an enumeration of DictionaryEntries obtained by the UpdateObject
     */
    public DictionaryEntriesEnumeration getDictionaryEntries();
    /**
     * This method should see in an UpdateObject if the main manu should change.
     * @return true if it should be changed, and false, otherwise.
     */
    public boolean changeMainMenu();    

}
