package br.ufpe.cin.dictionary;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import javax.microedition.rms.RecordStore;
import java.util.Vector;
/**
 * Class responsible for the persistence of Dictionary Entries on the RMS.
 */
public class DictionaryRMSPersistence {

    /**
     * The default dictionary entries in case there's nothing stored
     * on the RMS.
     */
    DictionaryEntry [] defaultEntries = {
        new DictionaryEntry(DictionaryConstants.LAN_ENGLISH,
            DictionaryConstants.LAN_PORTUGUESE,
            "ball", "bola"),
        new DictionaryEntry(DictionaryConstants.LAN_ENGLISH,
            DictionaryConstants.LAN_PORTUGUESE,
            "house", "casa"),
        new DictionaryEntry(DictionaryConstants.LAN_ENGLISH,
            DictionaryConstants.LAN_PORTUGUESE,
            "dog", "cachorro"),
        new DictionaryEntry(DictionaryConstants.LAN_ENGLISH,
            DictionaryConstants.LAN_SPANISH,
            "dog", "perro") ,
        new DictionaryEntry(DictionaryConstants.LAN_ENGLISH,
            DictionaryConstants.LAN_SPANISH,
            "house", "casa")
    };

    /**
     * The stored entries.
     */
    private String [] persistentEntries;

    /**
     * Used for identifying the record of stored value.
     */
    private int [] persistentIDs;

    /**
     * A object to save the record.
     */
    private RecordStore recordStore = null;

    /**
     * The default name of the file.
     */
    private static final String DICTIONARY_FILE = "persistentEntries";

    /**
     * Creates a new instance of this class.
     * @throws Exception
     */
    public DictionaryRMSPersistence() throws Exception{
        // create/open record store
        recordStore = RecordStore.openRecordStore(this.DICTIONARY_FILE, true);
        // loads the stored entries
        load();
    }

    /**
     * Loads the values from the RMS.
     * @throws Exception
     */
    public void load() throws Exception {

        ByteArrayOutputStream baos = null;
        DataOutputStream      das  = null;
        ByteArrayInputStream  bais = null;
        DataInputStream       dis  = null;
        byte[]                data = null;

        if(recordStore == null) {
            return;
        }
        int numEntries = 0;
        try {
            if(recordStore.getNumRecords() == 0) {    // no entries stored
                numEntries = this.defaultEntries.length;
                this.persistentEntries = new String [numEntries];
                this.persistentIDs = new int [numEntries];
                baos           = new ByteArrayOutputStream();
                das            = new DataOutputStream(baos);

                try {
                    for (int k=0; k<numEntries;k++){
                        das.writeUTF(this.defaultEntries[k].getEntryValue());
                        das.writeUTF(this.defaultEntries[k].getSourceLanguage());
                        das.writeUTF(this.defaultEntries[k].getDestinationLanguage());
                        das.writeUTF(this.defaultEntries[k].getOutputValue());
                        byte[] b = baos.toByteArray();
                        persistentIDs[k] = recordStore.addRecord(b, 0, b.length);
                        persistentEntries[k] = this.defaultEntries[k].getEntryValue();
                        baos.reset();
                    System.out.println(">>Entry["+k+"]"+persistentEntries[k]+"/"+persistentIDs[k]);
                    }
                } catch(IOException ioe) {
                    System.out.println("Error saving RMS file");
                }

            } else {               // there is a record
                numEntries = recordStore.getNumRecords();
                this.persistentEntries = new String [numEntries];
                this.persistentIDs = new int [numEntries];
                for (int k=0; k<numEntries; k++){
                    this.persistentIDs[k] = k+1;
                    data = recordStore.getRecord(persistentIDs[k]);
                    if(data != null) {
                        bais           = new ByteArrayInputStream(data);
                        dis            = new DataInputStream(bais);
                        persistentEntries[k] = dis.readUTF();
                    } else {
                        persistentEntries[k] = "null value";
                    }
                    System.out.println("Entry["+k+"]"+persistentEntries[k]+"/"+persistentIDs[k]);
                }
            }// else
        } finally {
            if(das != null) {
                das.close();
            }

            if(baos != null) {
                baos.close();
            }

            if(dis != null) {
                dis.close();
            }

            if(bais != null) {
                bais.close();
            }

            baos = null;
            das  = null;
            dis  = null;
            bais = null;
        }
    }

    /**
     * Saves an entry on the RMS.
     *
     * @param dicEntry, a DictionaryEntry to be stored.
     * @throws Exception
     */
     //TO BE DONE LATER
    public void save(DictionaryEntry entry) throws Exception {

        ByteArrayOutputStream baos = null;
        DataOutputStream      das  = null;

        if(recordStore == null) {
            return;
        }

        try {
            baos = new ByteArrayOutputStream();
            das  = new DataOutputStream(baos);
//            das.writeLong(persistentLong);
//            byte[] b = baos.toByteArray();
//            recordStore.setRecord(persistentLongID, b, 0, b.length);
        } finally {
            if(das != null) {
                das.close();
            }

            if(baos != null) {
                baos.close();
            }

            baos = null;
            das  = null;
        }
    }

    /**
     * Obtains the DictionaryEntries for a certain entry.
     *
     * @return An array containing all the Dictionary Entries for a certain word..
     */
    public DictionaryEntriesEnumeration getPersistentEntries(String word) throws Exception{
        int numEntries = this.persistentEntries.length;
        Vector v = new Vector();
        for (int k=0; k< numEntries; k++){
            if (this.persistentEntries[k].toLowerCase().equals(word.toLowerCase())){
                v.addElement(getDictionaryEntryOnRecord(this.persistentIDs[k]));
            }
        }
        if (v.size()==0){
            return null;
        } else {
            return new DictionaryEntriesEnumeration(v.elements());
        }
    }
    /**
     * Gets the DictionaryEntry object stored on the record whose
     * id is  recordID
     * @param recordID The id of the record to be loaded.
     */
    private DictionaryEntry getDictionaryEntryOnRecord(int recordID) throws Exception{
        byte[]                data = null;
        ByteArrayInputStream  bais = null;
        DataInputStream       dis  = null;
        DictionaryEntry entry = new DictionaryEntry();
        try{
            data = recordStore.getRecord(recordID);
            if(data != null) {
                bais           = new ByteArrayInputStream(data);
                dis            = new DataInputStream(bais);
                entry.setEntryValue(dis.readUTF());
                entry.setSourceLanguage(dis.readUTF());
                entry.setDestinationLanguage(dis.readUTF());
                entry.setOutputValue(dis.readUTF());
            }
        } finally{
            if(dis != null) {
                dis.close();
            }
            if(bais != null) {
                bais.close();
            }
            dis  = null;
            bais = null;
        }
        return entry;
    }
    /**
     * Recovers from corrupted Record Store
     * @param fileName The file's name.
     * @throws Exception When the recordStore can't be deleted.
     */
    public static void resetRecordStore(String fileName) throws Exception {
        RecordStore.deleteRecordStore(fileName);
    }
}