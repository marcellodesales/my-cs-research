package br.ufpe.cin.dictionary.aspects.screens;

import br.ufpe.cin.dictionary.*;
import br.ufpe.cin.dictionary.aspects.screens.*;
import javax.microedition.lcdui.*;
import br.ufpe.cin.dictionary.aspects.dynamic.*;

/**
 * Represents some aspects considered on the Dictionary application relative
 * to its screens.
 */
public aspect ScreensAspects {

    /**
     * Constants used to represent each new Screen of the application.
     * They are being introduced on the DictionaryController class.
     */
    public static final byte DictionaryController.REGISTRATION_SCREEN = -3;
    public static final byte DictionaryController.SOURCE_LANGUAGE_SELECTION_SCREEN = -4;
    public static final byte DictionaryController.DESTINATION_LANGUAGE_SELECTION_SCREEN = -5;
    public static final byte DictionaryController.SEARCH_MECHANISM_SCREEN = -6;

    /**
     * Introduction of new constants used on the new screens.
     */
    public static final String DictionaryConstants.SOURCE_LANGUAGE = "Source Language";
    public static final String DictionaryConstants.MECHANISM = "Mechanism";
    public static final String DictionaryConstants.DESTINATION_LANGUAGE = "Destination Language";
    public static final String DictionaryConstants.SERVER = "Server";
    public static final String DictionaryConstants.RMS = "RMS";
    public static final String DictionaryConstants.MEMORY = "Memory";

    static {
        DictionaryConstants.addStringValue(DictionaryConstants.SOURCE_LANGUAGE, "Source Language");
        DictionaryConstants.addStringValue(DictionaryConstants.DESTINATION_LANGUAGE, "Destination Language");
        DictionaryConstants.addStringValue(DictionaryConstants.MECHANISM, "Mechanism");
        DictionaryConstants.addStringValue(DictionaryConstants.SERVER, "Server");
        DictionaryConstants.addStringValue(DictionaryConstants.RMS, "RMS");
        DictionaryConstants.addStringValue(DictionaryConstants.MEMORY, "Memory");
    }


    /**
     * Object used to provide updates on the application.
     */
    private UpdateObject uo = new SimpleUpdateObject();

    /**
     *
     * Reference to the single DictionaryController instance of the
     * application.
     */
    private DictionaryController controller = null;

    /**
     * Gets the point where the presentation screen is drawn.
     */
    pointcut changingPresentation(Graphics g, PresentationScreen p):
        args(g) && execution(public void paint(Graphics)) && target(p);
    /**
     * Shows a message before presentation painting.
     */
    before(Graphics g, PresentationScreen p): changingPresentation(g,p){
        System.out.println("Presentation screen will be colorized...");
    }
    /**
     * Instead of painting the presentation screen image,
     * another thing is drawn on this screen.
     */
    void around(Graphics g, PresentationScreen p): changingPresentation(g,p){
        g.setColor(0xFFFFFF);//white color
        g.fillRect(0,0,p.getWidth(), p.getHeight());
        g.setColor(0x00FF00);//green color
        g.setFont(Font.getFont(Font.FACE_PROPORTIONAL,Font.STYLE_BOLD, Font.SIZE_LARGE));
        g.drawString(DictionaryConstants.APP_TITLE,p.getWidth()/2,0,Graphics.TOP|Graphics.HCENTER);
        try{
            Image img = Image.createImage("/dictionary2.png");
            g.drawImage(img,p.getWidth()/2, g.getFont().getHeight()+10, Graphics.HCENTER|Graphics.TOP);
        } catch (Exception ie){
            ie.printStackTrace();
        }
    }

    /**
     * Gets the moment at which the controller screens are being initialized.
     */
    pointcut initializingScreens(DictionaryController con): this(con)
        && execution(public void initializeScreens());
    /**
     * New screens are being added
     */
    after(DictionaryController con): initializingScreens(con){
        this.controller = con;
        //adds a new screen to be shown after presentation
        this.controller.addScreen(new RegistrationScreen(controller),DictionaryController.REGISTRATION_SCREEN);
        //if the main menu should be changed, a MainMenuEnhancer is created.
        if (uo.changeMainMenu()){
            //the codes of the screens to which each menu option will take the user
            byte [] screenCodes = new byte []{
                DictionaryController.DICTIONARY_SCREEN,
                DictionaryController.INSTRUCTIONS_SCREEN,
                DictionaryController.SOURCE_LANGUAGE_SELECTION_SCREEN,
                DictionaryController.DESTINATION_LANGUAGE_SELECTION_SCREEN,
                DictionaryController.SEARCH_MECHANISM_SCREEN
            };
            MainMenuEnhancer mainMenuEnhancer = new MainMenuEnhancer(this.controller, DictionaryController.MAIN_MENU_SCREEN,screenCodes);
            mainMenuEnhancer.enhance();
        }
    }
    /**
     * Gets the execution of the commandAction() method on
     * PresentationScreen.
     */
    pointcut presentationCommandAction(Displayable p, Command c):
        args(c, p) && if (p instanceof PresentationScreen)&& execution(public void commandAction(Command, Displayable));

    /**
     * Instead of going to main menu, another screen is shown when START
     * command is pressed on presentation screen.
     */
    void around(Displayable p, Command c): presentationCommandAction(p,c){
        if (c==DictionaryConstants.START_CMD){
            this.controller.showScreen(DictionaryController.REGISTRATION_SCREEN);
        } else {
            proceed(p,c);
        }
    }
}