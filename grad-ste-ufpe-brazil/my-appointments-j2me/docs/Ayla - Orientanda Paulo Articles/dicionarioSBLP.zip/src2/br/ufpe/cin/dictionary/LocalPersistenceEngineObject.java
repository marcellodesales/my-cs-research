package br.ufpe.cin.dictionary;

import java.util.Vector;
/**
 * This class is EngineObject that searches for a word translation
 * on the RMS.
 */
public class LocalPersistenceEngineObject implements EngineObject {
    /**
     * Object that handles the RMS
     */
    private DictionaryRMSPersistence rmsDic;
    /**
     * Default constructor.
     */
    public LocalPersistenceEngineObject() {
        try {
            this.rmsDic = new DictionaryRMSPersistence();
        } catch (Exception e){
            System.out.println("Error on RMS loading");
        }
    }
    /**
     * Searches a given word translation to a certain language.
     * @param word The word to be searched.
     * @param sourceLanguage The language in which word is written.
     * @param destinationLanguage The language to which word will be translated.
     * @param ordered Boolean indicating if all the entries for word should be
     * returned on a certain order.
     * @return an array containning DictionaryEntry objects.
     */
    public DictionaryEntriesEnumeration search(String word, String sourceLanguage, String destinationLanguage, boolean ordered) {
        return this.generalSearch(word, sourceLanguage, destinationLanguage, ordered);

    }

    /**
     * Searches a given word translation to a certain language.
     * @param word The word to be searched.
     * @param sourceLanguage The language in which word is written.
     * @param destinationLanguage The language to which word will be translated.
     * @return an enumeration containning DictionaryEntry objects.
     * @param ordered Boolean indicating if all the entries for word should be
     * returned on a certain order.
     */
    private DictionaryEntriesEnumeration generalSearch(String word, String sourceLanguage, String destinationLanguage, boolean ordered){
        System.out.println("Searching on RMS");

        //The order is not being considered yet.
        try {
            Vector v = new Vector();
            DictionaryEntriesEnumeration entries = this.rmsDic.getPersistentEntries(word);
            while(entries!=null && entries.hasMoreElements()){
                DictionaryEntry entry = entries.nextEntry();
                if (entry.getEntryValue().toLowerCase().equals(word.toLowerCase())
                    && entry.getSourceLanguage().equals(sourceLanguage)){
                    if (destinationLanguage==null || destinationLanguage.equals(DictionaryConstants.ALL_LANGUAGES)//if destination language is not important
                    || entry.getDestinationLanguage().equals(destinationLanguage)){ //compares destination languages
                        v.addElement(entry);
                    }
                }
            }
            if (v.size()==0){
                return null;
            } else{
                return new DictionaryEntriesEnumeration(v, ordered);
            }
        }catch(Exception e){
            System.out.println("Search on RMS failed");
            return null;
        }
    }
}