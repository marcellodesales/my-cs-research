package br.ufpe.cin.dictionary.aspects.dynamic;

import java.io.DataInputStream;
import java.io.InputStreamReader;

import br.ufpe.cin.dictionary.DictionaryEntriesEnumeration;
import br.ufpe.cin.dictionary.EngineObject;
import br.ufpe.cin.dictionary.InputSearchData;
import br.ufpe.cin.dictionary.aspects.xml.XMLExtractor;
import br.ufpe.cin.dictionary.aspects.xml.XmlRMSHandler;

/**
 * Class that provides some information to be used to update the
 * Dictionary application.
 */
public class RMSUpdate implements UpdateObject{

    /**
     * Object used to extract application objects from XML files.
     */	
    private XMLExtractor xmlExtractor = new XMLExtractor();
    /**
     * Object used to obtain XMLs stored on RMS.
     */
    private XmlRMSHandler xmlRMSHandler = new XmlRMSHandler();

    /**
     * Constructor.
     */
    public RMSUpdate() {
    }
    /**
     * Gets the new source and destination languages of the conversion.
     */
    public InputSearchData getInputSearchData(){
        Object extracted = this.extractObjectFromXML(XmlRMSHandler.INPUT_DATA_XML,XMLExtractor.INPUT_SEARCH_DATA);
        if (extracted!=null){
        	return (InputSearchData) extracted;
        }
        return null;
    }

    /**
     * Gets the search mechanism to be used
     * @return the EngineObject to be used on the search
     * according to the RMS.
     */
    public EngineObject getSearchMechanism(){
        Object extracted = this.extractObjectFromXML(XmlRMSHandler.SEARCH_ENGINE_XML,XMLExtractor.SEARCH_MECHANISM);
        if (extracted!=null){
        	return (EngineObject) extracted;
        }
        return null;
    }
    /**
     * Gets an enumeration of DictionaryEntries obtained by the RMS
     * @return an enumeration of DictionaryEntries obtained by the RMS
     */
    public DictionaryEntriesEnumeration getDictionaryEntries(){
        Object extracted = this.extractObjectFromXML(XmlRMSHandler.DICTIONARY_ENTRIES_XML,XMLExtractor.DICTIONARY_ENTRIES);
        if (extracted!=null){
        	return (DictionaryEntriesEnumeration) extracted;
        }
        return null;
    }
    /**
     * This method should see in an UpdateObject if the main manu should change.
     * @return true if it should be changed, and false, otherwise.
     */
    public boolean changeMainMenu(){
        Object extracted = this.extractObjectFromXML(XmlRMSHandler.CHANGE_MAIN_MENU_XML,XMLExtractor.BOOLEAN_ANSWER);
        if (extracted!=null){
        	return ((Boolean) extracted).booleanValue();
        }
        return false;
    }    

    /**
     * Extracts a general object from an XML returned by an RmsXMLHandler.
     * @param fileName The RMS file name
     * @param objectType Indicates the kind of object to be returned
     * @return an object extracted from the XML
     */
    public Object extractObjectFromXML(String fileName, byte objectType){
        DataInputStream xmlStream = xmlRMSHandler.readXML(fileName);
        Object extractedObject = null;
        if (xmlStream!=null){
            extractedObject = xmlExtractor.extractObject(new InputStreamReader(xmlStream), objectType);
        }
        return extractedObject;

    }
}
