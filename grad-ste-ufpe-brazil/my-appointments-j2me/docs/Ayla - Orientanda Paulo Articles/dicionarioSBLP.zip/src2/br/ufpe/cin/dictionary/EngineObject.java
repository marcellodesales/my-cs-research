package br.ufpe.cin.dictionary;

import java.util.Vector;
/**
 * This interface represents the objects capable of searching
 * DictionaryEntries.
 *
 */
public interface EngineObject {
    /**
     * Searches a given word translation to a certain language.
     * @param word The word to be searched.
     * @param sourceLanguage The language in which word is written.
     * @param destinationLanguage The language to which word will be translated.
     * @param ordered Boolean indicating if all the entries for word should be
     * returned on a certain order.
     * @return an array containning DictionaryEntry objects.
     */
    public DictionaryEntriesEnumeration search(String word, String sourceLanguage,
        String destinationLanguage, boolean ordered);
}