package br.ufpe.cin.dictionary.aspects.xml;

import javax.microedition.rms.RecordStore;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.InputStreamReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.Reader;
/**
 * Handles XML files obtained from the RMS or that should be written there.
 */
public class XmlRMSHandler {
	
    public static final String INPUT_DATA_XML    	= "InputData";
    public static final String SEARCH_ENGINE_XML 	= "Engine";	
    public static final String DICTIONARY_ENTRIES_XML = "Entries";	
    public static final String CHANGE_MAIN_MENU_XML 	= "MenuChange";	    
    public static final String ADAPTIVE_OBJ_CODE_XML  = "AdapCode";	    
        
    private RecordStore recordStore = null;
    
    /**
     * Constructor.
     */
    public XmlRMSHandler() {
    }
	/**
	 * Writes an XML on the RMS.
	 * @param fileName The file name.
	 * @param dis The DataInputStream with the data that should be written.
	 */
    public void writeXML(String fileName, DataInputStream dis){
        ByteArrayOutputStream baos = null;
        DataOutputStream das       = null;

        try{
            recordStore = RecordStore.openRecordStore(fileName, true);
            StringBuffer str = new StringBuffer();
            baos = new ByteArrayOutputStream();
            das       = new DataOutputStream(baos);
            int byteRead = 0;
            while ((byteRead = dis.read())!=-1){
                das.writeByte(byteRead);
            }
            byte [] b = baos.toByteArray();
            baos.reset();
            recordStore.addRecord(b, 0, b.length);
            if (recordStore!=null){
                recordStore.closeRecordStore();
                recordStore = null;
            }
            if (baos!=null){
                baos.close();
            }
            if (das != null){
                das.close();
            }
        } catch (Exception e){
            System.out.println("Exception while writing XML to RMS");
        }
    }
	/**
	 * Reads an XML from the RMS.
	 * @param fileName The RMS file name.
	 */
    public DataInputStream readXML(String fileName){
        try{
            recordStore = RecordStore.openRecordStore(fileName, true);
            if (recordStore.getNumRecords()==0){
                return null;
            } else {
                byte [] recordContents = recordStore.getRecord(1);
                DataInputStream dis = new DataInputStream(new ByteArrayInputStream(recordContents));
                return dis;
            }
        } catch (Exception e){
            System.out.println("Exception while reading XML from RMS");
            return null;
        }
    }

}