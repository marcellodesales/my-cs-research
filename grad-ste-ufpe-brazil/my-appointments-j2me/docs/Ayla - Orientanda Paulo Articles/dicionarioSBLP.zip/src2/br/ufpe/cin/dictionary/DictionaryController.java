package br.ufpe.cin.dictionary;

import javax.microedition.midlet.MIDlet;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Display;
import java.util.Hashtable;


/**
 * The controller claFs of the Dictionary application.
 * It handles the screens used.
 */
public class DictionaryController {
    /**
     * The screens of the dictionary application.
     */
    private Hashtable screens = new Hashtable();
    /**
     * It keeps the necessary information to get a translation
     * of a word.
     */
    private InputSearchData inputData = new InputSearchData();
    /**
     * The MIDlet of the Dictionary application.
     */
    private MIDlet parentMIDlet;
    /**
     * The engine object, which delegates the search of a word
     * to a certain EngineObject.
     */
    private DictionaryEngine engine = new DictionaryEngine();
    /**
     * Keeps the single active instance of the application.
     */
    private static DictionaryController instance;
    /**
     * The bytes used to identify each of the screens of the application.
     */
    public static final byte PRESENTATION_SCREEN = 0;
    public static final byte MAIN_MENU_SCREEN    = 1;
    public static final byte DICTIONARY_SCREEN   = 2;
    public static final byte INSTRUCTIONS_SCREEN = 3;

    /**
     * Constructor.
     * @param parent The MIDlet that owns this controller.
     */
    private DictionaryController(MIDlet parent) {
        this.parentMIDlet = parent;
        this.inputData = new InputSearchData();
    }
    /**
     * Gets an instance of this controller.
     * This method must be called from the MIDlet class
     * @param parent The MIDlet that owns this controller.
     *
     */
    public static DictionaryController getInstance(MIDlet parent){
        if (instance == null){
            return (instance = new DictionaryController(parent));
        } else {
            return instance;
        }
    }
    /**
     * Gets an instance of this controller.
     */
     public static DictionaryController getInstance(){
        return getInstance(null);
    }
    /**
     * Initializes the application screens.
     */
    public void initializeScreens(){
        this.addScreen(new PresentationScreen(this), DictionaryController.PRESENTATION_SCREEN);
        this.addScreen(new MainMenuScreen(this), DictionaryController.MAIN_MENU_SCREEN);
        this.addScreen(new DictionaryScreen(this), DictionaryController.DICTIONARY_SCREEN);
        this.addScreen(new InstructionsScreen(this), DictionaryController.INSTRUCTIONS_SCREEN);
    }
    /**
     * Adds a new screen to the application.
     * @param dis The displayable to be added
     * @param key The number that identifies this displayable.
     */
    public void addScreen(Displayable dis, byte key){
        this.screens.put(new Byte(key), dis);
    }
    /**
     * Gets the screen identified by screenCode.
     * @param screenCode The number that identifies one of the application
     * screens.
     * @return The displayable represented by screenCode.
     */
    public Displayable getScreen(byte screenCode){
        return (Displayable) this.screens.get(new Byte(screenCode));
    }
    /**
     * Shows the screen identified by this code.
     * @param screenCode The number that identifies one of the application
     * screens.
     */
    public void showScreen(byte screenCode){
        Display display = Display.getDisplay(this.parentMIDlet);
        display.setCurrent((Displayable) this.screens.get(new Byte(screenCode)));
    }
    /**
     * Exits the application.
     */
    public void exitApplication(){
      this.parentMIDlet.notifyDestroyed();
    }
    /**
     * Gets the dictionary entries for the word passed as a parameter, according to
     * InputSearchData previous configurations. The word to be translated will
     * be replaced by 'word'.
     * @param word The word to be searched.
     * @return Dictionary Entries for word.
     */
    public DictionaryEntriesEnumeration getEntries(String word){
      this.inputData.setWordToTranslate(word);
      DictionaryEntriesEnumeration result =  this.engine.search(inputData.getWordToTranslate(), inputData.getSourceLanguage(), inputData.getDestinationLanguage(), true);
      System.gc();
      System.out.println("==>Used Memory "+(Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory())+ " from the total amount of: "+Runtime.getRuntime().totalMemory());
      return result;
    }
    /**
     * Gets the InputSearchData object associated with this controller
     * @return the InputSearchData object associated with this controller.
     */
    public InputSearchData getInputData() {
      return inputData;
    }
    /**
     * Gets the DictionaryEngine responsible for the search.
     * @return DictionaryEngine object used by the application.
     */
    public DictionaryEngine getEngine() {
        return engine;
    }
}