package br.ufpe.cin.dictionary.aspects.dynamic;

import br.ufpe.cin.dictionary.DictionaryEntriesEnumeration;
import br.ufpe.cin.dictionary.EngineObject;
import br.ufpe.cin.dictionary.InputSearchData;
import br.ufpe.cin.dictionary.VolatileEngineObject;

/**
 * Object that looks for information to be used for adaptation on this class 
 * fields.
 */
public class SimpleUpdateObject implements UpdateObject {


	private InputSearchData isd;
	private EngineObject eo;
	private DictionaryEntriesEnumeration enum;
	private boolean mainMenuShouldChange;

	/**
	 * Constructor.
	 */
	public SimpleUpdateObject() {
		this.loadProperties();
		
	}
	/**
	 * Loads this class fields which contain the adaptation data.
	 */
	private void loadProperties(){
		this.isd = new InputSearchData();
		this.eo = new VolatileEngineObject();
		this.enum = new DictionaryEntriesEnumeration();
		this.mainMenuShouldChange = true;
	}
    /**
     * Gets the new source and destination languages of the conversion.
     */		
	public InputSearchData getInputSearchData() {
		return null;
	}
    /**
     * Gets the search mechanism to be used
     * @return the EngineObject to be used on the search.
     */

	public EngineObject getSearchMechanism() {
		return null;
	}
    /**
     * Gets a default enumeration of DictionaryEntries.
     * @return an enumeration of DictionaryEntries.
     */
	public DictionaryEntriesEnumeration getDictionaryEntries() {
		return null;
	}
    /**
     * This method should see if the main manu should change.
     * @return true if it should be changed, and false, otherwise.
     */
	public boolean changeMainMenu() {
		return true;
	}

}
