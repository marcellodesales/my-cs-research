package br.ufpe.cin.dictionary;

import java.io.InputStream;
import java.io.IOException;
import javax.microedition.io.Connector;
import javax.microedition.io.HttpConnection;
import java.util.Vector;

/**
 * This class is EngineObject that searches for a word translation
 * on a server.
 */
public class ServerSearcherEngineObject implements EngineObject {
    /**
     * Default constructor.
     */
    public ServerSearcherEngineObject() {
    }
    /**
     * Searches a given word translation to a certain language.
     * @param word The word to be searched.
     * @param sourceLanguage The language in which word is written.
     * @param destinationLanguage The language to which word will be translated.
     * @param ordered Boolean indicating if all the entries for word should be
     * returned on a certain order.
     * @return an enumeration of DictionaryEntry objects.
     */
    public DictionaryEntriesEnumeration search(String word, String sourceLanguage, String destinationLanguage, boolean ordered) {
        Vector translations = this.getTranslations(word, sourceLanguage, destinationLanguage) ;
        if (translations==null){
            return null;
        } else {
            int numTrans = translations.size();
            Vector entries = new Vector();
            for (int k=0; k<numTrans; k++){
                entries.addElement(new DictionaryEntry(sourceLanguage, (String)translations.elementAt(k++), word, (String) translations.elementAt(k)));
            }
            return new DictionaryEntriesEnumeration(entries, ordered);
        }

    }
    /**
     * Gets the translations of a word on a server
     * @param word The word to be searched.
     * @param sourceLanguage The language in which word is written.
     * @param destinationLanguage The language to which word must be translated.
     * @return Vector containing the translations for word.
     */
    private Vector getTranslations(String word, String sourceLanguage, String destinationLanguage) {
        HttpConnection hc = null;
        InputStream in = null;
        String url = "http://localhost:8080/Dictionary/servlet/DictionaryServerSearcher";
        Vector translations = new Vector();
        try {
            url+="?word="+word+"&sourceLanguage="+sourceLanguage+"&destinationLanguage="+destinationLanguage;
            hc = (HttpConnection)Connector.open(url);
            in = hc.openInputStream();

            int contentLength = (int)hc.getLength();
            byte[] raw = new byte[contentLength];
            int length = in.read(raw);

            in.close();
            hc.close();

            // Show the response to the user.
            int start = 0;
            int len = 0;
            for (int k=0; k<length; k++, len++){
                if (raw[k]==':'){
                    translations.addElement(new String(raw,start,len));
                    start = k+1;
                    len = -1;
                }
                if (k==length-1){
                    translations.addElement(new String(raw,start,len+1));
                }
            }
            if (length  ==0){
                return null;
            } else{
                return translations;
            }

        }
        catch (IOException ioe) {
           System.out.println(ioe.toString());
           ioe.printStackTrace();
           return null;
        }
    }

}