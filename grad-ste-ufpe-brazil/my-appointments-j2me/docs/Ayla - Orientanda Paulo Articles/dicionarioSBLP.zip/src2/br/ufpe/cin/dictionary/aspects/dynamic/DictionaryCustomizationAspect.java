package br.ufpe.cin.dictionary.aspects.dynamic;

import br.ufpe.cin.dictionary.*;
import javax.microedition.midlet.MIDlet;;

/**
 * This aspect provides the adaptation behavior for the
 * Dictionary application.
 */
public aspect DictionaryCustomizationAspect extends CustomizationAspect {
    /**
     * The update object.
     */
    private UpdateObject uo = new SimpleUpdateObject();
    
    /**
     * Gets the object from where the updates will be obtained.
     */
    public UpdateObject getUpdateObject(){
        return uo;
    }



    /**
     * Before the MIDlet starts, the application will require from the UpdateObject
     * an InputSearchData object and change the current Dictionary Source
     * and Destination languages.
     * @param midlet The captured MIDlet object.
     */
    protected void doBeforeAdaptations(MIDlet myMidlet){
        System.out.println(">>>>Do before");
    	try {
	        DictionaryMIDlet midlet = (DictionaryMIDlet) myMidlet;
	        System.out.println("Looking for updates of languages and search mechanism...");
	 		InputSearchData data = getUpdateObject().getInputSearchData();
	 		InputSearchData current = midlet.getController().getInputData();
	        if (data!=null){
	            current.setDestinationLanguage(data.getDestinationLanguage());
	            current.setSourceLanguage(data.getSourceLanguage());
	        }	
    	} catch (ClassCastException e){
    		System.out.println("The current midlet is not a DictionaryMIDlet");
    	}
	}

    /**
     * After the MIDlet starts, the EngineObject used to perform the searches
     * will be changed according to the one obtained by the current updateObject.
     * @param midlet The captured MIDlet object.
     */
	protected void doAfterAdaptations(MIDlet myMidlet){
		System.out.println("Will execute do after to "+myMidlet);
		try{
	        System.out.println(">>>>Do after");
	        DictionaryMIDlet midlet = (DictionaryMIDlet) myMidlet;
	        //changes the engine object according to the server
	        EngineObject eo = null;
			eo = getUpdateObject().getSearchMechanism();
	        if (eo!=null){
	        	System.out.println("Engine object changed to "+eo);
	            midlet.getController().getEngine().setEngineObject(eo);
	        }
		} catch (ClassCastException e){
    		System.out.println("The current midlet is not a DictionaryMIDlet");
    	}
	}
	
	/**
	 * Do actions while the method is executing and possibly proceed.
	 * @return true, if proceed should be executed, and false, otherwise.
	 */
	protected boolean doAroundAdaptationAndPossiblyProceed(MIDlet midlet){
	        System.out.println(">>>>Do around");
		return true;
	}
	

}
