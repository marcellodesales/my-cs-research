package br.ufpe.cin.dictionary.aspects.util;

import br.ufpe.cin.dictionary.*;

/**
 * Represents the actions to be executed
 * when an exception of the Dictionary application is handled.
 */
public aspect ExceptionHandlingAspect {
    /**
     * A message is outputed every time an Exception is handled.
     */
    pointcut handlingException(Exception e): handler(Exception) && args(e);
    before(Exception e): handlingException(e){
      System.out.println("Handling general exception :"+e);
    }

}