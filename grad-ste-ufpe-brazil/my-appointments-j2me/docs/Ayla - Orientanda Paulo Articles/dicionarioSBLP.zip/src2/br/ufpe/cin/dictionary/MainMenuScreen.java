package br.ufpe.cin.dictionary;

import javax.microedition.lcdui.List;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Command;

/**
 * This class represents the main menu.
 */
public class MainMenuScreen extends List implements CommandListener {
    DictionaryController controller;
    /**
     * Default constructor
     */
    public MainMenuScreen(DictionaryController controller) {
        super(DictionaryConstants.getStringValue(DictionaryConstants.APP_TITLE), List.IMPLICIT );
        this.controller = controller;
        this.append(DictionaryConstants.getStringValue(DictionaryConstants.QUERY), null);
        this.append(DictionaryConstants.getStringValue(DictionaryConstants.INSTRUCTIONS), null);
        this.addCommand(DictionaryConstants.BACK_CMD);
        this.addCommand(DictionaryConstants.SELECT_CMD);
        this.setCommandListener(this);
    }
    /**
     * Performs the actions ordered by Main menu screen.
     * @param c The command pressed
     * @param d The displayable where the command was pressed.
     */
    public void commandAction(Command c, Displayable d){
        if (c==DictionaryConstants.SELECT_CMD){
          if (this.getSelectedIndex()==0){//Query option
            controller.showScreen(DictionaryController.DICTIONARY_SCREEN);
          } else if (this.getSelectedIndex()==1){ //Instructions option
            controller.showScreen(DictionaryController.INSTRUCTIONS_SCREEN);
          }
        } else if (c==DictionaryConstants.BACK_CMD){
            controller.showScreen(DictionaryController.PRESENTATION_SCREEN);
        }
    }
}