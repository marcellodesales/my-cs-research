package br.ufpe.cin.dictionary;

/**
 * This class represents the entries of the dictionary.
 */
public class DictionaryEntry {
    /**
     * Default constructor.
     */
    public DictionaryEntry() {
    }
    /**
     * Constructor
     * @param sourceLanguage The language in which entryValue is written
     * @param destinationLanguage The language to which entryValue is translated
     * in this entry.
     * @param entryValue The entry word.
     * @param outputValue The translation of entryValue on destinationLanguage.
     */
    public DictionaryEntry(String sourceLanguage, String destinationLanguage,
        String entryValue, String outputValue){
        this.sourceLanguage = sourceLanguage;
        this.destinationLanguage = destinationLanguage ;
        this.entryValue = entryValue;
        this.outputValue = outputValue;
    }
    /**
     * The source language of the translation
     */
    private String sourceLanguage="";
    /**
     * The destination language of the translation.
     */
    private String destinationLanguage="";
    /**
     * The word to be translated.
     */
    private String entryValue="";
    /**
     * The translation of entryValue on destinationLanguage language.
     */
    private String outputValue="";
    /**
     * Gets the source language of the translation.
     * @return the source language of the translation.
     */
    public String getSourceLanguage() {
        return sourceLanguage;
    }
    /**
     * Changes the sourceLanguage of the translation.
     * @param sourceLanguage The new value for the source language.
     */
    public void setSourceLanguage(String sourceLanguage) {
        this.sourceLanguage = sourceLanguage;
    }
    /**
     * Changes the destinationLanguage of the translation.
     * @param destinationLanguage The new value for the destination language.
     */
    public void setDestinationLanguage(String destinationLanguage) {
        this.destinationLanguage = destinationLanguage;
    }
    /**
     * Gets the destination language of the translation.
     * @return the destination language of the translation.
     */
    public String getDestinationLanguage() {
        return destinationLanguage;
    }
    /**
     * Changes the entry value
     * @param entryValue The new entry value
     */
    public void setEntryValue(String entryValue) {
        this.entryValue = entryValue;
    }
    /**
     * Gets the entry value
     * @return the entryValue
     */
    public String getEntryValue() {
        return entryValue;
    }
    /**
     * Changes the output value (translation) of a entry.
     * @param outputValue The new outputValue
     */
    public void setOutputValue(String outputValue) {
        this.outputValue = outputValue;
    }
    /**
     * Gets the outputValue of this entry
     * @return The outputValeu
     */
    public String getOutputValue() {
        return outputValue;
    }
    /**
     * Compares two DictionaryEntries according to the lexicographical
     * order of the destination languages. If they are the same,
     * the output value is analyzed.
     * @param entry The DictionaryEntry to be compared with this.
     * @return the value 0 if the argument entry is equal to this
     * entry; a value less than 0 if this entry is lexicographically
     * less than the entry argument; and a value greater than 0 if
     * this entry is lexicographically greater than the entry argument.
     */
    public int compareTo(DictionaryEntry entry){
        int result = this.destinationLanguage.compareTo(entry.getDestinationLanguage());
        if (result!=0){
            return result;
        } else {
            return this.outputValue.compareTo(entry.getOutputValue());
        }
    }
}