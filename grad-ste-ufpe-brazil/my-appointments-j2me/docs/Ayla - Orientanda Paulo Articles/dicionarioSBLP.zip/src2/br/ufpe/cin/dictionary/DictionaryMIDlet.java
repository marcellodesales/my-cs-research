package br.ufpe.cin.dictionary;

import javax.microedition.midlet.MIDlet;
/**
 * This class represents the midlet itself.
 */
public class DictionaryMIDlet extends MIDlet {
    /**
     * The controller class of the application. It handles the screens
     * of it, among other things.
     */
    DictionaryController dictionaryController;
    /**
     * Constructor
     */
    public DictionaryMIDlet() {
        this.dictionaryController = DictionaryController.getInstance(this);
    }

    /**
     * Creates the Dictionary and shows its presentation screen.
     */
    public void startApp() {
        this.dictionaryController.initializeScreens();
        this.dictionaryController.showScreen(dictionaryController.PRESENTATION_SCREEN);
    }

    /**
     * Pause the application.
     */
    public void pauseApp() {
    }

    /**
     * Destroy must cleanup everything.
     */
    public void destroyApp(boolean unconditional) {
    }
    /**
     * Gets the controller of the application according to the
     * MVC
     */
	public DictionaryController getController(){
		return this.dictionaryController;
	}
}