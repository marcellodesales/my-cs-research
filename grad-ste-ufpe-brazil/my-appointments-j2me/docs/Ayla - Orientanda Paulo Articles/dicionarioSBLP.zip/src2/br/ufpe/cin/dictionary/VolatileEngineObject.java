package br.ufpe.cin.dictionary;

import java.util.Vector;

/**
 * This class is EngineObject that searches for a word translation
 * on the active memory.
 */
public class VolatileEngineObject implements EngineObject {
    DictionaryEntry [] entries = {
        new DictionaryEntry(DictionaryConstants.LAN_ENGLISH,
            DictionaryConstants.LAN_PORTUGUESE,
            "ball", "bola"),
        new DictionaryEntry(DictionaryConstants.LAN_ENGLISH,
            DictionaryConstants.LAN_FRENCH,
            "ball", "ballon"),
        new DictionaryEntry(DictionaryConstants.LAN_ENGLISH,
            DictionaryConstants.LAN_PORTUGUESE,
            "house", "casa"),

        new DictionaryEntry(DictionaryConstants.LAN_ENGLISH,
            DictionaryConstants.LAN_PORTUGUESE,
            "dog", "c�o"),
        new DictionaryEntry(DictionaryConstants.LAN_ENGLISH,
            DictionaryConstants.LAN_FRENCH,
            "dog", "chien"),
        new DictionaryEntry(DictionaryConstants.LAN_ENGLISH,
            DictionaryConstants.LAN_SPANISH,
            "dog", "perro") ,
        new DictionaryEntry(DictionaryConstants.LAN_ENGLISH,
            DictionaryConstants.LAN_PORTUGUESE,
            "dog", "cachorro"),
        new DictionaryEntry(DictionaryConstants.LAN_ENGLISH,
            DictionaryConstants.LAN_SPANISH,
            "house", "casa"),
        new DictionaryEntry(DictionaryConstants.LAN_ENGLISH,
            DictionaryConstants.LAN_FRENCH,
            "house", "maison")
    };
    /**
     * Default constructor.
     */
    public VolatileEngineObject() {
    }
    /**
     * Searches a given word translation to a certain language.
     * @param word The word to be searched.
     * @param sourceLanguage The language in which word is written.
     * @param destinationLanguage The language to which word will be translated.
     * @param ordered Boolean indicating if all the entries for word should be
     * returned on a certain order.
     * @return an enumeration containning DictionaryEntry objects.
     */
    public DictionaryEntriesEnumeration search(String word, String sourceLanguage, String destinationLanguage, boolean ordered) {
        return this.generalSearch(word, sourceLanguage, destinationLanguage, ordered);
    }

    /**
     * Searches a given word translation to a certain language.
     * @param word The word to be searched.
     * @param sourceLanguage The language in which word is written.
     * @param destinationLanguage The language to which word will be translated.
     * @return an enumeration containning DictionaryEntry objects.
     * @param ordered Boolean indicating if all the entries for word should be
     * returned on a certain order.
     */
    private DictionaryEntriesEnumeration generalSearch(String word, String sourceLanguage, String destinationLanguage, boolean ordered){
        System.out.println("Searching on Memory");
        DictionaryEntriesEnumeration result = null;
        Vector temp = new Vector();
        for (int k=0; k< this.entries.length; k++){
            if (this.entries[k].getSourceLanguage()==sourceLanguage  &&
                this.entries[k].getEntryValue().toLowerCase().equals(word.toLowerCase())){
                if (destinationLanguage==null || destinationLanguage.equals("All")
                    || entries[k].getDestinationLanguage().equals(destinationLanguage)){
                    temp.addElement(this.entries[k]);
                }
            }
        }
        if (temp.size()>0){
            result = new DictionaryEntriesEnumeration(temp, ordered);
        }
        return result;
    }
}