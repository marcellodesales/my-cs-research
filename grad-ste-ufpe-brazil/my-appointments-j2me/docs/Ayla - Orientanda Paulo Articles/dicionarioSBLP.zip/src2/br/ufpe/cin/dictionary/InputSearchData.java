package br.ufpe.cin.dictionary;

import javax.microedition.lcdui.Form;

/**
 * The data stored about the kind of search the dictionary will perform.
 */
public class InputSearchData {
    /**
     * Default constructor.
     */
    public InputSearchData() {
       this.sourceLanguage = DictionaryConstants.LAN_ENGLISH;
       this.destinationLanguage = DictionaryConstants.LAN_PORTUGUESE;
       this.wordToTranslate = "";
    }
    /**
     * The source language of the translation.
     */
    private String sourceLanguage;
    /**
     * The destination language of the translation.
     */
    private String destinationLanguage;
    /**
     * The word to be translated.
     */
    private String wordToTranslate;
    /**
     * Gets the source language of the translation.
     * @param return  the source language of the translation.
     */
    public String getSourceLanguage() {
        return sourceLanguage;
    }
    /**
     * Changes the source language of the translation.
     * @param sourceLanguage the source language of the translation.
     */
    public void setSourceLanguage(String sourceLanguage) {
        this.sourceLanguage = sourceLanguage;
    }
    /**
     * Changes the destination language of the translation.
     * @param destinationLanguage the destination language of the translation.
     */
    public void setDestinationLanguage(String destinationLanguage) {
        this.destinationLanguage = destinationLanguage;
    }

    /**
     * Gets the destination language of the translation.
     * @param return  the destination language of the translation.
     */
    public String getDestinationLanguage() {
        return destinationLanguage;
    }
    /**
     * Changes the word to be translated.
     * @param wordToTranslate The new word to be translated.
     */
    public void setWordToTranslate(String wordToTranslate) {
        this.wordToTranslate = wordToTranslate;
    }
    /**
     * Gets the word to be translated.
     * @return the word to be translated.
     */
    public String getWordToTranslate() {
        return wordToTranslate;
    }
}