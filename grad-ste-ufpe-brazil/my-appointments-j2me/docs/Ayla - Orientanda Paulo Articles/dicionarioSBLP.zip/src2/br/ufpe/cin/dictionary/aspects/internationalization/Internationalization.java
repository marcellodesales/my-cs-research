package br.ufpe.cin.dictionary.aspects.internationalization;

import java.util.Hashtable;
import br.ufpe.cin.dictionary.DictionaryConstants;
/**
 * Class responsible for the Internationalization aspect.
 */
public class Internationalization {
    /**
     * The language to be used on the internationalization
     */
    private String language;
    /**
     * The Hash that stores each string constant value on a certain language
     */
    private Hashtable stringValues;
    /**
     * Default Constructor
     */
    public Internationalization() {
        language = DictionaryConstants.LAN_PORTUGUESE;
        stringValues = new Hashtable();
        initializeStringValues();
    }
    /**
     * Changes the language to be used.
     * @param language The language used by this object.
     */
    public void setLanguage(String language){
        this.language= language;
        this.initializeStringValues();
    }
    /**
     * Gets the language to be used.
     * return The code of the language used by this object.
     */
    public String getLanguage(){
        return this.language;
    }
    /**
     * Initializes the string constant values, according to the selected
     * language.
     */
    private void initializeStringValues(){
        if (language == null){
            return;
        } else if(language.equals(DictionaryConstants.LAN_PORTUGUESE)){
            stringValues.put(DictionaryConstants.START,  "INICIAR");
            stringValues.put(DictionaryConstants.EXIT,   "SAIR");
            stringValues.put(DictionaryConstants.SELECT, "SELEC.");
            stringValues.put(DictionaryConstants.BACK,   "VOLTAR");
            stringValues.put(DictionaryConstants.SEARCH, "PESQUISAR");
            stringValues.put(DictionaryConstants.APP_TITLE,  "Dicion�rio");
            stringValues.put(DictionaryConstants.ENTER_WORD,  "Entre uma palavra:");
            stringValues.put(DictionaryConstants.QUERY,   "Pesquise");
            stringValues.put(DictionaryConstants.INSTRUCTIONS, "Instru��es");
            stringValues.put(DictionaryConstants.LAN_ENGLISH,   "Ingl�s");
            stringValues.put(DictionaryConstants.LAN_FRENCH, "Franc�s");
            stringValues.put(DictionaryConstants.LAN_SPANISH, "Espanhol");
            stringValues.put(DictionaryConstants.LAN_PORTUGUESE,  "Portugu�s");
            stringValues.put(DictionaryConstants.ALL_LANGUAGES,  "Todas");
            stringValues.put(DictionaryConstants.NO_RESULTS,  "Nenhum resultado encontrado.");
            stringValues.put(DictionaryConstants.INSTRUCTIONS_MSG, "Para usar o dicion�rio,"
            + "simplesmente selecione 'Pesquise' no menu principal, "
            + "entre a palavra a ser pesquisada e pressione o comando PESQUISAR.");

        }
    }
    /**
     * Adds a new String value to be associated to a code on a certain language.
     * However, this action is only performed if 'language' is the current selected
     * language of this object.
     * @param stringCode The code that represents a certain string
     * @param language The language to which 'value'pertains
     * @param value The representation of a certain String on 'language'
     */
    public void addStringValue(String stringCode, String language, String value){
    	if (language!=null && language.equals(this.language)){
    		stringValues.put(stringCode, value);
    	}
    }
    /**
     * Gets the String value of a constant on a certain language.
     * @param key The constant that represents a string used on the application.
     * @return The string value of the constant on a certain language.
     */
    public String getStringValue(Object key){
        return (String) this.stringValues.get(key);
    }

}