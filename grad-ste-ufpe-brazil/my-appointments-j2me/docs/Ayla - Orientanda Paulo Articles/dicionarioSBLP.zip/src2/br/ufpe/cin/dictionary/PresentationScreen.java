package br.ufpe.cin.dictionary;

import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import java.io.IOException;
/**
 * The main screen of the application.
 */
public class PresentationScreen extends Canvas implements CommandListener{
    DictionaryController controller;
    /**
     * Default Constructor
     */
    public PresentationScreen(DictionaryController controller) {
        this.controller = controller;
        this.addCommand(DictionaryConstants.START_CMD);
        this.addCommand(DictionaryConstants.EXIT_CMD);
        this.setCommandListener(this);
    }
    /**
     * Draws the presentation screen.
     */
    public void paint(Graphics g) {
        g.setColor(0xFFFFFF);//white color
        g.fillRect(0,0,super.getWidth(), super.getHeight());
        try{
            Image img = Image.createImage("/dictionary.png");
            g.drawImage(img,this.getWidth()/2, 5, Graphics.HCENTER|Graphics.TOP);
        } catch (Exception ie){
            ie.printStackTrace();
        }
    }
    /**
     * Performs the actions ordered by Presentation screen.
     * @param c The pressed command
     * @param d  The displayable from where the action was fired.
     */
    public void commandAction(Command c, Displayable d){
        if (c==DictionaryConstants.START_CMD){
            controller.showScreen(DictionaryController.MAIN_MENU_SCREEN);
        } else if (c==DictionaryConstants.EXIT_CMD){
            controller.exitApplication();
        }
    }
}