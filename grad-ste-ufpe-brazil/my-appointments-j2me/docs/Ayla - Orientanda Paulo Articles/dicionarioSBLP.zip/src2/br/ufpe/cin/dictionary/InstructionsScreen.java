package br.ufpe.cin.dictionary;

import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Displayable;

/**
 * This class represents the screen show when the user selects the
 * Instructions option on the application main menu.
 */
public class InstructionsScreen extends Form implements CommandListener{
    DictionaryController controller;
    /**
     * Default Constructor
     */
    public InstructionsScreen(DictionaryController controller) {
        super(DictionaryConstants.getStringValue(DictionaryConstants.INSTRUCTIONS));
        this.controller = controller;
        this.append(DictionaryConstants.INSTRUCTIONS_MSG);
        this.addCommand(DictionaryConstants.EMPTY_CMD);
        this.addCommand(DictionaryConstants.BACK_CMD);
        this.setCommandListener(this);
    }
    /**
     * Executes an action according to the soft key pressed.
     * @param c The chosen command
     * @param d The displayable from where the command was fired.
     */
    public void commandAction( Command c, Displayable d){
        if (c == DictionaryConstants.BACK_CMD){
            controller.showScreen(DictionaryController.MAIN_MENU_SCREEN);
        }
    }
}
