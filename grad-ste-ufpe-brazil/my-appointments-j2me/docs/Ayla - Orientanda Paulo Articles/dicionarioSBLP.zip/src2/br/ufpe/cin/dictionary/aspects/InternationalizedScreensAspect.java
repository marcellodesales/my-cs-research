package br.ufpe.cin.dictionary.aspects;

import br.ufpe.cin.dictionary.aspects.internationalization.Internationalization;
import br.ufpe.cin.dictionary.DictionaryConstants;;
/**
 * Aspect responsible for Internationalization of the strings introduced by
 * ScreensAspects aspect.
 */
public aspect InternationalizedScreensAspect{
	    /**
	     * Captures the execution of the constructor of Internationalization
	     * class.
	     */
	    pointcut internationalizingNewScreensStrings(Internationalization in):
	    	initialization(public Internationalization.new()) && target(in);
		/**
		 * After the constructor is executed, the new strings values used on the
		 * introduced screens will be added to Internationalization class.
		 */
		after(Internationalization in):internationalizingNewScreensStrings(in){			
        	System.out.println("Strings introduced");
        	String language = in.getLanguage();
            in.addStringValue(DictionaryConstants.SOURCE_LANGUAGE, language,"Idioma de origem");
            in.addStringValue(DictionaryConstants.DESTINATION_LANGUAGE, language, "Idioma destino");
            in.addStringValue(DictionaryConstants.MECHANISM, language, "Mecanismo");
            in.addStringValue(DictionaryConstants.SERVER, language,"Servidor");
            in.addStringValue(DictionaryConstants.RMS, language, "RMS");
            in.addStringValue(DictionaryConstants.MEMORY, language, "Mem�ria");
            }
}

