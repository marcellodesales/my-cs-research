package br.ufpe.cin.dictionary.aspects.screens;

import br.ufpe.cin.dictionary.*;
import javax.microedition.lcdui.*;
/**
 * New screen introduced on the application
 */
public class RegistrationScreen extends Form implements CommandListener{
    DictionaryController controller;
    public RegistrationScreen(DictionaryController controller) {
        super("Registration");
        this.controller = controller;
        this.setCommandListener(this);
        this.addCommand(DictionaryConstants.BACK_CMD);
        this.addCommand(DictionaryConstants.START_CMD);
        this.append(new TextField("Login:", "", 20, TextField.ANY));
        this.append(new TextField("Password:", "", 5, TextField.PASSWORD));
    }
    /**
     * Actions associated with each key pressed.
     */
    public void commandAction( Command c, Displayable d){
        if (c == DictionaryConstants.BACK_CMD){
            controller.showScreen(DictionaryController.PRESENTATION_SCREEN);
        } else if (c== DictionaryConstants.START_CMD){
            controller.showScreen(DictionaryController.MAIN_MENU_SCREEN);
        }
    }
}