package br.ufpe.cin.dictionary;

/**
 * This class is responsible for the delegation of the search task to
 * a certain EngineObject.
 */
public class DictionaryEngine {
    /**
     * The EngineObject that will perform the search.
     */
    private EngineObject engine;
    /**
     * Constructor
     */
    public DictionaryEngine() {
        engine = new VolatileEngineObject();
    }
    /**
     * Searches a given word translation to a certain language.
     * @param word The word to be searched.
     * @param sourceLanguage The language in which word is written.
     * @param destinationLanguage The language to which word will be translated.
     * @param ordered Boolean indicating if all the entries for word should be
     * returned on a certain order.
     * @return an enumeration of DictionaryEntry objects.
     */
    public DictionaryEntriesEnumeration search(String word, String sourceLanguage, String destinationLanguage, boolean ordered){
        return this.engine.search(word, sourceLanguage, destinationLanguage, ordered);
    }
    /**
     * Sets the object that will perform the search.
     */
    public void setEngineObject(EngineObject obj){
        this.engine = obj;
    }

}