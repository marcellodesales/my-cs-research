package br.ufpe.cin.dictionary.aspects.dynamic;

import br.ufpe.cin.dictionary.aspects.dynamic.*;
import br.ufpe.cin.dictionary.aspects.xml.*;
import br.ufpe.cin.dictionary.*;
import java.io.DataInputStream;


/**
 * This aspect provides adaptation for the Dictionary application
 * getting data from the server and then storing this data
 * on the RMS.
 */
public aspect DistributedAdaptationWithCache {
	

	private boolean ServerUpdate.useCache = this.shouldUseCache();
	/**
	 * Indicates if the application should use cache.
	 */
	private boolean ServerUpdate.shouldUseCache(){
		ServerConnector sc = new ServerConnector();
		DataInputStream dis = sc.getServerDataInputStream(ServerConnector.USE_CACHE_URL);
		XMLExtractor ext = new XMLExtractor();
		Boolean use = (Boolean) ext.extractObject(dis,XMLExtractor.BOOLEAN_ANSWER);
		if (use == null){
			System.out.println("Could not connect to server! Cache will be used.");
			return true;
		
		}
		else return use.booleanValue();		
	}
	/**
	 * Indicates if the data obtained by the server should be saved.
	 * @return true if the data obtained by the server should be saved and false,
	 * otherwise.
	 */
	public boolean ServerUpdate.useCache(){
		return useCache;
	}
	private ServerConnector connector = new ServerConnector();

    /**
     * Object used to obtain XMLs stored on RMS.
     */
    private XmlRMSHandler xmlRMSHandler = new XmlRMSHandler();
	
	
	/**
	 * Writes an XML obtained by the server from 'url' on the RMS in a file
	 * called 'fileName'.
	 * @param fileName The name of the XML file where the data will be stored.
	 * @param url The url from where the adaptation data was obtained.
	 */
    public void writeServerContentsOnXML(String fileName, String url){
        DataInputStream dis = connector.getServerDataInputStream(url);
        if (dis!=null){
            this.xmlRMSHandler.writeXML(fileName,dis);
        }
    }	
	
	/**
	 * Captures the execution of changeMainMenu method from ServerUpdate when useCache is true.
	 */
	pointcut changingMainMenu(ServerUpdate su): if(su.useCache()) && this(su) && execution(public boolean changeMainMenu());
	
	/**
	 * Writes the XML which contains the adaptation on the RMS.
	 */
	after(ServerUpdate su): changingMainMenu(su){
		this.writeServerContentsOnXML(XmlRMSHandler.CHANGE_MAIN_MENU_XML, ServerConnector.UPDATE_MENU_URL);
	}

	/**
	 * Captures the execution of getInputSearchData method from ServerUpdate when useCache is true.
	 */	
	pointcut gettingInputData(ServerUpdate su): if(su.useCache()) && this(su) && execution(public InputSearchData getInputSearchData());

	/**
	 * Writes the XML which contains the adaptation on the RMS.
	 */	
	after(ServerUpdate su): gettingInputData(su){
		System.out.println("Caching...");
		this.writeServerContentsOnXML(XmlRMSHandler.INPUT_DATA_XML, ServerConnector.LANGUAGE_URL);
	}

	/**
	 * Captures the execution of getSearchMechanism method from ServerUpdate when useCache is true.
	 */
	pointcut gettingSearchMechanism(ServerUpdate su): if(su.useCache()) && this(su) && execution(public EngineObject getSearchMechanism());
	
	/**
	 * Writes the XML which contains the adaptation on the RMS.
	 */	
	after(ServerUpdate su): gettingSearchMechanism(su){
		this.writeServerContentsOnXML(XmlRMSHandler.SEARCH_ENGINE_XML, ServerConnector.SEARCH_MECHANISM_URL);
	}

	/**
	 * Captures the execution of getDictionaryEntries method from ServerUpdate when useCache is true.
	 */	
	pointcut gettingDictionaryEntries(ServerUpdate su): if(su.useCache()) && this(su) && execution(public DictionaryEntriesEnumeration getDictionaryEntries());

	/**
	 * Writes the XML which contains the adaptation on the RMS.
	 */	
	after(ServerUpdate su): gettingDictionaryEntries(su){
		this.writeServerContentsOnXML(XmlRMSHandler.DICTIONARY_ENTRIES_XML, ServerConnector.SERVER_ENTRIES_URL);
	}

}
