package br.ufpe.cin.dictionary;

import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.TextField;


/**
 * The screen where the user enters the word to be searched and where
 * its translation is shown.
 */
public class DictionaryScreen extends Form implements CommandListener{

    DictionaryController controller;
    /**
     * Constructor
     */
    public DictionaryScreen(DictionaryController controller) {
        super(DictionaryConstants.getStringValue(DictionaryConstants.APP_TITLE));
        this.controller = controller;
        this.addCommand(DictionaryConstants.BACK_CMD);
        this.addCommand(DictionaryConstants.SEARCH_CMD);
        this.setCommandListener(this);
        //Dictionary screen components
        this.append(new TextField(DictionaryConstants.getStringValue(DictionaryConstants.ENTER_WORD), "", 20, TextField.ANY));

    }
    /**
     * Rebuilds this screen, adding the obtained result for the entered word.
     * @param entries The dictionary entries to be shown on the screen.
     */
    public void rebuildScreen(DictionaryEntriesEnumeration entries){
        int numItems = this.size();
        for (int k=1; k< numItems; k++){
            this.delete(1);
        }
        int j=0;
        while(entries!=null && entries.hasMoreElements()){
            DictionaryEntry entry= entries.nextEntry();
            this.append((j+1)+". "+ DictionaryConstants.getStringValue(entry.getDestinationLanguage())+ ": "+ entry.getOutputValue()+"\n");
            this.append("");
            j++;
        }
        if (entries == null){
            this.append(DictionaryConstants.getStringValue(DictionaryConstants.NO_RESULTS));
        }
    }
    /**
     * It defines the action associated with each soft key
     * pressed on DictionaryScreen.
     * @param c The command chosen.
     * @param d The displayable shown when the command was pressed.
     */
    public void commandAction( Command c, Displayable d){
        if (c == DictionaryConstants.BACK_CMD){
            controller.showScreen(DictionaryController.MAIN_MENU_SCREEN);
        } else if (c== DictionaryConstants.SEARCH_CMD){
            TextField t = (TextField)this.get(0);
            String word = t.getString();
            DictionaryEntriesEnumeration obtainedEntries = controller.getEntries(word);
            this.rebuildScreen(obtainedEntries);
            controller.showScreen(DictionaryController.DICTIONARY_SCREEN);
        }
    }
}