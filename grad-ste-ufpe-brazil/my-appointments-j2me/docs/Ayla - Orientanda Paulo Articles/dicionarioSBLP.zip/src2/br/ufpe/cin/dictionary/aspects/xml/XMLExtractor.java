package br.ufpe.cin.dictionary.aspects.xml;

import br.ufpe.cin.dictionary.*;
import java.io.InputStreamReader;
import java.io.DataInputStream;
import java.util.Vector;
import org.kxml.parser.XmlParser;
import org.kxml.Attribute;
import org.kxml.Xml;
import org.kxml.parser.ParseEvent;
 
/**
 * Class that extracts application objects from Reader objects containing
 * XML files.
 */
public class XMLExtractor {

    public static final byte INPUT_SEARCH_DATA	= 1;
    public static final byte SEARCH_MECHANISM  	= 2;
    public static final byte DICTIONARY_ENTRIES	= 3;
    public static final byte BOOLEAN_ANSWER    	= 4;
    public static final byte INTEGER_ANSWER    	= 5;

    public static final byte SERVER = 1;
    public static final byte RMS    = 2;
    public static final byte MEMORY = 3;

	/**
	 * Constructor.
	 */
    public XMLExtractor() {
    }
    /**
     * Gets an InputSearchData object extracted from a XML file
     * @param parser The parser associated with the XML file
     * @return an InputSearchData object indicating the source
     * and destination language that should be used, according to XML
     * returned by the server.
     */
    private InputSearchData getSearchData(XmlParser parser){
        try {
            InputSearchData data = new InputSearchData();
            ParseEvent evt = parser.read();
            if (evt.getType()==Xml.START_TAG && evt.getName().equals("InputSearchData")){
                data.setSourceLanguage(evt.getValue("SourceLanguage"));
                data.setDestinationLanguage(evt.getValue("DestinationLanguage"));
            }
            return data;
        } catch (Exception e){
            System.out.println("Error retrieving source and destination" +
                "languages from XML file");
            return null;
        }
    }
    /**
     * Gets the search mechanism code, according to the XML returned by the server.
     * @param parser The parser associated with the XML file
     * @return The mechanism code.
     */
    private EngineObject getSearchMechanism(XmlParser parser){
        try {
            ParseEvent evt = parser.read();
            if (evt.getType()==Xml.START_TAG && evt.getName().equals("SearchAlgorithm")){
                int mechanism = Integer.parseInt(evt.getValue("typeCode"));
                switch (mechanism){
                    case SERVER:
                        return new ServerSearcherEngineObject();
                    case RMS:
                        return new LocalPersistenceEngineObject();
                    case MEMORY:
                        return new VolatileEngineObject();
                }

            }
        } catch (Exception e){
            System.out.println("Error retrieving source and destination" +
                "languages from XML file");
        }
        return null;
    }

    /**
     * Gets the boolean value of the answer attribute from the XML returned by the server.
     * @param parser The parser associated with the XML file
     * @return The Boolean answer.
     */
    private Boolean getBooleanAnswer(XmlParser parser){
        try {
            ParseEvent evt = parser.read();
            String answerValue = evt.getValue("answer");
            if (answerValue.toLowerCase().equals("true")){
                return new Boolean(true);
            }  else {
                return new Boolean(false);
            }
        } catch (Exception e){
            System.out.println("Error retrieving boolean value" +
                "from XML file");
        }
        return null;
    }

    /**
     * Gets the int value of the answer attribute from the XML returned by the server.
     * @param parser The parser associated with the XML file
     * @return The Integer answer.
     */
    private Integer getIntegerAnswer(XmlParser parser){
        try {
            ParseEvent evt = parser.read();
            String answerValue = evt.getValue("answer");
            return new Integer(Integer.parseInt(answerValue));
        } catch (Exception e){
            System.out.println("Error retrieving boolean value" +
                "from XML file");
        }
        return null;
    }


    /**
     * Extracts an enumeration of DictionaryEntries extracted from an XML
     * @param parser The parser that will handle the XML
     * @return an enumeration of DictionaryEntries extracted from an XML
     */
    public DictionaryEntriesEnumeration getServerEntriesEnumeration(XmlParser parser){
        try {
            Vector v = new Vector();
            System.out.println("Parser will read");
            ParseEvent evt = parser.read();
            System.out.println("Parser read");
            if (evt.getName().equals("Entries")){
                DictionaryEntry entry;
                while ((evt = parser.read()).getType()!= Xml.END_DOCUMENT){
                    if (evt.getType() == Xml.START_TAG && evt.getName().equals("DictionaryEntry")){
                        entry = new DictionaryEntry(evt.getAttribute("sourceLanguage").getValue(),
                            evt.getValue("destinationLanguage"),
                            evt.getValue("entryValue"),
                            evt.getValue("outputValue"));
                        v.addElement(entry);
                        evt = parser.read();
                    }
                }
            }
            if (v!=null && v.size()>0){
                return new DictionaryEntriesEnumeration(v,true);
            }
        } catch (Exception e){
            System.out.println("Error retrieving server entries" +
                " from XML file");
        }
        return null;
    }

	/**
	 * Extracts an application object from an InputStreamReader.
	 * @param isr InputStreamReader object.
	 * @param objectType Code indicating which kind of object will be returned.
	 */
    public Object extractObject(InputStreamReader isr, int objectType){
        try {
            XmlParser parser= new XmlParser(isr);
            switch(objectType){
                case INPUT_SEARCH_DATA:
                    return this.getSearchData(parser);
                case SEARCH_MECHANISM:
                    return this.getSearchMechanism(parser);
                case DICTIONARY_ENTRIES:
                    return this.getServerEntriesEnumeration(parser);
                case BOOLEAN_ANSWER:
                    return this.getBooleanAnswer(parser);
                case INTEGER_ANSWER:
                    return this.getIntegerAnswer(parser);                    
                default:
                    return null;
            }
        } catch (Exception e){
            System.out.println("Error while parsing XML");
        }
        return null;
    }

	/**
	 * Extracts an application object from a DataInputStream.
	 * @param isr DataInputStream object.
	 * @param objectType Code indicating which kind of object will be returned.
	 */
    public Object extractObject(DataInputStream dis, int objectType){
        if (dis == null){
        	return null;
        }
        InputStreamReader isr = new InputStreamReader(dis);
		return this.extractObject(isr, objectType);
    }

	
}