package br.ufpe.cin.dictionary.aspects.dynamic;

import br.ufpe.cin.dictionary.aspects.dynamic.*;
import br.ufpe.cin.dictionary.aspects.xml.XMLExtractor;
import java.io.DataInputStream;
import java.io.InputStreamReader;
import br.ufpe.cin.dictionary.*;


/**
 * Configures the object that should be used to provide adaptation for
 * the application.
 */
public aspect DictionaryCustomizationConfigAspect {

    /**
     * Code of the UpdateObject to be used.
     */
    protected UpdateObject updateObject = null;
    
	pointcut otherAdaptationPoints(DictionaryMIDlet midlet): execution (public DictionaryController getController()) && this(midlet);

  	before (DictionaryMIDlet midlet): otherAdaptationPoints(midlet){
  		System.out.println("Eu");
  		DictionaryCustomizationAspect.aspectOf().doBeforeAdaptations(midlet);
  	}
	/**
	 * Constant to represent a ServerUpdate object.
	 */
	public static final byte SERVER = 1;
	/**
	 * Constant to represent a RMSUpdate object.
	 */
	public static final byte RMS    = 2;
	/**
	 * Constant to represent a SimpleUpdate object.
	 */
	public static final byte VOLATILE_OBJECT = 3;
	/**
	 * Makes an UpdateObject according to the code locally stored.
	 */
	protected UpdateObject makeUpdateObject(){	
        if (this.updateObject==null) {
    		int adaptiveObjectCode = this.readAdaptiveObjectCode();
    		switch(adaptiveObjectCode){
    			case SERVER:
    				return new ServerUpdate();
    			case RMS:
    				return new RMSUpdate();
    			default:
    				return new SimpleUpdateObject();
    		}
        } else return this.updateObject;
	}
	/**
	 * Reads the updateObject code from an RMS file.
	 */
	private int readAdaptiveObjectCode(){		
		ServerConnector sc = new ServerConnector();
		DataInputStream dis = sc.getServerDataInputStream(ServerConnector.UPDATE_OBJ_URL);
		XMLExtractor ext = new XMLExtractor();
		Integer code = (Integer) ext.extractObject(dis,XMLExtractor.INTEGER_ANSWER);
		if (code == null){
			System.out.println("Could not connect to server! Volatile object will be used.");
			return this.VOLATILE_OBJECT;
		
		}
		else return code.intValue();
	}
		
    /**
     * Captures the execution of the getUpdateObject() method of AdaptationAspect.
     */
    pointcut gettingAdaptationObject(DictionaryCustomizationAspect adap): target (adap)
        && execution(public UpdateObject getUpdateObject());
    /**
     * Instead of returning a SimpleUpdateObject,
     * the adaptiveObjectCode variable will indicate which
     * UpdateObject will be used.
     */ 
    UpdateObject around(DictionaryCustomizationAspect adap): gettingAdaptationObject(adap){
        return this.makeUpdateObject();
    }
		
}
