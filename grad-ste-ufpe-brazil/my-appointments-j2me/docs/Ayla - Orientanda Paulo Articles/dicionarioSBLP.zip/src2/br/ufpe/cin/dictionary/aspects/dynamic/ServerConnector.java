package br.ufpe.cin.dictionary.aspects.dynamic;

import javax.microedition.io.HttpConnection;
import javax.microedition.io.Connector;
import java.io.DataInputStream;
import java.io.InputStreamReader;
import java.io.IOException;


public class ServerConnector {

    public static final String LANGUAGE_URL
        = "http://localhost:8080/Dictionary/updateLanguages.jsp";
    public static final String SEARCH_MECHANISM_URL
        = "http://localhost:8080/Dictionary/searchMechanism.jsp";
    public static final String SERVER_ENTRIES_URL
        = "http://localhost:8080/Dictionary/serverEntries.jsp";
    public static final String UPDATE_MENU_URL
        = "http://localhost:8080/Dictionary/shouldUpdateMenu.jsp";
    public static final String UPDATE_OBJ_URL
    	= "http://localhost:8080/Dictionary/UpdateObjectCode.jsp";
    public static final String USE_CACHE_URL
    	= "http://localhost:8080/Dictionary/shouldUseCache.jsp";


	/**
	 * Constructor for ServerConector.
	 */
	public ServerConnector() {

	}
	/**
	 * Gets the DataInputStream of a connection to 'url'
	 * @param url The requested url
	 */
    public DataInputStream getServerDataInputStream(String url){
        HttpConnection conn = null;
        DataInputStream is  = null;
        try {
            conn = (HttpConnection) Connector.open(url);
            conn.setRequestProperty("User-Agent",
                                 "Profile/MIDP-1.0, Configuration/CLDC-1.0");
            conn.setRequestProperty("Content-Language",
                                 "en-US");
            conn.setRequestMethod(HttpConnection.POST);
            // Get the response from the JSP page.
            is = conn.openDataInputStream();
            return is;
        } catch (Exception e){
            System.out.println("Exception while connecting to updateLanguages.jsp");
            System.out.println(e);
            return null;
        } finally {
            try {
                if (conn !=  null){
                    conn.close();
                }
            } catch (IOException e){
                System.out.println("IOException captured");
            }
        }
    }

}
