package br.ufpe.cin.dictionary;

import java.util.Enumeration;
import java.util.Vector;
/**
 * This class represents an enumeration of DictionaryEntry objects.
 */
public class DictionaryEntriesEnumeration {

    /**
     * The elements of the enumeration.
     */
    Enumeration contents;
    /**
     * Default constructor.
     */
    public DictionaryEntriesEnumeration() {
    }
    /**
     * Constructor
     * @param entries An Enumeration containing the elements of this Enumeration.
     */
    public DictionaryEntriesEnumeration(Enumeration entries) {
        this.contents = entries;
    }

    /**
     * Constructor
     * @param v Vector containing the dictionary entries
     * @param ordered Boolean indicating if the entries should be ordered.
     */
    public DictionaryEntriesEnumeration(Vector v, boolean ordered){
        if (ordered){
            this.sortEntryVector(v,0,v.size()-1);
        }
        this.contents = v.elements();
    }
    /**
     * Tells if the enumeration has more elements(if the pointer position is valid).
     * @return true if there are more elements to be shown, false, otherwise.
     */
    public boolean hasMoreElements() {
        return (this.contents.hasMoreElements());
    }

    /**
     * Returns the next DictionaryEntry of the enumeration to be listed.
     * @return The next DictionaryEntry of the enumeration to be listed.
     */
    public DictionaryEntry nextEntry(){
        if (this.hasMoreElements()){
            return (DictionaryEntry) contents.nextElement();
        } else {
            return null;
        }
    }
    /**
     * Sorts a Vector of DictionaryEntries using the mergesort algorithm.
     * @param v The Vector to be sorted.
     * @param start The start position of the Vector on which the sort will be done.
     * @param end The end position of the Vector on which the sort will be done.
     */
    protected void sortEntryVector(Vector v, int start, int end){
        if (end-start ==1){
            DictionaryEntry ent1 = (DictionaryEntry) v.elementAt(start);
            DictionaryEntry ent2 = (DictionaryEntry) v.elementAt(end);
            if (ent1.compareTo(ent2) >0 ){
                v.removeElementAt(start);
                v.insertElementAt(ent1, end);
            }
            return;
        } else if (end-start>0) {
            sortEntryVector(v,start,(end-start)/2);
            sortEntryVector(v,(end-start)/2 +1, end);
            mergeVector(v, start, end);
        }
    }
    /**
     * Merges two ordered parts of a Vector.
     * @param start position on which the merge will be done.
     * @param end last position on which the merge will be done.
     */
    private void mergeVector(Vector v, int start, int end){
        int pointer1 = start;
        int pointer2 = (end-start)/2 +1;
        while(pointer2<=end && pointer1!=pointer2){
            DictionaryEntry ent1 = (DictionaryEntry) v.elementAt(pointer1);
            DictionaryEntry ent2 = (DictionaryEntry) v.elementAt(pointer2);
            if (ent1.compareTo(ent2)>=0){
                v.removeElementAt(pointer2);
                v.insertElementAt(ent2,pointer1);
                pointer2++;
                pointer1++;
            } else {
                pointer1++;
            }
        }
    }

}