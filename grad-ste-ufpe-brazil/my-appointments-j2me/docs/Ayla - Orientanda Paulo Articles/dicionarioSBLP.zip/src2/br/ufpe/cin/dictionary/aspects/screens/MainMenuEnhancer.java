package br.ufpe.cin.dictionary.aspects.screens;

import javax.microedition.lcdui.List;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.CommandListener;
import br.ufpe.cin.dictionary.DictionaryController;
import br.ufpe.cin.dictionary.DictionaryConstants;
import br.ufpe.cin.dictionary.aspects.screens.GeneralList;

/**
 * Class that changes a given main menu of Dictionary application.
 */
public class MainMenuEnhancer implements CommandListener{
    /**
     * The controller of the application.
     */
    DictionaryController controller;
    /**
     * The main menu to be changed.
     */
    List mainMenu;
    /**
     * An array containning the codes of the screens to which each option
     * of the menu will take the user, if selected.
     */
    byte [] screenCodes;
    /**
     * Constructor
     * @param controller The Controller class of the Dictionary application.
     * @param screenCode The code that represents the main menu on the application.
     * @param screenCodes The codes that represent the screens each option
     * of the menu will take the user, if selected.
     */
    public MainMenuEnhancer(DictionaryController controller, byte screenCode, byte [] screenCodes) {
        this.controller = controller;
        this.mainMenu = (List)controller.getScreen(screenCode);
        this.mainMenu.setCommandListener(this);
        this.screenCodes = screenCodes;
    }
    /**
     * Enhances the main menu, adding 3 more options:
     * "Source Language", "Destination Language", "Mechanism"
     */
    public void enhance(){
        int index = mainMenu.size();
        mainMenu.append(DictionaryConstants.getStringValue(DictionaryConstants.SOURCE_LANGUAGE),null);
        mainMenu.append(DictionaryConstants.getStringValue(DictionaryConstants.DESTINATION_LANGUAGE),null);
        mainMenu.append(DictionaryConstants.getStringValue(DictionaryConstants.MECHANISM),null);

        //Source Language selection screen
        GeneralList source = new GeneralList(this.controller, DictionaryConstants.getStringValue(DictionaryConstants.SOURCE_LANGUAGE),List.IMPLICIT,
            new String []{
                (DictionaryConstants.LAN_ENGLISH),
                (DictionaryConstants.LAN_FRENCH),
                (DictionaryConstants.LAN_SPANISH),
                (DictionaryConstants.LAN_PORTUGUESE)
            },  GeneralList.SOURCE_LANGUAGE_SELECTION);
        controller.addScreen(source, screenCodes[index++]);//Source Language option

        //Destination Language selection screen
        GeneralList destination = new GeneralList(this.controller, DictionaryConstants.getStringValue(DictionaryConstants.DESTINATION_LANGUAGE),List.IMPLICIT,
            new String []{
                (DictionaryConstants.LAN_ENGLISH),
                (DictionaryConstants.LAN_FRENCH),
                (DictionaryConstants.LAN_SPANISH),
                (DictionaryConstants.LAN_PORTUGUESE),
                (DictionaryConstants.ALL_LANGUAGES)
            },  GeneralList.DESTINATION_LANGUAGE_SELECTION);
        controller.addScreen(destination, screenCodes[index++]);//Destination Language option

        //Mechanism selection screen
        GeneralList mechanism = new GeneralList(this.controller, DictionaryConstants.getStringValue(DictionaryConstants.MECHANISM),List.IMPLICIT,
            new String []{
                (DictionaryConstants.SERVER),
                (DictionaryConstants.RMS),
                (DictionaryConstants.MEMORY)
            },  GeneralList.SEARCH_MECHANISM_SELECTION);
        controller.addScreen(mechanism, screenCodes[index]);//Mechanism option
    }
    /**
     * Decides which action should be executed if a soft key is pressed.
     * @param c The pressed command.
     * @param d The displayable on which the command was pressed.
     */
    public void commandAction(Command c, Displayable d){
        if (c==DictionaryConstants.SELECT_CMD){
            int selectedOption = ((List)d).getSelectedIndex();
            controller.showScreen(this.screenCodes[selectedOption]);
        } else {//BACK command was selected
            controller.showScreen(DictionaryController.REGISTRATION_SCREEN);
        }

    }
}