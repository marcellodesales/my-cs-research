package br.ufpe.cin.dictionary.aspects.dynamic;

import javax.microedition.midlet.MIDlet;

/**
 * Represents some aspects considered on the Dictionary application.
 */
public abstract aspect CustomizationAspect {
 	
	/**
	 * Execute the commands to be executed before MIDlet startup.
	 */
	protected abstract void doBeforeAdaptations(MIDlet midlet);

	/**
	 * Execute the commands to be executed after MIDlet startup.
	 */	
	protected abstract void doAfterAdaptations(MIDlet midlet);
	
	/**
	 * Do actions while the method is executing and possibly proceed.
	 * @return true, if proceed should be executed, and false, otherwise.
	 */
	protected abstract boolean doAroundAdaptationAndPossiblyProceed(MIDlet midlet);

    /**
     * Captures the starting of the application.
     */
    pointcut MIDletStart(MIDlet midlet): execution(void startApp()) && target(midlet);


    before(MIDlet midlet): MIDletStart(midlet){
		doBeforeAdaptations(midlet);
    }

    void around (MIDlet midlet) : MIDletStart(midlet){
    	boolean shouldProceed = doAroundAdaptationAndPossiblyProceed(midlet);
    	if (shouldProceed){
    		proceed(midlet);
    	}
    }

    after(MIDlet midlet): MIDletStart(midlet){
		doAfterAdaptations(midlet);
    }
    

}