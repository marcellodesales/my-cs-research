package br.ufpe.cin.dictionary.aspects.internationalization;

import br.ufpe.cin.dictionary.*;
import br.ufpe.cin.dictionary.aspects.internationalization.Internationalization;
/**
 * Represents the internationalization aspect to be introduced
 * on the Dictionary application.
 */
public aspect InternationalizationAspect {

    /**
     * Class used for internationalization.
     */
    Internationalization internationalization = new Internationalization();
    /**
     * Takes care of the internationalization every time an string value
     * is required.
     */
    pointcut internationalizing(Object key): execution(public static String DictionaryConstants.getStringValue(Object))&& args(key);
    String around(Object key): internationalizing(key){
        return internationalization.getStringValue(key);
    }
}