@interface NSFramework_NanoXML
@end


@implementation NSFramework_NanoXML
@end
