//*****************************************************************
// 
//  Java Source Code for MaxiCode Test Application
//  
//  Copyright, IDAutomation.com, Inc. 2001. All rights reserved.
//  
//  http://www.IDAutomation.com/
//  
//  NOTICE:
//  You may incorporate our Source Code in your application
//  only if you own a valid Java Barcode Package License
//  from IDAutomation.com, Inc. and the copyright notices 
//  are not removed from the source code.
//  
//*****************************************************************

import com.idautomation.maxicode.*;import com.idautomation.maxicode.encoder.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ApplicaitonExample extends Frame {
  MaxiCode rm=new MaxiCode();

  Panel panel1 = new Panel();
  Button btnApply = new Button();
  Button btnExit = new Button();
  Button btnPrint = new Button();
  Button btnSave = new Button();
  Label label1 = new Label();
  Label label2 = new Label();
  Label label3 = new Label();
  Label label4 = new Label();
  Label label5 = new Label();
  TextField txtService = new TextField();
  TextField txtZipCode = new TextField();
  TextField txtCountry = new TextField();
  TextField txtData = new TextField();
  List listMode = new List();
  Label Symbol = new Label();
  Label label6 = new Label();
  TextField txtSymbols = new TextField();
  TextField txtSymbol = new TextField();
  List listResolution = new List();
  Label label7 = new Label();

  public ApplicaitonExample() {
    try {
      jbInit();
      userInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    this.setLayout(null);
    panel1.setLayout(new java.awt.BorderLayout());
    panel1.setBounds(new Rectangle(19, 23, 315, 181));
    btnApply.setLabel("Apply");
    btnApply.setBounds(new Rectangle(14, 364, 75, 27));
    btnApply.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        btnApply_actionPerformed(e);
      }
    });
    btnExit.setLabel("Exit");
    btnExit.setBounds(new Rectangle(263, 364, 75, 27));
    btnExit.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        btnExit_actionPerformed(e);
      }
    });
    btnPrint.setLabel("Print");
    btnPrint.setBounds(new Rectangle(97, 364, 75, 27));
    btnPrint.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        btnPrint_actionPerformed(e);
      }
    });
    btnSave.setLabel("Save");
    btnSave.setBounds(new Rectangle(181, 364, 75, 27));
    btnSave.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        btnSave_actionPerformed(e);
      }
    });
    label1.setText("Mode");
    label1.setBounds(new Rectangle(8, 210, 49, 17));
    label2.setText("Postal Code");
    label2.setBounds(new Rectangle(178, 277, 91, 17));
    label3.setText("Service Class");
    label3.setBounds(new Rectangle(177, 253, 90, 17));
    label4.setText("Country");
    label4.setBounds(new Rectangle(178, 305, 77, 17));
    label5.setText("Data");
    label5.setBounds(new Rectangle(9, 331, 45, 17));
    txtService.setColumns(3);
    txtService.setText("111");
    txtService.setBounds(new Rectangle(272, 252, 79, 21));
    txtZipCode.setText("123450000");
    txtZipCode.setBounds(new Rectangle(272, 277, 79, 21));
    txtCountry.setColumns(3);
    txtCountry.setText("222");
    txtCountry.setBounds(new Rectangle(272, 302, 56, 21));
    txtData.setText("This is a test...");
    txtData.setBounds(new Rectangle(56, 331, 293, 21));
    listMode.setBounds(new Rectangle(57, 210, 45, 39));
    Symbol.setText("Symbol");
    Symbol.setBounds(new Rectangle(9, 282, 57, 17));
    label6.setText("Num. of symbols");
    label6.setBounds(new Rectangle(8, 305, 114, 17));
    txtSymbols.setColumns(1);
    txtSymbols.setText("1");
    txtSymbols.setBounds(new Rectangle(122, 302, 28, 21));
    txtSymbol.setColumns(1);
    txtSymbol.setText("1");
    txtSymbol.setBounds(new Rectangle(71, 279, 28, 21));
    this.setTitle("MaxiCode sample application");
    listResolution.setBounds(new Rectangle(272, 208, 81, 38));
    label7.setText("Printer Resolution (dpi)");
    label7.setBounds(new Rectangle(115, 210, 156, 17));
    this.add(panel1, null);
    this.add(label1, null);
    this.add(btnPrint, null);
    this.add(label6, null);
    this.add(txtData, null);
    this.add(txtSymbol, null);
    this.add(txtSymbols, null);
    this.add(label3, null);
    this.add(label2, null);
    this.add(label4, null);
    this.add(txtCountry, null);
    this.add(txtZipCode, null);
    this.add(txtService, null);
    this.add(btnExit, null);
    this.add(btnSave, null);
    this.add(btnApply, null);
    this.add(listMode, null);
    this.add(listResolution, null);
    this.add(label7, null);
    this.add(Symbol, null);
    this.add(label5, null);
  }

  void userInit() {


  this.setBackground(java.awt.Color.lightGray);

  this.listResolution.add("200");
  this.listResolution.add("300");
  this.listResolution.add("400");
  this.listResolution.add("500");
  this.listResolution.add("600");
  this.listResolution.setMultipleMode(false);
  this.listResolution.select(0);

  this.listMode.add("2");
  this.listMode.add("3");
  this.listMode.add("4");
  this.listMode.add("5");
  this.listMode.add("6");
  this.listMode.setMultipleMode(false);
  this.listMode.select(0);
  this.setSize(365,410);
  this.setLocation(100,100);


  applyData();

    panel1.add(rm);

  }

  
//NOTE: The following applyData() method can be used to test out the symbol structure required by UPS./*			  void applyData() {
	rm.setZipCode("");
    rm.setCountry("");
    rm.setServiceClass("");	rm.setMode(2);
	char GS = (char)29;
	char RS = (char)30;	rm.setData("[)>"+RS+ "01"+GS+ "01336260000"+GS+ "840"+GS+ "002"+GS+ "1Z14647438"+GS+"UPSN"+GS+"410E1W"+GS+"195"+GS+GS+"1/1"+GS+GS+"Y"+GS+"35 Lightner"+GS+"TAMPA"+GS+"FL"+RS);
    try {
    rm.setNumberOfCodes(Integer.parseInt(txtSymbols.getText()));
    rm.setPositionOfCode(Integer.parseInt(txtSymbol.getText()));
    }
    catch (Exception e) {}
    rm.setRedraw(true);
  }
*/  
  // load data into MaxiCode object
  void applyData() {

    rm.setAutoResize(true);
    rm.setMode(this.listMode.getSelectedIndex()+2);
    rm.setResolution((this.listResolution.getSelectedIndex()+2)*100);
    rm.setZipCode(this.txtZipCode.getText());
    rm.setCountry(this.txtCountry.getText());
    rm.setServiceClass(this.txtService.getText());
    rm.setData(this.txtData.getText());
    try {
    rm.setNumberOfCodes(Integer.parseInt(txtSymbols.getText()));
    rm.setPositionOfCode(Integer.parseInt(txtSymbol.getText()));

    }
    catch (Exception e) {}

    rm.setRedraw(true);


  }

  void btnApply_actionPerformed(ActionEvent e) {
    applyData();
    this.paintAll(this.getGraphics());
    this.repaint();
    this.panel1.paintAll(this.panel1.getGraphics());
    this.panel1.setVisible(false);
    this.panel1.setVisible(true);
  }

  void btnPrint_actionPerformed(ActionEvent e) {

       rm.setAutoResize(false);
   // set printer resolution
    java.awt.PageAttributes pa= new PageAttributes();
    pa.setPrinterResolution(rm.getResolution());

    // get printer job
    java.awt.PrintJob pj=Toolkit.getDefaultToolkit().getPrintJob(this,"Maxicode",null,pa);

    rm.offsetX=pj.getPageDimension().width/2;
    rm.offsetY=pj.getPageDimension().height/3;

    //    print barcode
    Graphics g= pj.getGraphics();
    rm.paint(g);

    rm.offsetX=0;
    rm.offsetY=0;

    // end job
    pj.end();

       rm.setAutoResize(true);

  }

  void btnSave_actionPerformed(ActionEvent e) {

      FileDialog f=new FileDialog(this,"Select GIF File",FileDialog.SAVE);

     f.show();

     if (f.getFile()!=null) {
         rm.setRedraw(true);
         rm.setSize(rm.getPreferredSize());
         com.idautomation.maxicode.encoder.barCodeEncoder   be=  new com.idautomation.maxicode.encoder.barCodeEncoder(rm,"GIF",f.getDirectory()+f.getFile());

       }


  }

  void btnExit_actionPerformed(ActionEvent e) {
      System.exit(0);
  }


  public static void main(String[] a) {
    new ApplicaitonExample().show();
  }
}