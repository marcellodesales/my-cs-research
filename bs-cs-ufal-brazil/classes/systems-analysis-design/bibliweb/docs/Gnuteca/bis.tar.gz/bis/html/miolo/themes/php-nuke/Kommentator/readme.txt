Hi,

I started with the Xeron-theme which comes bundled with PHP Nuke 4.2,
and customized it from there. As you'll probably notice, though, espe-
cially in footer.php, I've used a few "hacks" to achieve what I wanted.

If you know better/cleaner ways to do these things, or if you just want
to clean up the code in general, please mail me the result. I'm too
busy to do that myself, currently :-}

Good luck!


Best regards,

Fredrik Romteland
fredrik@romteland.no

editor@kommentator.net
http://www.kommentator.net