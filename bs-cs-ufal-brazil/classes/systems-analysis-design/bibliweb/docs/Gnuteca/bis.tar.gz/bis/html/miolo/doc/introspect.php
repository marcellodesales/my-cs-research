<?php
    
    $file = "../$classe.class";
    
    include $file;    
    
    $methods = get_class_methods($classe);
    
    $fp = fopen($file,'r');

    echo "<dl>\n";
    
    while (! feof($fp))
    {
        $linha = fgets($fp, 1024);       
        
        foreach ($methods as $m)
        {
            if ( eregi("^ *function +(($m).*\$)",$linha,$regs) )
            {
              echo " <dt>$regs[1]</dt>\n";
              echo " <dd>Descri��o do m�todo $regs[2]. </dd>\n";
            }
        }
    }
    echo "</dl>\n";
?>
