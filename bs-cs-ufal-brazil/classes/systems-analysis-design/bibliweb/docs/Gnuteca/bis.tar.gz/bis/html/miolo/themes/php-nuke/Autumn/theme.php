<?php

$thename = "Autumn";
$bgcolor1 = "#CCCC00";
$bgcolor2 = "#FFFF00";
$bgcolor3 = "#ffd700";
$bgcolor4 = "#FFd700";
$textcolor1 = "Black";
$textcolor2 = "Blue";
$hr = 1; # 1 to have horizonal rule in comments instead of table bgcolor

function themefeature($fulltext)
{
?>
<table BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%" >
<tr background="themes/Autumn/wholebg1x1.jpg">
<td WIDTH="100%" background="themes/Autumn/wholebg1x1.jpg">
<div align=center><b><font color="#ffd700">Feature Story</font></b></div>
</td>
</tr>

<tr>
<td ALIGN=middle VALIGN=top WIDTH="100%" BGCOLOR="#ffd700" BACKGROUND="themes/Autumn/bgmenus.jpg">
  <?php echo"$fulltext"; ?>
</td>
</tr>
</table>

<?php
}

function themeindex ($aid, $informant, $time, $title, $counter, $topic, $thetext, $notes, $morelink, $topicname, $topicimage, $topictext) {
	if (!$config_called) {if (!isset($config)) {if (!isset($config)) { include("config.php"); }}}
	if ("$aid" == "$informant") { ?>

<!-- begin titlebar block -->
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr><td>&nbsp;<td><tr>
<tr><td><p>&nbsp</p><td><tr>
  <tr>
    <td BACKGROUND="themes/Autumn/bgmenus.jpg" width="100%"><font color="#000000"><b>
<?php echo"$title"; ?></b>
    </font></td>
  </tr>
</table>
<!-- end titlebarblock -->

<!-- begin story block -->
<table width="100%" border="0" cellspacing="0" cellpadding="5">
  <tr>
    <td><font size="-2">
      <a href="search.php?query=&topic=<?php echo"$topic"; ?>&author="><img src=<?php echo"$tipath$topicimage"; ?> border=0 Alt=<?php echo"\"$topictext\""; ?> align=right hspace=10 vspace=10></a>
	  <font size="-1">
        <?php echo"$thetext"; ?>
      </font>
    </td>
  </tr>
</table>
<!-- end story block -->

<!-- begin story_link block -->
<table width="99%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="100%"><img src="themes/Autumn/pix.gif" width="1" height="8" alt=""></td>
    <td rowspan="3" nowrap><font size="-1"><b>&nbsp;
<!-- end story_link block -->

      <?php echo"$morelink"; ?>

<!-- begin story_trailer block -->
      </b></font>
    </td>
  </tr>
  <tr>
    <td bgcolor="#CCCCCC"><img src="themes/Autumn/pix.gif" width="1" height="1" alt=""></td>
  </tr>
  <tr>
    <td><img src="themes/Autumn/pix.gif"  width="1" height="8" alt=""></td>
  </tr>
</table>
<!-- end story_trailer block -->

<?php	} else {
		if($informant != "") $boxstuff = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
		else $boxstuff = "$anonymous ";
		$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i><br> $notes";
?>


<!-- begin titlebar block --><br><p>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td background="/themes/Autumn//bgmenus.jpg" width="100%"><font size="-1" color="#000000"><b><?php echo"$title"; ?></b><font size="-2" color="#666666"> <?php echo translate("Posted by "); ?><?php formatAidHeader($aid) ?></font>
    </font></td>
  </tr>
</table>
<!-- end titlebarblock -->

<!-- begin story block -->
<table width="100%" border="0" cellspacing="0" cellpadding="5">
  <tr>
    <td><font size="-2">
      <a href="search.php?query=&topic=<?php echo"$topic"; ?>&author="><img src=<?php echo"$tipath$topicimage"; ?> border=0 Alt=<?php echo"\"$topictext\""; ?> align=right hspace=10 vspace=10></a>
      <font size="-1">
        <?php echo"$boxstuff"; ?>
      </font>
    </td>
  </tr>
</table>
<!-- end story block -->

<!-- begin story_link block -->
<table width="99%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="100%"><img src="themes/Autumn/pix.gif" width="1" height="8" alt=""></td>
    <td rowspan="3" nowrap><font size="-1"><b>&nbsp;
<!-- end story_link block -->

      <?php echo"$morelink"; ?>

<!-- begin story_trailer block -->
      </b></font>
    </td>
  </tr>
  <tr>
    <td bgcolor="#CCCCCC"><img src="themes/Autumn/pix.gif" width="1" height="1" alt=""></td>
  </tr>
  <tr>
    <td><img src="themes/Autumn/pix.gif"  width="1" height="8" alt=""></td>
  </tr>
</table>
<!-- end story_trailer block -->

<br>

<?php	}
}

function themearticle ($aid, $informant, $datetime, $title, $thetext, $topic, $topicname, $topicimage, $topictext) {
	if (!$config_called) {if (!isset($config)) {if (!isset($config)) { include("config.php"); }}}
	if ("$aid" == "$informant") {
echo"

<table border=0 cellpadding=0 cellspacing=0 align=center bgcolor=000000 width=100%>
<tr><td>

<table border=0 cellpadding=3 cellspacing=1 width=100%>
<tr><td bgcolor=CCCCCC>
<font face=Arial,Helvetica>
<b>$title</b><br><font face=Arial,Helvetica size=1>".translate("Posted on ")." $datetime
";
global $admin, $sid;
if ($admin) {
    echo "&nbsp;&nbsp; $font2 [ <a href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]";
}

echo "
</td>
</tr>
<tr>
<td bgcolor=ffffff>
<font face=Arial,Helvetica>
<a href=search.php?query=&topic=$topic&author=><img src=$tipath$topicimage border=0 Alt=\"$topictext\" align=right hspace=10 vspace=10></a>
$thetext
</td>
</tr>
</table>
</td>
</tr>
</table><br>
";

	} else {
		if($informant != "") $informant = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
		else $boxstuff = "$anonymous ";
		$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes";
echo "

<table border=0 cellpadding=0 cellspacing=0 align=center bgcolor=000000 width=100%>
<tr><td>
<table border=0 cellpadding=3 cellspacing=1 width=100%>
<tr><td bgcolor=CCCCCC>
<font face=Arial,Helvetica>
<b>$title</b><br><font face=Arial,Helvetica size=2>".translate("Contributed by ")." $informant ".translate("on")." $datetime</font>
";
global $admin, $sid;
if ($admin) {
    echo "&nbsp;&nbsp; $font2 [ <a href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]";
}
echo "
</td>
</tr>
<tr>
<td bgcolor=ffffff>
<a href=search.php?query=&topic=$topic&author=><img src=$tipath$topicimage
border=0 Alt=\"$topictext\" align=right hspace=10 vspace=10></a>
$thetext
</td>
</tr>
</table>
</td>
</tr>
</table><br>
";

	}
}

function themesidebox($title, $content) {
     ?><br>
<table BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%" >
<tr background="themes/Autumn/wholebg1x1.jpg">
<td WIDTH="100%" background="themes/Autumn/wholebg1x1.jpg">
<div align=center><font color="#ffd700">
  <?php echo"$title"; ?>
</font></div>
</td>
</tr>

<tr>
<td ALIGN=middle VALIGN=top WIDTH="100%" BGCOLOR="#ffd700" BACKGROUND="themes/Autumn/bgmenus.jpg">
<div align="left">
  <?php echo"$content"; ?>
</div>
</td>
</tr>
</table>

<?php }
?>
