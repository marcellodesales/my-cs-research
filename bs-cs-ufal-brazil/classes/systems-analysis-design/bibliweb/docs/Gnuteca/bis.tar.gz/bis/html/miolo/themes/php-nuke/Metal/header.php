<?php

echo "<body onload=init() bgcolor=white text=black link=black vlink=black topmargin=5 leftmargin=0 rightmargin=0 marginheight=5>
<br>";
if ($banners) {
    include("banners.php");
}
echo "<br>
<table border=0 cellpadding=4 cellspacing=4 width=100% align=center><tr><td bgcolor=white>
<table border=0 cellpadding=0 cellspacing=0 width=100% background=themes/Metal/steel3.jpg>
<tr><td background=themes/Metal/tbar1.gif height=17><img src=themes/Metal/tleft1.gif width=17 height=17></td>
<td width=99% align=center valign=bottom background=themes/Metal/tbar1.gif><font size=-2>&nbsp;</font></td>
<td><img src=themes/Metal/tright1.gif width=17 height=17></td>
</tr>
<tr bgcolor=ffffff>
	<td background=themes/Metal/leftbar1.gif align=left>&nbsp;</td>
	<td width=100% valign=top background=themes/Metal/steel3.jpg>
<a href=$nuke_url><img src=themes/Metal/logo.jpg Alt=\"".translate("Welcome to")." $sitename\" border=0 align=middle></a>
<font size=+3 color=Navy>
<b>$slogan</b></font>
</td><td background=themes/Metal/rightbar1.gif>&nbsp;</td></tr>
<tr><td valign=top background=themes/Metal/steel3.jpg><IMG src=themes/Metal/bleft1.gif width=17 height=17></td>
<td align=left valign=top background=themes/Metal/bbar1.gif>&nbsp;</td>
<TD valign=top background=themes/Metal/steel3.jpg><IMG src=themes/Metal/bright1.gif width=17 height=17></TD>
</TR></table></td></tr><tr><td valign=top width=100%>
<table border=0 cellspacing=0 cellpadding=4 width=100% bgcolor=white>
<tr><td valign=top width=150 bgcolor=white>";

mainblock();
adminblock();
leftblocks();
headlines();
online();

echo "<img src=images/pix.gif border=0 width=100% height=1></td><td width=100% valign=top>";
?>
