<html>
<head>
 <title> MIOLO - Classe main</title>
 <link rel="stylesheet" href="/miolo/doc/doc.css">
</head>
<body>
<? include '/usr/local/bis/html//miolo/doc/header.inc' ?>
<h2>Classe: BusinessVestibularMain</h2>
<blockquote>
extends <a href="#.class.php">SuperClasse</a>
</blockquote>
<p>TODO: Escrever documenta��o da classe BusinessVestibularMain.</p>
<h3>M�todos:</h3>
<dl>
 <dt><a href="/miolo/doc/modules/vestibular/db/main.BusinessVestibularMain.php">BusinessVestibularMain()</a></dt>
 <dd>Descri��o do m�todo BusinessVestibularMain. </dd>
 <dt><a href="/miolo/doc/modules/vestibular/db/main.InsertInscricao.php">InsertInscricao($data)</a></dt>
 <dd>Descri��o do m�todo InsertInscricao. </dd>
 <dt><a href="/miolo/doc/modules/vestibular/db/main.GetVestibular.php">GetVestibular($id)</a></dt>
 <dd>Descri��o do m�todo GetVestibular. </dd>
 <dt><a href="/miolo/doc/modules/vestibular/db/main.Insert.php">Insert($data)</a></dt>
 <dd>Descri��o do m�todo Insert. </dd>
 <dt><a href="/miolo/doc/modules/vestibular/db/main.Update.php">Update($data)</a></dt>
 <dd>Descri��o do m�todo Update. </dd>
 <dt><a href="/miolo/doc/modules/vestibular/db/main.DeletarVestibular.php">DeletarVestibular($id)</a></dt>
 <dd>Descri��o do m�todo DeletarVestibular. </dd>
 <dt><a href="/miolo/doc/modules/vestibular/db/main.ListaVestibulares.php">ListaVestibulares(&$range)</a></dt>
 <dd>Descri��o do m�todo ListaVestibulares. </dd>
</dl>
<p>&nbsp;</p>
<? include '/usr/local/bis/html//miolo/doc/footer.inc' ?>
</body>
</html>
