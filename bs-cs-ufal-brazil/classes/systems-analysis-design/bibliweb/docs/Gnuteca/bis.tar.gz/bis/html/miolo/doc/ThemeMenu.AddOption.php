<html>
<head>
  <title> MIOLO - AddOption </title>
  <link rel="stylesheet" href="doc.css">
</head>
<body>
<? include 'header.inc' ?>
<h3 align="right">Classe: <a href="ThemeMenu.class.php">ThemeMenu</a></h3>
<h2>AddOption($label,$module='main',$action='',$item='')</h2>
<p>� utilizado para adicionar um item ao menu anteriormente criado com a fun��o
<a href="Theme.CreateMenu.php">CreateMenu</a>.</p>
<h3>Par�metros:</h3>
<dl>
    <dt>$label</dt>
    <dd>Texto para exibi��o do link</dd>
    <dt>$module</dt>
    <dd>Nome do m�dule</dd>
    <dt>$action</dt>
    <dd>Representa uma lista de nomes dos handlers (/module/nome_modulo/handlers/*.inc) 
        separados por ':' (dois pontos). Esses handlers ser�o executados na seq��ncia em 
        que aparecerem na lista, pela fun��o <a href="MIOLO.InvokeHandler.php">InvokeHandler</a></dd>
</dl>
<p>
<pre>
<?php
highlight_string(
'<?php
    ...
    $menu = $theme->CreateMenu("Op��es de Cadastros");     
    $menu->AddOption("Vestibular", $module, "main:novo");
    ...
?>');
?>
</pre>
<? include 'footer.inc' ?>
</body>
</html>
