<?php
global $admin;
echo "<body onload=init() bgcolor=009999 text=000000 link=800080 vlink=800080 topmargin=5 leftmargin=0 rightmargin=0 marginheight=5>
<br>";
if ($banners) {
    include("banners.php");
}
echo "<br>
<table border=0 cellpadding=4 cellspacing=0 width=100% align=center><tr><td>
<table border=0 cellspacing=0 cellpadding=1 width=100% bgcolor=009999><tr><td>
<table border=0 cellspacing=0 cellpadding=3 width=100% bgcolor=009999><tr><td>
<a href=$nuke_url><img src=themes/Barranuke/logo.gif Alt=\"".translate("Welcome to")." $sitename\" border=0></a>
</td><td align=right>
    <form action=search.php method=post><font size=2 color=ffffff>
    ".translate("Search")."
    <input type=text name=query>
    </form>
</tr>
<tr bgcolor=cc0000>
<td colspan=2 bgcolor=cc0000 background=themes/Barranuke/barra.gif>
<font size=3 color=FFFFFF>$slogan
</td>
</tr>
<tr bgcolor=009999>
<td colspan=2 bgcolor=009999>
<font size=3 color=009999>.
</td>
</tr>
</table></td></tr></table></td></tr><tr><td valign=top width=100%>
<table border=0 cellspacing=0 cellpadding=2 width=100%><tr><td valign=top width=150>";

mainblock();
adminblock();
leftblocks();
ephemblock();
headlines();
online();

echo "<img src=images/pix.gif border=0 width=150 height=1></td><td width=100% valign=top>";
?>