<?php
  include_once 'miolo/miolo.php';

  $info = $MIOLO->GetAutoComplete($module,$item,$hint);
?>
<html>
<body>
Module=<?=$module?>; Item=<?=$item?>; Hint=<?=$hint?>; Info=<?=$info?>
<script language="JavaScript">
top.frames['content'].SetResult('<?=$info?>');
</script>
</body>
</html>
