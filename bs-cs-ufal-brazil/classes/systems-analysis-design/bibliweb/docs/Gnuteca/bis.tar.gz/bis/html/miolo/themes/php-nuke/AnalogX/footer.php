<?php
echo "</td></tr></table></td></tr></table>";
footmsg();
?>
