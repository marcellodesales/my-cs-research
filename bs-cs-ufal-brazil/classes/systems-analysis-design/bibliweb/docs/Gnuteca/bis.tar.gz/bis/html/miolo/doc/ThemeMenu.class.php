<html>
<head>
 <title> MIOLO - Classe ThemeMenu</title>
 <link rel="stylesheet" href="doc.css">
</head>
<body>
<? include 'header.inc' ?>
<h2>Classe ThemeMenu</h2>
<p>TODO: Escrever documenta��o da classe ThemeMenu.</p>
<h3>M�todos:</h3>
<dl>
    <dt>ThemeMenu($title,$style='table',$home='main')</dt>
    <dd>Construtor da classe</dd>
    <dt>SetStyle($style)</dt>
    <dd></dd>
    <dt><a href="ThemeMenu.AddOption.php">AddOption($label,$module='main',$action='',$item='')</a></dt>
    <dd></dd>
    <dt>AddUserOption($access,$label,$module='main',$action='',$item='')</dt>
    <dd></dd>
    <dt>AddSeparator($name=null)</dt>
    <dd></dd>
    <dt>AddMenu($label,$options)</dt>
    <dd></dd>
    <dt>Generate()</dt>
    <dd></dd>
</dl>
<p>&nbsp;</p>
<? include 'footer.inc' ?>
</body>
</html>
