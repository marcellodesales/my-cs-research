<? require("common.php"); ?>
<? require("checkFormParameters.php"); ?>

<html>
<head>
<script language="PHP">


CheckFormParameters(array("etiqueta",
                          "subcampo",
                          "descricao"));

if (!$temrepeticoes)
{
  $temrepeticoes = "false";
}

if (!$temsubcampos)
{
  $temsubcampos = "false";
}

if (!$ehobsoleto)
{
  $ehobsoleto = "false";
}

$conn = new Connection;
$conn->Open();

$sql = "insert into gtc_etiqueta" .
       "  (" .
       "    etiqueta," .
       "    subcampo," .
       "    descricao," .
       "    temrepeticoes," .
       "    temsubcampos," .
       "    obsoleto" .
       "  )" .
       "  values" .
       "  (" .
       "    '$etiqueta'," .
       "    '$subcampo'," .
       "    '$descricao'," .
       "    $temrepeticoes," .
       "    $temsubcampos," .
       "    $ehobsoleto" .
       "  )";

$ok = $conn->Execute($sql);  // tire o @ para visualizar mensagens de error do sistema DB

if ($ok)
{
  echo("<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><center><font color=blue size=6> Deu Certo !!! <a href='novaetiqueta.html'>Continua cadastrando</a>...</font></center>");
}
else
{
  echo("<blink><center><font color=red size=6> Deu Erro !!! Cuidado !!!</font></center></blink>");
}
$conn->Close();
</script>
