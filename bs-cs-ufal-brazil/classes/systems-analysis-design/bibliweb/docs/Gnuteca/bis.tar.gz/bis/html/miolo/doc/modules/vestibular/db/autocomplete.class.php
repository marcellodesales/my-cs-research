<html>
<head>
 <title> MIOLO - Classe autocomplete</title>
 <link rel="stylesheet" href="/miolo/doc/doc.css">
</head>
<body>
<? include '/usr/local/bis/html//miolo/doc/header.inc' ?>
<h2>Classe: BusinessVestibularAutoComplete</h2>
<blockquote>
extends <a href="#.class.php">SuperClasse</a>
</blockquote>
<p>TODO: Escrever documenta��o da classe BusinessVestibularAutoComplete.</p>
<h3>M�todos:</h3>
<dl>
 <dt><a href="/miolo/doc/modules/vestibular/db/autocomplete.GetInstituicao.php">GetInstituicao($id)</a></dt>
 <dd>Descri��o do m�todo GetInstituicao. </dd>
</dl>
<p>&nbsp;</p>
<? include '/usr/local/bis/html//miolo/doc/footer.inc' ?>
</body>
</html>
