<html>
<head>
 <title> MIOLO - MIOLO:GetAutoComplete</title>
 <link rel="stylesheet" href="doc.css">
</head>
<body>
<? include 'header.inc' ?>
<h3 align="right">Classe: <a href="MIOLO.class.php">MIOLO</a></h3>
<h2>GetAutoComplete($module,$item,$hint)
</h2>
<p>TODO: Escrever documenta��o da fun��o GetAutoComplete.</p>
<h3>Par�metros:</h3>
<dl>
 <dt>$module</dt>
 <dd>Descri��o par�metro $module.</dd>
 <dt>$item</dt>
 <dd>Descri��o par�metro $item.</dd>
 <dt>$hint</dt>
 <dd>Descri��o par�metro $hint.</dd>
</dl>
<p>&nbsp;</p>
<pre>
<?php
highlight_string(
'<?php
    ...
    $MIOLO->GetAutoComplete($module,$item,$hint); 
    ...
?>');
?>
</pre>
<? include 'footer.inc' ?>
</body>
</html>
