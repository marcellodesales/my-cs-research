<?php

$thename = "Christmas";
$bgcolor1 = "#008040";
$bgcolor2 = "#FF0000";
$bgcolor3 = "#666666";
$textcolor1 = "red";
$textcolor2 = "#green";
$hr = 1; # 1 to have horizonal rule in comments instead of table bgcolor


function themefeature($fulltext)
{
?>
<TABLE border="0" cellspacing="0" cellpadding="0" width=100% bgcolor=white>
<tr align="center" bgcolor="Green">
<td height="20" align=center><font color="#FFFFFF">Feature Story</font></td></tr>
<tr bgcolor="Red">
<td><img src="themes/Christmas/pix.gif" width="1" height="2" alt=""></td>
</tr></TABLE>
<TABLE width=100% border=0 cellspacing=0 cellpadding=1 bgcolor="white">
<tr bgcolor="#666666"><td>
<TABLE width="100%" border=0 cellspacing=0 cellpadding=2 bgcolor="#EFEFEF">
<tr><td valign="middle" align="left"><font size="-1" color="Green">
  <?php echo"$fulltext"; ?>
</font></td></tr></TABLE>
<tr><td>
<img src=themes/Christmas/shadow.gif width=100% height=13 border=0><br><br>
</td></tr>
</TABLE>
<?php
}

function themeindex ($aid, $informant, $time, $title, $counter, $topic, $thetext, $notes, $morelink, $topicname, $topicimage, $topictext) {
	if (!$config_called) {if (!isset($config)) {if (!isset($config)) { include("config.php"); }}}
	if ("$aid" == "$informant") { ?>

<!-- begin titlebar block -->
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr><td><img src="themes/Christmas/snowman2.gif" width="37" height="37" alt="" border="0"><td><tr>
<tr><td><p>&nbsp</p><td><tr>
  <tr>
    <td bgcolor="#FFFFFF" width="100%"><font color="#000000"><b>
<?php echo"$title"; ?></b>
    </font></td>
  </tr>
</table>
<!-- end titlebarblock -->

<!-- begin story block -->
<table width="100%" border="0" cellspacing="0" cellpadding="5">
  <tr>
    <td><font size="-2">
      <a href="search.php?query=&topic=<?php echo"$topic"; ?>&author="><img src=<?php echo"$tipath$topicimage"; ?> border=0 Alt=<?php echo"\"$topictext\""; ?> align=right hspace=10 vspace=10></a>
	  <font size="-1">
        <?php echo"$thetext"; ?>
      </font>
    </td>
  </tr>
</table>
<!-- end story block -->

<!-- begin story_link block -->
<table width="99%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="100%"><img src="themes/Christmas/pix.gif" width="1" height="8" alt=""></td>
    <td rowspan="3" nowrap><font size="-1"><b>&nbsp;
<!-- end story_link block -->

      <?php echo"$morelink"; ?>

<!-- begin story_trailer block -->
      </b></font>
    </td>
  </tr>
  <tr>
    <td bgcolor="#CCCCCC"><img src="themes/Christmas/pix.gif" width="1" height="1" alt=""></td>
  </tr>
  <tr>
    <td><img src="themes/Christmas/pix.gif"  width="1" height="8" alt=""></td>
  </tr>
</table>
<!-- end story_trailer block -->

<?php	} else {
		if($informant != "") $boxstuff = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
		else $boxstuff = "$anonymous ";
		$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i><br> $notes";
?>


<!-- begin titlebar block -->
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td bgcolor="#FFFFFF" width="100%"><font size="-1" color="#000000"><b><?php echo"$title"; ?></b><font size="-2" color="#666666"> <?php echo translate("Posted by "); ?><?php formatAidHeader($aid) ?></font>
    </font></td>
  </tr>
</table>
<!-- end titlebarblock -->

<!-- begin story block -->
<table width="100%" border="0" cellspacing="0" cellpadding="5">
  <tr>
    <td><font size="-2">
      <?php echo"$time $timezone"; ?>&nbsp;&nbsp;&nbsp; [ <a href="search.php?query=&topic=<?php echo"$topic"; ?>&author="><b><?php echo"$topictext"; ?></b></a> ] </font><br>
      <font size="-1">
        <?php echo"$boxstuff"; ?>
      </font>
    </td>
  </tr>
</table>
<!-- end story block -->

<!-- begin story_link block -->
<table width="99%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="100%"><img src="themes/Christmas/pix.gif" width="1" height="8" alt=""></td>
    <td rowspan="3" nowrap><font size="-1"><b>&nbsp;
<!-- end story_link block -->

      <?php echo"$morelink"; ?>

<!-- begin story_trailer block -->
      </b></font>
    </td>
  </tr>
  <tr>
    <td bgcolor="#CCCCCC"><img src="themes/Christmas/pix.gif" width="1" height="1" alt=""></td>
  </tr>
  <tr>
    <td><img src="themes/Christmas/pix.gif"  width="1" height="8" alt=""></td>
  </tr>
</table>
<!-- end story_trailer block -->

<br>

<?php	}
}

function themearticle ($aid, $informant, $datetime, $title, $thetext, $topic, $topicname, $topicimage, $topictext) {
	if (!$config_called) {if (!isset($config)) {if (!isset($config)) { include("config.php"); }}}
	if ("$aid" == "$informant") {
echo"

<table border=0 cellpadding=0 cellspacing=0 align=center bgcolor=000000 width=100%>
<tr><td>

<table border=0 cellpadding=3 cellspacing=1 width=100%>
<tr><td bgcolor=CCCCCC>
<font face=Arial,Helvetica>
<b>$title</b><br><font face=Arial,Helvetica size=1>".translate("Posted on ")." $datetime
";
global $admin, $sid;
if ($admin) {
    echo "&nbsp;&nbsp; $font2 [ <a href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]";
}

echo "
</td>
</tr>
<tr>
<td bgcolor=ffffff>
<font face=Arial,Helvetica>
<a href=search.php?query=&topic=$topic&author=><img src=$tipath$topicimage border=0 Alt=\"$topictext\" align=right hspace=10 vspace=10></a>
$thetext
</td>
</tr>
</table>
</td>
</tr>
</table><br>
";

	} else {
		if($informant != "") $informant = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
		else $boxstuff = "$anonymous ";
		$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes";
echo "

<table border=0 cellpadding=0 cellspacing=0 align=center bgcolor=000000 width=100%>
<tr><td>
<table border=0 cellpadding=3 cellspacing=1 width=100%>
<tr><td bgcolor=CCCCCC>
<font face=Arial,Helvetica>
<b>$title</b><br><font face=Arial,Helvetica size=2>".translate("Contributed by ")." $informant ".translate("on")." $datetime</font>
";
global $admin, $sid;
if ($admin) {
    echo "&nbsp;&nbsp; $font2 [ <a href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]";
}
echo "
</td>
</tr>
<tr>
<td bgcolor=ffffff>
<a href=search.php?query=&topic=$topic&author=><img src=$tipath$topicimage
border=0 Alt=\"$topictext\" align=right hspace=10 vspace=10></a>
$thetext
</td>
</tr>
</table>
</td>
</tr>
</table><br>
";

	}
}

function themesidebox($title, $content) {
     ?><br>
<TABLE width="150" border="0" cellspacing="0" cellpadding="0">
<tr align="center" bgcolor="Green">
<td height="20"><font size="-1" color="#EFEFEF"><b>
  <?php echo"$title"; ?>
</b></font></td></tr>
<tr bgcolor="Red">
<td><img src="themes/Christmas/pix.gif" width="1" height="2" alt=""></td>
</tr></TABLE>
<TABLE width="100$" border=0 cellspacing=0 cellpadding=1 bgcolor="#EFEFEF">
<tr bgcolor="#666666"><td>
<TABLE width="100%" border=0 cellspacing=0 cellpadding=2 bgcolor="#EFEFEF">
<tr><td valign="middle" align="left"><font size="-1" color="#666666">
  <?php echo"$content"; ?>
</font></td></tr>
</TABLE>
<tr><td><img src="themes/Christmas/shadow.gif" width="100%" height="13" alt="" border="0"></td></tr>
</tr></td></table>

<?php }
?>
