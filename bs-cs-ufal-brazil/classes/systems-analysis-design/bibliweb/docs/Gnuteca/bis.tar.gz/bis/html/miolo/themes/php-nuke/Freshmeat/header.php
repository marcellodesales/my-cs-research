<?php

?>
<LINK href="themes/Freshmeat/styles.css" rel=STYLESHEET type=text/css>
<BODY onload=init() aLink=#336699 bgColor=#ffffff leftMargin=0 link=#336699 rightMargin=0 text=#000000 topMargin=0 vLink=#336699 marginheight="0" marginwidth="0">
<br>
<?php
if ($banners) {
    include("banners.php");
}
?>
<br>
<TABLE border=0 cellPadding=0 cellSpacing=0 width="100%">
<TBODY><TR bgColor=#e7e7e7>
<TD><IMG alt="" height=1 src="themes/Freshmeat/images/pixel.gif" width=1></TD>
</TR></TBODY></TABLE>
<TABLE border=0 cellPadding=1 cellSpacing=0 width="100%">
 <TBODY>
  <TR bgColor=#c0c0c0 vAlign=center>
   <TD>&nbsp;&nbsp;&nbsp;
     <?php echo "<a class=osdn>".translate("Welcome to")." $sitename</a>"; ?>
   </TD>
   <TD align=right>
    <?php echo "<a class=osdn>$slogan</a>"; ?>&nbsp;&nbsp;&nbsp; 
   </TD>
  </TR>
 </TBODY>
</TABLE>

<TABLE border=0 cellPadding=0 cellSpacing=0 width="100%">
 <TBODY>
  <TR bgColor=#6f6f6f vAlign=center>
   <TD><IMG alt="" height=1 src="themes/Freshmeat/images/pixel.gif" width=1></TD>
  </TR>
  <TR bgColor=#e7e7e7>
   <TD><IMG alt="" height=1 src="themes/Freshmeat/images/pixel.gif" width=1></TD>
  </TR>
 </TBODY>
</TABLE><BR>
<CENTER>
<TABLE border=0 cellPadding=0 cellSpacing=0>
<TBODY>
<TR>
<TD width=1>
<IMG border=0 height=1 src="themes/Freshmeat/images/pc.gif" width=1><BR></TD></TR></TBODY></TABLE>

<TABLE border=0 cellPadding=2 cellSpacing=0 width="97%">
<TBODY>
<TR>
 <TD align=left vAlign=bottom><a href="<?php echo $nuke_url; ?>"><img src="themes/Freshmeat/images/logo.gif" alt="<?php echo "".translate("Welcome to").""; ?> <?php echo $sitename; ?>" border=0></a></TD>
 <TD align=left rowSpan=2 vAlign=bottom>
 <FORM action=search.php method=post>
  <SMALL>find: <input type=text name=query size=15></SMALL>
 </FORM>
 </TD>
<TD align=right vAlign=bottom>
<TABLE border=0 cellPadding=1 cellSpacing=0 width="100%">
<TBODY>
 <TR>
  <TD align=right nobr><SMALL><B>
   <A href="index.php">Home</A> | <BR>
   <A href="topics.php">Topics</A> | <BR>
   <A href="sections.php">Sections</A> | <BR>
   <A href="links.php">Web Links</A> | </B></SMALL>
  </TD>
  <TD align=right nobr><SMALL><B>
   <A href="friend.php">Recommend Us</A> | <BR>
   <A href="memberslist.php">Members List</A> | <BR>
   <A href="user.php">Your Account</A> | <BR>
   <A href="submit.php">Submit News</A> | </B></SMALL>
  </TD>
  <TD align=right nobr><SMALL><B>
   <A href="submit.php">Submit News</A> | <BR>
   <A href="stats.php">Stats</A> | <BR>
   <A href="stats.php">Top 10</A> | <BR>
   <A href="stats.php">FAQ's</A> | </B></SMALL>
  </TD>
 </TR>
</TBODY>
</TABLE></TD></TR></TBODY></TABLE>

<TABLE border=0 cellPadding=0 cellSpacing=0 width="100%">
 <TBODY>
  <TR bgColor=#000000>
   <TD><IMG alt="" height=2 src="themes/Freshmeat/images/1x1.gif" width=1></TD>
  </TR>
 </TBODY>
</TABLE>

<TABLE bgColor=#bbddff border=0 cellPadding=3 cellSpacing=0 width="100%"> 
<TABLE bgColor=#bbddff border=0 cellPadding=3 cellSpacing=0 width=100%><tr><td valign=top> 


<?php
function themesidebox($title, $content) {
?>
<TABLE border=0 cellspacing=0 cellpadding=0 width=240 bgcolor=000000>
<TR>
<TD>
<TABLE border=0 cellPadding=3 cellSpacing=1 width="100%">
 <TBODY>
  <TR>
    <TD align=middle bgColor=#eeeeee><B>
    <FONT color=#000000><?php echo"$title"; ?></FONT></B></TD></TR>
      <TR>
        <TD bgColor=#ffffff><SMALL>
	  <?php echo"$content"; ?>
	 </SMALL>
	</TD>
      </TR>
  </TBODY>
</TABLE>
</TD>
</TR>
</TABLE><BR> 
<?php
}
?>
