<html>
<head>
 <title> MIOLO - Classe grupo</title>
 <link rel="stylesheet" href="/miolo/doc/doc.css">
</head>
<body>
<? include '/usr/local/bis/html//miolo/doc/header.inc' ?>
<h2>Classe: BusinessGnutecaGrupo</h2>
<blockquote>
extends <a href="#.class.php">SuperClasse</a>
</blockquote>
<p>TODO: Escrever documenta��o da classe BusinessGnutecaGrupo.</p>
<h3>M�todos:</h3>
<dl>
 <dt><a href="/miolo/doc/modules/common/db/grupo.BusinessGnutecaGrupo.php">BusinessGnutecaGrupo()</a></dt>
 <dd>Descri��o do m�todo BusinessGnutecaGrupo. </dd>
 <dt><a href="/miolo/doc/modules/common/db/grupo.GetGrupo.php">GetGrupo($id)</a></dt>
 <dd>Descri��o do m�todo GetGrupo. </dd>
 <dt><a href="/miolo/doc/modules/common/db/grupo.ListaGrupos.php">ListaGrupos()</a></dt>
 <dd>Descri��o do m�todo ListaGrupos. </dd>
 <dt><a href="/miolo/doc/modules/common/db/grupo.AlteraGrupo.php">AlteraGrupo($data)</a></dt>
 <dd>Descri��o do m�todo AlteraGrupo. </dd>
 <dt><a href="/miolo/doc/modules/common/db/grupo.ExcluiGrupo.php">ExcluiGrupo($CodigoDoGrupo)</a></dt>
 <dd>Descri��o do m�todo ExcluiGrupo. </dd>
 <dt><a href="/miolo/doc/modules/common/db/grupo.NovoGrupo.php">NovoGrupo($data)</a></dt>
 <dd>Descri��o do m�todo NovoGrupo. </dd>
</dl>
<p>&nbsp;</p>
<? include '/usr/local/bis/html//miolo/doc/footer.inc' ?>
</body>
</html>
