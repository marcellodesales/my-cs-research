<?php
cookiedecode($user);
$username = $cookie[1];
if ($username == "") {
        $username = "Anonymous";
}
?>
<?php
echo "<body onload=init() topmargin=\"0\" leftmargin=\"0\" marginwidth=\"0\" marginheight=\"0\" bgcolor=\"#FFFFFF\" text=\"#000000\" link=\"#363636\" vlink=\"#363636\" alink=\"#d5ae83\">
      <br>";
if ($banners) {
    include("banners.php");
}
echo "<br>
<TABLE cellpadding=0 cellspacing=0 width=\"100%\" border=\"0\" align=\"center\" bgcolor=\"#ffffff\">
<tr>
<td bgcolor=FFFFFF align=center>
<CENTER><form action=\"search.php\" method=get><FONT size=2>".translate("Topics")." ";

    $toplist = mysql_query("select topicid, topictext from topics order by topictext");
    echo "<SELECT NAME=\"topic\"onChange='submit()'>" ;
    echo "<OPTION VALUE=\"\">".translate("All Topics")."</option>\n";
    while(list($topicid, $topics) = mysql_fetch_row($toplist)) {
    if ($topicid==$topic) { $sel = "selected "; }
	echo "<option $sel value=\"$topicid\">$topics</option>\n";
    $sel = "";
    }
echo "
</select></font></form></center></td>
<td bgcolor=ffffff align=center>
<center><a href=\"index.php\"><img src=\"themes/OpenMind/images/logo.gif\" border=0 Alt=\"Welcome to $sitename\"></a></center></td>
<td bgcolor=ffffff align=center>
<CENTER><form action=\"search.php\" method=post><font size=2 color=\"#000000\">".translate("Search")." </font>
<input type=text name=query size=\"14\"></form></CENTER></TD>
</tr></table><br>

<TABLE cellpadding=0 cellspacing=0 width=\"100%\" border=\"0\" align=\"center\" bgcolor=\"#fefefe\">
<TR><TD bgcolor=\"#000000\" colspan=7>
<IMG src=\"themes/OpenMind/images/pixel.gif\" width=1 height=1 Alt=\"\" border=0></TD>
</tr><tr>
<TD bgcolor=\"#FFFFFF\" colspan=7>
<IMG src=\"themes/OpenMind/images/pixel.gif\" width=1 height=1 alt=\"\" border=0></TD>
</tr><tr bgcolor=\"#d8ecea\"><td colspan=7><img src=\"themes/OpenMind/images/pixel.gif\" width=1 height=6 Alt=\"\"></td>
</TR><TR valign=\"middle\" bgcolor=\"#d8ecea\">
<td align=center width=\"14%\">
<A href=\"/\"><img src=\"themes/OpenMind/images/home.gif\" border=0 width=22 height=22 Alt=\"Go to Home\"></A>
</td><td align=center width=\"14%\">
<A href=\"submit.php\"><img src=\"themes/OpenMind/images/submit.gif\" border=0 width=22 height=22 Alt=\"Send your Article\"></A>
</td><td align=center width=\"14%\">
<A href=\"download.php\"><img src=\"themes/OpenMind/images/download.gif\" border=0 width=22 height=22 Alt=\"Downloads\"></A>
</td><td align=center width=\"14%\">
<A href=\"forum.php\"><img src=\"themes/OpenMind/images/forum.gif\" border=0 width=22 height=22 Alt=\"Discussion Boards\"></A>
</td><td align=center width=\"14%\">";
if ($username == "Anonymous") {
    echo "<A href=\"user.php\"><img src=\"themes/OpenMind/images/unregistered.gif\" border=0 width=22 height=22 Alt=\"Create an Account\"></A>";
    $reg_u = "Create an Account";
} else {
    echo "<A href=\"user.php\"><img src=\"themes/OpenMind/images/registered.gif\" border=0 width=22 height=22 Alt=\"Configure your Account\"></A>";
    $reg_u = "Your Account";
}
echo "
</td><td align=center width=\"14%\">
<A href=\"opendir.php\"><img src=\"themes/OpenMind/images/opendir.gif\" border=0 width=22 height=22 Alt=\"Open Directory\"></A>
</td><td align=center width=\"14%\">
<A href=\"top.php\"><img src=\"themes/OpenMind/images/top.gif\" border=0 width=22 height=22 Alt=\"Top 10\"></A>
</TD></tr>

<TR valign=\"middle\" bgcolor=\"#d8ecea\">
<td align=center><font size=2>
<a href=\"/\">Home</a></font>
</td><td align=center><font size=2>
<a href=\"submit.php\">Submit</a></font>
</td><td align=center><font size=2>
<a href=\"download.php\">Downloads</a></font>
</td><td align=center><font size=2>
<a href=\"forum.php\">Forums</a></font>
</td><td align=center><font size=2>
<a href=\"user.php\">$reg_u</a></font>
</td><td align=center><font size=2>
<a href=\"opendir.php\">Open Directory</a></font>
</td><td align=center><font size=2>
<a href=\"top.php\">Top 10</a></font>
</td></tr>
<tr bgcolor=\"#d8ecea\"><td colspan=7><img src=\"themes/OpenMind/images/pixel.gif\" width=1 height=6 Alt=\"\"></td></tr>
";
?>

<TR>
<TD bgcolor="#cccccc" colspan=7><IMG src="themes/OpenMind/images/pixel.gif" width=1 height=1 alt="" border=0></TD>
</tr><tr>
<TD bgcolor="#000000" colspan=7><IMG src="themes/OpenMind/images/pixel.gif" width=1 height=1 alt="" border=0></TD>
</TR></TABLE>


<!-- FIN DEL TITULO -->

<table width="95%" cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff" align="center"><tr valign=top>
<td bgcolor=ffffff><img src="themes/OpenMind/images/pixel.gif" width=1 height=20 border=0 alt=""></td></tr></table>

<table width="95%" cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff" align="center"><tr valign=top>
<td bgcolor=ffffff><img src="themes/OpenMind/images/pixel.gif" width=10 height=1 border=0 alt=""></td>
<td bgcolor=ffffff width=150 valign=top>

<?php

mainblock();
online();
adminblock();
leftblocks();
ephemblock();
headlines();

?>
</td><td><img src="themes/OpenMind/images/pixel.gif" width=15 height=1 border=0 alt=""></td><td width="100%">
