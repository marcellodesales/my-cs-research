<?php

if ($index == 1) {
    echo "</td><td><img src=themes/NukeNews/pixel.gif width=15 height=1 border=0></td><td valign=\"top\" width=150>";
    category();
    pollNewest();
    bigstory(); 
    loginbox();
    userblock();
    oldNews($storynum);
    rightblocks();
}


echo "</td><td bgcolor=ffffff><img src=themes/NukeNews/pixel.gif width=10 height=1 border=0></td>";
?>
</tr></table>

<table width="95%" cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff" align="center"><tr valign=top>
<TD align="middle" height=17>
<IMG height=17 alt="" hspace=0 src="themes/NukeNews/corner-bottom-left.gif" width=17 align=left>
<IMG height=17 alt="" hspace=0 src="themes/NukeNews/corner-bottom-right.gif" width=17 align=right>
</TD>
      </TR>
    </TABLE>
<br>

<table width="95%" cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff" align="center"><tr valign=top>
<TD><IMG height=17 alt="" hspace=0 src="themes/NukeNews/corner-top-left.gif" width=17 align=left></td>
<td width=100%>&nbsp;</td>
<td><IMG height=17 alt="" hspace=0 src="themes/NukeNews/corner-top-right.gif" width=17 align=right></td>

</tr><tr align=middle>
<td width=100% colspan=3>
<?php footmsg(); ?>
</td>
</tr><tr align=top>

<TD><IMG height=17 alt="" hspace=0 src="themes/NukeNews/corner-bottom-left.gif" width=17 align=left></td>
<td width=100%>&nbsp;</td>
<td><IMG height=17 alt="" hspace=0 src="themes/NukeNews/corner-bottom-right.gif" width=17 align=right></TD>
</TR></TABLE>
<br><br>