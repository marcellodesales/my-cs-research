<?php
 echo '<a href="jedit.php?file=anything.php">Edit</a>';
?>
