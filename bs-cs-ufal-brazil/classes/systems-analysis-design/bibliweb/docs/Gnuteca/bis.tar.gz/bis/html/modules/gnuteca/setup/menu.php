<?

function CallImporta()
{
  exec("php importaISO.php");
}

function CallGeraExemplares()
{
  exec("php geraExemplares.php");
}

function CallAlteraEtiquetas()
{
  exec("php alteraEtiquetas.php");
}

function CallAlteraConteudos()
{
  exec("php alteraConteudo.php");
}

function FechaJanela()
{
  Gtk::main_quit();
}

function create_main_window()
{
  $buttons = array('Gera Exemplares|Gera Tabela de Exemplares.'      => 'CallGeraExemplares',
                   'Altera Conteudos|Altera Conte�do das Etiquetas.' => 'CallAlteraConteudos',
                   'Altera Etiquetas|Troca Etiquetas.'               => 'CallAlteraEtiquetas',
                   'Importa|Importa Arquivo ISO.'                    => 'CallImporta',
                  );

  $tooltips = &new GtkTooltips();

  $window = &new GtkWindow();
  $window->set_policy(false, false, false);
  $window->set_name('main window');
  $window->set_title('Setup');
  $window->set_usize(200, 200);
  $window->set_uposition(20, 20);

  $window->connect('delete-event', 'FechaJanela');

  $box1 = &new GtkVBox();
  $window->add($box1);

  $scrolled_window = &new GtkScrolledWindow();
  $scrolled_window->set_border_width(10);
  $scrolled_window->set_policy(GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);

  $box1->pack_start($scrolled_window);

  $box2 = &new GtKVBox();
  $box2->set_border_width(10);
  $scrolled_window->add_with_viewport($box2);
  $box2->set_focus_vadjustment($scrolled_window->get_vadjustment());

  ksort($buttons);
  foreach ($buttons as $label  => $function) {
    list ( $label, $help ) = explode('|',$label,2);

    $button = &new GtkButton($label);
    $tooltips->set_tip($button, $help, '');
    if ($function)
      $button->connect('clicked', $function);
    else
      $button->set_sensitive(false);
    $box2->pack_start($button);
  }

  $separator = &new GtkHSeparator();
  $box1->pack_start($separator, false);

  $box2 = &new GtkVBox(false, 10);
  $box2->set_border_width(10);
  $box1->pack_start($box2, false);

  $button = &new GtkButton('close');
  $button->connect_object('clicked', array('gtk', 'main_quit'));
  $box2->pack_start($button);
  $button->set_flags(GTK_CAN_DEFAULT);
  $button->grab_default();

  $window->show_all();
}
if (strtoupper(substr(PHP_OS, 0, 3)) == 'WIN')
  dl('php_gtk.dll');
else
  dl('php_gtk.so');


create_main_window();
Gtk::main();

?>