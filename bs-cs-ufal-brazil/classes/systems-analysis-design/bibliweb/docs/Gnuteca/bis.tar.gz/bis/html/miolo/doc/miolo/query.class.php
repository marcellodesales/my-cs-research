<html>
<head>
 <title> MIOLO - Classe query</title>
 <link rel="stylesheet" href="/miolo/doc/doc.css">
</head>
<body>
<? include '/usr/local/bis/html//miolo/doc/header.inc' ?>
<h2>Classe: Query</h2>
<blockquote>
extends <a href="#.class.php">SuperClasse</a>
</blockquote>
<p>TODO: Escrever documenta��o da classe Query.</p>
<h3>M�todos:</h3>
<dl>
 <dt><a href="/miolo/doc/miolo/query.Open.php">Open()</a></dt>
 <dd>Descri��o do m�todo Open. </dd>
 <dt><a href="/miolo/doc/miolo/query.Close.php">Close()</a></dt>
 <dd>Descri��o do m�todo Close. </dd>
 <dt><a href="/miolo/doc/miolo/query.MovePrev.php">MovePrev()</a></dt>
 <dd>Descri��o do m�todo MovePrev. </dd>
 <dt><a href="/miolo/doc/miolo/query.MoveNext.php">MoveNext()</a></dt>
 <dd>Descri��o do m�todo MoveNext. </dd>
 <dt><a href="/miolo/doc/miolo/query.GetRowCount.php">GetRowCount()</a></dt>
 <dd>Descri��o do m�todo GetRowCount. </dd>
 <dt><a href="/miolo/doc/miolo/query.GetColumnCount.php">GetColumnCount()</a></dt>
 <dd>Descri��o do m�todo GetColumnCount. </dd>
 <dt><a href="/miolo/doc/miolo/query.GetColumnName.php">GetColumnName($col)</a></dt>
 <dd>Descri��o do m�todo GetColumnName. </dd>
 <dt><a href="/miolo/doc/miolo/query.GetValue.php">GetValue($col)</a></dt>
 <dd>Descri��o do m�todo GetValue. </dd>
 <dt><a href="/miolo/doc/miolo/query.GetRowValues.php">GetRowValues()</a></dt>
 <dd>Descri��o do m�todo GetRowValues. </dd>
 <dt><a href="/miolo/doc/miolo/query.SetConnection.php">SetConnection($c)</a></dt>
 <dd>Descri��o do m�todo SetConnection. </dd>
 <dt><a href="/miolo/doc/miolo/query.SetSQL.php">SetSQL($sql)</a></dt>
 <dd>Descri��o do m�todo SetSQL. </dd>
</dl>
<p>&nbsp;</p>
<? include '/usr/local/bis/html//miolo/doc/footer.inc' ?>
</body>
</html>
