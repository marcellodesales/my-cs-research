<html>
<head>
 <title> MIOLO - Classe error</title>
 <link rel="stylesheet" href="/miolo/doc/doc.css">
</head>
<body>
<? include '/usr/local/bis/html//miolo/doc/header.inc' ?>
<h2>Classe: Error</h2>
<blockquote>
extends <a href="#.class.php">SuperClasse</a>
</blockquote>
<p>TODO: Escrever documenta��o da classe Error.</p>
<h3>M�todos:</h3>
<dl>
 <dt><a href="/miolo/doc/miolo/error.Error.php">Error($msg=null,$info=null,$href=null)</a></dt>
 <dd>Descri��o do m�todo Error. </dd>
 <dt><a href="/miolo/doc/miolo/error.Generate.php">Generate()</a></dt>
 <dd>Descri��o do m�todo Generate. </dd>
</dl>
<p>&nbsp;</p>
<? include '/usr/local/bis/html//miolo/doc/footer.inc' ?>
</body>
</html>
