<?php
/* Class Organizer
 * Small application that organize classes for other projects
 * Author Pablo Dall'Oglio
 * August, 02, 2001 (Cruzeiro do Sul - Brasil)
 * License GPL
 * Language PHP-GTK
 */
$VERSAO = '1.0';

class ClassOrganizer
{
  var $ctree;
  var $window;
  var $ctree_data;
  var $nomeArquivo;
  var $InfoWindow;

  function closeWindow()
  {
    Gtk::main_quit();
    return true;
  }

  function CarregaClasses()
  {
    $this->ctree->freeze();
    $this->ctree->clear();

    $arquivo = $this->nomeArquivo->get_text();
    $text = array('Raiz', '', '');
    $parent = $this->ctree->insert_node(null, null, $text, 5,
                    $this->ctree_data['pixmap1'],
                    $this->ctree_data['mask1'],
                    $this->ctree_data['pixmap2'],
                    $this->ctree_data['mask2'], false, true);


    $fd = @fopen($arquivo, 'r');

    if ($fd)
    {
      while (!feof($fd))
      {
        $conteudo = fgets($fd, 1000);

        if (strtoupper(substr(PHP_OS, 0, 3)) == 'WIN')
          $conteudo = substr($conteudo,0,strlen($conteudo)-2);

        if ($conteudo)
        {
          $text = explode('>', $conteudo, 3);

          if ($text[0]=='class')
          {
            $sibling = $this->ctree->insert_node($parent, null, $text, 5,
                            $this->ctree_data['pixmap1'],
                            $this->ctree_data['mask1'],
                            $this->ctree_data['pixmap2'],
                            $this->ctree_data['mask2'],
                            false, false);

          }
          else
          {
            $this->InsereFilho($sibling, $text);
          }
        }
      }
      fclose($fd);

      $text = array('Raiz', '', '');
      $this->ctree->thaw();
    }
  }

  function InsereFilho($parent, $text)
  {
    $sibling = @$this->ctree->insert_node($parent, null , $text, 5,
               $this->ctree_data['pixmap3'],
               $this->ctree_data['mask3'], null, null,
               true, false);

    $style = &new GtkStyle();
    if ($text[0]=='method')
      $style->fg[GTK_STATE_NORMAL] = new GdkColor(0, 10000, 60000);
    else if ($text[0]=='property')
       $style->fg[GTK_STATE_NORMAL] = new GdkColor(45000, 0, 0);
    else if ($text[0]=='event')
       $style->fg[GTK_STATE_NORMAL] = new GdkColor(10000, 45000, 0);
    else if ($text[0]=='parent')
       $style->fg[GTK_STATE_NORMAL] = new GdkColor(56000, 0, 60000);
    else if ($text[0]=='constructor')
       $style->fg[GTK_STATE_NORMAL] = new GdkColor(60000, 30000, 0);

    else
       $style->fg[GTK_STATE_NORMAL] = new GdkColor(45000, 45000, 0);

    @$this->ctree->node_set_row_style($sibling, $style);


  }
  function CloseInfo()
  {
    $this->InfoWindow->hide();
  }

  function ExibeInfo()
  {
    global $VERSAO;
    $this->InfoWindow = &new GtkWindow;
    $this->InfoWindow->connect_object('delete-event', array(&$this,'CloseInfo'));
    $this->InfoWindow->set_title('Creditos');
    $this->InfoWindow->set_border_width(0);
    $this->InfoWindow->set_default_size(248,150);
    $this->InfoWindow->set_policy(true, true, false);
    $this->InfoWindow->set_uposition(100,100);

    $vbox = &new GtkVBox();
    $this->InfoWindow->add($vbox);
    $vbox->show();

    $style = &new GtkStyle();
    $style->font = gdk::font_load ("-adobe-helvetica-*-r-*-*-*-140-*-*-*-*-*-*");

    $label = &new GtkLabel("Class Organizer " . $VERSAO . "\nAutor Pablo Dall'Oglio\npablo@univates.br\nVersao " . $VERSAO . "\n02/Agosto/2001\nLinguagem PHP-GTK ");

    $label->set_justify(GTK_JUSTIFY_LEFT);
    $label->set_uposition(0,10);
    $label->set_style($style);
    $label->show();
    $vbox->pack_start($label, false);
    $this->InfoWindow->show();
  }

  function ctree_click_column($ctree, $column)
  {
    if ($column == $this->ctree->sort_column) {
      if ($this->ctree->sort_type == GTK_SORT_ASCENDING)
        $this->ctree->set_sort_type(GTK_SORT_DESCENDING);
      else
        $this->ctree->set_sort_type(GTK_SORT_ASCENDING);
    } else
      $this->ctree->set_sort_column($column);

    $this->ctree->sort_recursive();
  }

  function expand_all($button, $ctree)
  {
    $this->ctree->expand_recursive();
  }

  function collapse_all($button, $ctree)
  {
    $this->ctree->collapse_recursive();
  }

  function remove_selection($button, $ctree)
  {
    $this->ctree->freeze();

    while (($node = $this->ctree->selection[0]) !== null) {
      if ($node->is_leaf)
        $this->ctree_data['pages']--;
      else
        $this->ctree->post_recursive($node, 'count_items');

      $this->ctree->remove_node($node);

      if ($this->ctree->selection_mode == GTK_SELECTION_BROWSE)
        break;
    }

    if ($this->ctree->selection_mode == GTK_SELECTION_EXTENDED &&
      $this->ctree->selection[0] === null && $this->ctree->focus_row >= 0) {
      $node = $this->ctree->node_nth($this->ctree->focus_row);
      if ($node)
        $this->ctree->select($node);
    }

    $this->ctree->thaw();
  }

  function KeyTest($p1)
  {
    if ($p1->keyval == 65293)
      $this->CarregaClasses();
  }

  function ClassOrganizer()
  {
    global $VERSAO;
    $this->window = &new GtkWindow;
    $this->window->connect_object('delete-event', array(&$this,'CloseWindow'));
    $this->window->set_title('ClassOrganizer');
    $this->window->set_border_width(0);
    $this->window->set_default_size(700,500);
    $this->window->set_uposition(60,60);

    $vbox = &new GtkVBox();
    $this->window->add($vbox);
    $vbox->show();

    $label = &new GtkLabel('Class Organizer ' . $VERSAO);
    $color = &new GdkColor(900000, 0, 0);
    $style = &new GtkStyle();
    $style->font = gdk::font_load ("-adobe-helvetica-bold-r-*-*-*-140-*-*-*-*-*-*");
    $style->fg[GTK_STATE_NORMAL] = $color;

    $label->set_style($style);
    $vbox->pack_start($label, false);
    $label->show();

    $scrolled_win = &new GtkScrolledWindow();
    $scrolled_win->set_border_width(5);
    $scrolled_win->set_policy(GTK_POLICY_AUTOMATIC, GTK_POLICY_ALWAYS);
    $vbox->pack_start($scrolled_win);
    $scrolled_win->show();

    $this->ctree = &new GtkCTree(3, 0, array('Class', 'Elements', 'ShordDesc'));
    $scrolled_win->add($this->ctree);
    $this->ctree->show();

    $this->ctree->set_column_auto_resize(0, true);
    $this->ctree->set_column_width(1, 200);
    $this->ctree->set_selection_mode(GTK_SELECTION_EXTENDED);
    $this->ctree->set_line_style(GTK_CTREE_LINES_DOTTED);
    $line_style = GTK_CTREE_LINES_DOTTED;

    $hbox = &new GtkHBox(false, 5);
    $hbox->set_border_width(5);
    $vbox->pack_start($hbox, false);
    $hbox->show();

    $this->nomeArquivo = &new GtkEntry();
    $this->nomeArquivo->set_text('classes.txt');
    $hbox->pack_start($this->nomeArquivo);
    $this->nomeArquivo->show();

    $this->nomeArquivo->add_events(GDK_KEY_PRESS_MASK);
    $this->nomeArquivo->connect_object('key_press_event', array(&$this,'KeyTest'));

    $button = &new GtkButton('Carrega/Load');
    $button->connect_object('clicked', array(&$this,'CarregaClasses'));
    $hbox->pack_start($button);
    $button->show();


    $button = &new GtkButton('?');
    $button->connect_object('clicked', array(&$this,'ExibeInfo'));
    $hbox->pack_start($button);
    $button->show();

    
    $bbox = &new GtkHBox(false, 5);
    $bbox->set_border_width(5);
    $vbox->pack_start($bbox, false);
    $bbox->show();

    $this->window->realize();

    $book_closed_xpm = array('16 16 6 1',
                 '       c None s None',
                 '.      c black',
                 'X      c red',
                 'o      c yellow',
                 'O      c #808080',
                 '#      c white',
                 '                ',
                 '       ..       ',
                 '     ..XX.      ',
                 '   ..XXXXX.     ',
                 ' ..XXXXXXXX.    ',
                 '.ooXXXXXXXXX.   ',
                 '..ooXXXXXXXXX.  ',
                 '.X.ooXXXXXXXXX. ',
                 '.XX.ooXXXXXX..  ',
                 ' .XX.ooXXX..#O  ',
                 '  .XX.oo..##OO. ',
                 '   .XX..##OO..  ',
                 '    .X.#OO..    ',
                 '     ..O..      ',
                 '      ..        ',
                 '                ');
    $book_open_xpm = array('16 16 4 1',
                 '       c None s None',
                 '.      c black',
                 'X      c #808080',
                 'o      c white',
                 '                ',
                 '  ..            ',
                 ' .Xo.    ...    ',
                 ' .Xoo. ..oo.    ',
                 ' .Xooo.Xooo...  ',
                 ' .Xooo.oooo.X.  ',
                 ' .Xooo.Xooo.X.  ',
                 ' .Xooo.oooo.X.  ',
                 ' .Xooo.Xooo.X.  ',
                 ' .Xooo.oooo.X.  ',
                 '  .Xoo.Xoo..X.  ',
                 '   .Xo.o..ooX.  ',
                 '    .X..XXXXX.  ',
                 '    ..X.......  ',
                 '     ..         ',
                 '                ');
    $mini_page_xpm = array('16 16 4 1',
                 '       c None s None',
                 '.      c black',
                 'X      c white',
                 'o      c #808080',
                 '                ',
                 '   .......      ',
                 '   .XXXXX..     ',
                 '   .XoooX.X.    ',
                 '   .XXXXX....   ',
                 '   .XooooXoo.o  ',
                 '   .XXXXXXXX.o  ',
                 '   .XooooooX.o  ',
                 '   .XXXXXXXX.o  ',
                 '   .XooooooX.o  ',
                 '   .XXXXXXXX.o  ',
                 '   .XooooooX.o  ',
                 '   .XXXXXXXX.o  ',
                 '   ..........o  ',
                 '    oooooooooo  ',
                 '                ');
    $transparent = &new GdkColor(0, 0, 0);

    list($this->ctree_data['pixmap1'], $this->ctree_data['mask1']) = Gdk::pixmap_create_from_xpm_d($this->window->window, $transparent, $book_closed_xpm);
    list($this->ctree_data['pixmap2'], $this->ctree_data['mask2']) = Gdk::pixmap_create_from_xpm_d($this->window->window, $transparent, $book_open_xpm);
    list($this->ctree_data['pixmap3'], $this->ctree_data['mask3']) = Gdk::pixmap_create_from_xpm_d($this->window->window, $transparent, $mini_page_xpm);

    $this->ctree->set_usize(0, 300);
    $this->window->show();
    $this->window->set_focus($this->nomeArquivo);

    //rebuild_tree(null, $this->ctree);
  }
}

if (strtoupper(substr(PHP_OS, 0, 3)) == 'WIN')
  dl('php_gtk.dll');
else
  dl('php_gtk.so');

$MyClassOrganizer = new ClassOrganizer();

Gtk::main();

?>
