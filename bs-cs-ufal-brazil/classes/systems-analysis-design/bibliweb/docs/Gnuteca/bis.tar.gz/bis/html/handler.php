<?php

    // include_once 'miolo/login.class';

    header ("Cache-Control: no-cache, must-revalidate");  // HTTP/1.1
    header ("Pragma: no-cache");                          // HTTP/1.0

    include_once 'miolo/miolo.php';
    
    $MIOLO->Trace("HTTP_REFERER='" . getenv("HTTP_REFERER") . "'<br>\n");
    $MIOLO->Trace("HTTP_USER_AGENT='$HTTP_USER_AGENT'<br>\n");
    $MIOLO->uses('ui/statusbar.class');

    /**
     *
     */
    class DefaultStatusBar
    {
        function Generate()
        {   global $MIOLO;
            
            $login = $MIOLO->GetLogin();

            $online = 0; // ( time() - $login->time ) / 60; 

            $sb = new StatusBar();
            $sb->AddInfo('<div align="center">Usu�rio: ' . ($login->id ? $login->id : '-') . '</div>');
            $sb->AddInfo('<div align="center">Hora Login: ' . ($login->id ? Date('H:i',$login->time) . 
                         ' (' . sprintf('%02d:%02d',$online/60,$online%60) . ')' : '--:--') . '</div>');        
            $sb->AddInfo('<div align="center">Data: '. ($login->id ? Date('d/m/Y',$login->time) : '--/--/----') . '</div>');        
            $sb->AddInfo('<div align="center">MIOLO Version: ' . MIOLO_VERSION . '</div>');
            
            $sb->Generate();
        }
    }
    
    // registrar scripts externos (os modulos podem registrar scripts 
    // individuais nos handlers)     
    $theme->AddScript("common.js");

    // variaveis globais que utilizamos em todos os modulos
    $theme = & $MIOLO->GetTheme();

	$theme->Status(new DefaultStatusBar());

    $menu    = $theme->CreateMenu('SAGU-Public');
    $topmenu = $theme->CreateMenu('Menu Principal','flow');

    $menu->AddOption('Logout','common','logout');

    /*
    if ( $login->id != 'guest' && $login->id )
      $MIOLO->InvokeHandler('common','main');   
      
    else
      $MIOLO->InvokeHandler('public','main');   
    */

    $MIOLO->InvokeHandler('common','main');   

    // $MIOLO->dump($theme);
?>
