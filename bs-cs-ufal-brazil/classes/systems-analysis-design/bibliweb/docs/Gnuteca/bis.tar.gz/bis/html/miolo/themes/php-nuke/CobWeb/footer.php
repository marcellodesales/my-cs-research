<?php

if ($index == 1) {
    echo "</td><td>&nbsp;</td><td valign=top width=200>\n";
    category();
    pollNewest();
    bigstory();
    loginbox();
    userblock();
    oldNews($storynum);
    rightblocks();
    searchbox();
}
echo "</td></tr></table>";
footmsg();
?>