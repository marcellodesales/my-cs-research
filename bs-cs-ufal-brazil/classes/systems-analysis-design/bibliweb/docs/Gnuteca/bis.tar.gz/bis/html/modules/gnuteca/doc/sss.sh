#!/bin/sh
php /gt/doc/cor.php 
