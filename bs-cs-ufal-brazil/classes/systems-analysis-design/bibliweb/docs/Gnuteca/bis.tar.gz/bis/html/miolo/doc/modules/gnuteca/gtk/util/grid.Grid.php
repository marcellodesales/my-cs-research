<html>
<head>
 <title> MIOLO - grid:Grid</title>
 <link rel="stylesheet" href="/miolo/doc/doc.css">
</head>
<body>
<? include '/usr/local/bis/html//miolo/doc/header.inc' ?>
<h3 align="right">Classe: <a href="/miolo/doc/modules/gnuteca/gtk/util/grid.class.php">Grid</a></h3>
<h2>Grid($Title, $Titles, $width, $height, $label='ok')</h2>
<p>TODO: Escrever documenta��o da fun��o Grid.</p>
<h3>Par�metros:</h3>
<dl>
 <dt>$Title</dt>
 <dd>Descri��o par�metro $Title.</dd>
 <dt> $Titles</dt>
 <dd>Descri��o par�metro  $Titles.</dd>
 <dt> $width</dt>
 <dd>Descri��o par�metro  $width.</dd>
 <dt> $height</dt>
 <dd>Descri��o par�metro  $height.</dd>
 <dt> $label</dt>
 <dd>Descri��o par�metro  $label.</dd>
</dl>
<p>&nbsp;</p>
<pre>
<?php
highlight_string(
'<?php
    ...
    $grid->Grid($Title, $Titles, $width, $height, $label); 
    ...
?>');
?>
</pre>
<? include '/usr/local/bis/html//miolo/doc/footer.inc' ?>
</body>
</html>
