<html>
<head>
 <title> MIOLO - Classe miolo</title>
 <link rel="stylesheet" href="/miolo/doc/doc.css">
</head>
<body>
<? include '/usr/local/bis/html//miolo/doc/header.inc' ?>
<h2>Classe: miolo</h2>
<blockquote>
extends <a href="#.class.php">SuperClasse</a>
</blockquote>
<p>TODO: Escrever documenta��o da classe miolo.</p>
<h3>M�todos:</h3>
<dl>
 <dt><a href="#">foo()</a></dt>
 <dd>Descri��o do m�todo foo</dd>
 <dt><a href="#">bar()</a></dt>
 <dd>Descri��o do m�todo bar</dd>
 <dt><a href="#">rin()</a></dt>
 <dd>Descri��o do m�todo rin</dd>
</dl>
<p>&nbsp;</p>
<? include '/usr/local/bis/html//miolo/doc/footer.inc' ?>
</body>
</html>
