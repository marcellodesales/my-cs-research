<?php

$thename = "RedDress";
$lnkcolor = "000000";
$bgcolor1 = "#CCCCCC";
$bgcolor2 = "#333333";
$bgcolor3 = "CCCCCC";
$textcolor1 = "#FFFFFF";
$textcolor2 = "#000000";
$hr = 1; # 1 to have horizonal rule in comments instead of table bgcolor


function themeindex ($aid, $informant, $time, $title, $counter, $topic, $thetext, $notes, $morelink, $topicname, $topicimage, $topictext) {
	if (!$config_called) {if (!isset($config)) {if (!isset($config)) { include("config.php"); }}}
	if ("$aid" == "$informant") { ?>

<table border=0 cellpadding=0 cellspacing=0 align=center width=100%>
<tr><td>

<table border=0 cellpadding=3 cellspacing=1 width=100%>
<tr><td>
<b><?php echo"$title"; ?></b><br>
<font size=1>
<?php echo translate("Posted by "); ?> <b><?php formatAidHeader($aid) ?></b> <?php echo translate("on"); ?> <?php echo"$time $timezone"; ?> (<?php echo $counter; ?> <?php echo translate("reads"); ?>)
<br>
</td>
</tr>
<tr>
<td bgcolor=ffffff>
<a href="search.php?query=&topic=<?php echo"$topic"; ?>&author="><img src=<?php echo"$tipath$topicimage"; ?> border=0 Alt=<?php echo"\"$topictext\""; ?> align=right hspace=10 vspace=10></a>
<?php echo"$thetext<br><br><font size=2>$morelink<br>
</td></tr>
"; ?>
</table>
</td>
</tr>
</table><br>


<?php	} else {
		if($informant != "") $boxstuff = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
		else $boxstuff = "$anonymous ";
		$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes";
?>
<table border=0 cellpadding=0 cellspacing=0 align=center  width=100%>
<tr><td>

<table border=0 cellpadding=3 cellspacing=1 width=100%>
<tr><td>
<b><?php echo"$title"; ?></b><br>
<font size=1>
<?php echo translate("Posted by "); ?> <?php formatAidHeader($aid); ?> <?php echo translate("on"); ?> <?php echo"$time $timezone"; ?> (<?php echo $counter; ?> <?php echo translate("reads"); ?>)
<br>
</td>
</tr>
<tr>
<td bgcolor=ffffff>
<a href="search.php?query=&topic=<?php echo"$topic"; ?>&author="><img src=<?php echo"$tipath$topicimage"; ?> border=0 Alt=<?php echo"\"$topictext\""; ?> align=right hspace=10 vspace=10></a>
<?php echo"$boxstuff<br><br><font size=2>$morelink<br>
</td></tr>
"; ?>
</table>
</td>
</tr>
</table><br>

<?php	}
}

function themearticle ($aid, $informant, $datetime, $title, $thetext, $topic, $topicname, $topicimage, $topictext) {
	if (!$config_called) {if (!isset($config)) {if (!isset($config)) { include("config.php"); }}}
	if ("$aid" == "$informant") {
echo"

<table border=0 cellpadding=0 cellspacing=0 align=center bgcolor=000000 width=100%>
<tr><td>

<table border=0 cellpadding=3 cellspacing=1 width=100%>
<tr><td bgcolor=CCCCCC>
$font2
<b>$title</b><br>$font2 ".translate("Posted on ")." $datetime
";
global $admin, $sid;
if ($admin) {
    echo "&nbsp;&nbsp; $font2 [ <a href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]";
}
echo "
</td>
</tr>
<tr>
<td bgcolor=ffffff>
<a href=search.php?query=&topic=$topic&author=><img src=$tipath$topicimage border=0 Alt=\"$topictext\" align=right hspace=10 vspace=10></a>
$thetext
</td>
</tr>
</table>
</td>
</tr>
</table><br>
";

	} else {
		if($informant != "") $informant = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
		else $boxstuff = "$anonymous ";
		$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes";
echo "

<table border=0 cellpadding=0 cellspacing=0 align=center bgcolor=000000 width=100%>
<tr><td>
<table border=0 cellpadding=3 cellspacing=1 width=100%>
<tr><td bgcolor=CCCCCC>
$font3
<b>$title</b><br>$font2 ".translate("Contributed by ")." $informant ".translate("on")." $datetime</font>
";
global $admin, $sid;
if ($admin) {
    echo "&nbsp;&nbsp; $font2 [ <a href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]";
}
echo "
</td>
</tr>
<tr>
<td bgcolor=ffffff>
<a href=search.php?query=&topic=$topic&author=><img src=$tipath$topicimage border=0 Alt=\"$topictext\" align=right hspace=10 vspace=10></a>
$font3 $thetext
</td>
</tr>
</table>
</td>
</tr>
</table><br>
";

	}
}

function themesidebox($title, $content) {
    if (!$config_called) {if (!isset($config)) {if (!isset($config)) { include("config.php"); }}}
    echo "
    <table border=1 bordercolor=DDDDDD cellspacing=0 cellpadding=3 width=100%><tr><td>
    <table width=100% border=0 cellspacing=0 cellpadding=0><tr><td colspan=1>
    <font size=2><b>$title</b></td></tr><tr><td>
    <font size=2>$content</td></tr></table></td></tr></table><br>";
}
?>