#!/bin/sh
php /gt/doc/php-co/co.php 
