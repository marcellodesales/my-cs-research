<html>
<head>
 <title> MIOLO - MIOLO:UsesDump</title>
 <link rel="stylesheet" href="doc.css">
</head>
<body>
<? include 'header.inc' ?>
<h3 align="right">Classe: <a href="MIOLO.class.php">MIOLO</a></h3>
<h2>UsesDump()
</h2>
<p>TODO: Escrever documenta��o da fun��o UsesDump.</p>
<p>&nbsp;</p>
<pre>
<?php
highlight_string(
'<?php
    ...
    $MIOLO->UsesDump(); 
    ...
?>');
?>
</pre>
<? include 'footer.inc' ?>
</body>
</html>
