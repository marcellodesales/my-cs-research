<?php
cookiedecode($user);
$uname = $cookie[1];
if ($uname == "") {
        $uname = "Anonymous";
}
?>
<body onload=init() text="#000000" link="#000000" vlink="#0000ff" alink="#0000ff" background="themes/Autumn/bgsbenra2.jpg">
<br>
<?php
if ($banners) {
    include("banners.php");
}
?>
<br>
<a name="top"></a>
<table BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%" HEIGHT="140" >
  <tr valign="top" background="themes/Autumn/foggy_r1_c1.jpg" height="21"><!-- row 1 -->
   <td colspan=3 align=center background="themes/Autumn/foggy_r1_c1.jpg">
   <a href="/" target="_top"><FONT color=#ffff00 size=2>HOME</FONT></a>
<FONT color=#ffff00 size=2>&nbsp; | </FONT>
<a href="faq.php" target="_top"><FONT color=#ffff00 size=2>Help</FONT></a>
<FONT color=#ffff00 size=2>&nbsp; | </FONT>
<a href="users.php" target="_top"><FONT color=#ffff00 size=2>Members &amp; Sponsors</FONT></a>
   </td>
   </tr>
  <tr valign="top" background="themes/Autumn/foggy_r2_c1.jpg" height="20"><!-- row 2 -->
   <td colspan=3 align=center background="themes/Autumn/foggy_r2_c1.jpg" height="20"><FONT color=#ffff00 size=4><b><?php echo $sitename ?></b></font></td>
  </tr>
  <tr valign="top" align="right" width="600" height="80"><!-- row 3 -->
   <td height=80 width=80 align="right" colspan=3 background="themes/Autumn/foggy_r3_c1.jpg"><div align="right"><form action="search.php" method=post>
<font size="-2" color="#ffff00"><b><?php echo "".translate("Search").""; ?> <?php echo $sitename ?><br>
<input type=name name=query size="12">
</b></font></form></div></td>
  </tr>
  <tr valign="top" width="600" height="20"><!-- row 4 -->
   <td colspan=3 background="themes/Autumn/foggy_r4_c1.jpg"><div align=left valign=top><font size="-1" color="#ffff00"><?php
if ($uname == "Anonymous") {
    echo "<b>(Why not <font color=white><a href=\"user.php\">sign up</a></font> for an account?)</b>";
}
else
{
    echo "$uname, Welcome to $sitename";
}
?></font></div><div align=right valign=top><font size="-1"color="#FFFF00"><b><script language=JavaScript>
      <!--   // Array ofmonth Names
      var monthNames = new Array( "January","February","March","April","May","June","July","August","September","October","November","December");
      var now = new Date();
      thisYear = now.getYear();
      if(thisYear < 1900) {thisYear += 1900}; // corrections if Y2K display problem
      document.write(monthNames[now.getMonth()] + " " + now.getDate() + ", " + thisYear);
      // -->
</script></b></font></div></td>

  </tr>
</table>
<TABLE width="100%" align="CENTER" cellspacing="10" cellpadding="0">
<tr><td valign=TOP rowspan="5"><?php

mainblock();
adminblock();
leftblocks();
ephemblock();
headlines();

?>

</td><td width=1%>&nbsp;</td><td valign="TOP" width="100%">
<font color="#000000">

<BR>
<!-- end of header file -->
