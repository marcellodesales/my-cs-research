SAGU2 - Coding Standards
========================

- Tags de PHP:
==============
Prefira utilizar <?php .... ?>
ao inv�s de <? ...... ?>
e evite utilizar <script language="PHP" ... ?>


- Identa��o:
============
Identa��o padr�o utilizando 4 caracteres.
Para configurar o vim:
  set expandtab
  set shiftwidth=4
  set tabstop=4


- Nome de Constantes:
=====================
O nome de constantes devem ser identificados com todas as letra mai�scula.
Utilize _ para separar palavras.
Exemplo:
  DB_ACAO onde DB identifica a classe.


- Nome de Vari�ves:
===================
O nome de vari�veis devem ser identificados com letra min�scula.
Utilize _ para separar palavras.
Exemplo:
  $var1       = "Valor";
  $variavel_1 = "Valor1";


- Estruturas de Controle:
=========================
Iniciar o bloco de comandos com '{' na mesma linha do teste condicional.
No caso de teste composto com || e/ou && ... utilizar par�nteses para
separar os blocos e outro para delimitar todo o conjunto.
Utilizar chaves mesmo quando existir apenas um comando.
Deixar um espa�o entre o comando de condicional e o bloco de teste.

if ((condi��o1) || (condi��o2)) {
    a��o1;
} elseif ((condi��o3) && (condi��o4)) {
    a��o2;
    a��o3;
} else {
    a��o4;
}


switch (condi��o) {
case 1:
    a��o1;
    break;

case 2:
    a��o2;
    break;

default:
    a��o3;
    break;

}


- Chamada de Fun��es:
=====================
Uma chamada:
$var = funcao($param1, $param2, $param3);

Bloco de chamada de fun��es (observe o alinhamento):
$var1         = foo($bar);
$variavel2    = foo($baz);


- Defini��o de Fun��es:
=======================
Iniciar o bloco de c�digo (chaves) na segunda linha.

function umaFunction($arg1, $arg2 = '')
{
    if (condi��o) {
        c�digo;
    }
    return $val;
}

function connect(&$dsn, $persistent = false)
{
    if (is_array($dsn)) {
        $dsninfo = &$dsn;
    } else {
        $dsninfo = DB::parseDSN($dsn);
    }

    if (!$dsninfo || !$dsninfo['phptype']) {
        return $this->raiseError();
    }

    return true;
}


- Composi��o de vari�vel sql
============================
As cl�usulas select, from, where, and, group, ... ficam alinhadas
� direita, e, conseq�entemente, as identifica��es de arquivos, campos,...
ficam alinhados � esquerda.
As condi��es da cl�usula where tamb�m devem ter os '=' alinhados de forma
que as condi��es fiquema alinhados � esquerda

    $sql = " select distinct C.campo1, C.campo2, C.campo3" .
           "        D.campo1, " .
           "        count(*) " .
           "   from tabela1 A, " .
           "        tabela2 B, " .
           "        tabela3 C, " .
           "        tabela4 D " .
           "  where (A.campo1 = $var1) " .
           "    and (B.cmp3   = '$var2') " .
           "    and (A.campo2 = C.campo1) " .
           "    and (A.cmp4   = D.campo1) " .
           "    and (D.cmp3   = B.cmp1) " .
           "  group by C.campo1, " .
           "           C.cmp2 " ;


- Coment�rios:
==============
// para uma linha

/*
   em caso de
   mais de uma linha
*/


- Inclus�o de Arquivos:
=======================
Utilize include_once() e require_once() ao inv�s de include() e require()


- Cabe�alho dos Arquivos:
=========================
(Faltam fazer algumas defini��es, de acordo com o CVS, ...)

/* vim: set expandtab tabstop=4 shiftwidth=4: */
// +----------------------------------------------------------------------+
// | SAGU2 - SAGU Development Team - UNIVATES Centro Universit�rio        |
// +----------------------------------------------------------------------+
// | Copyleft (l) 1999, 2000, 2001  Equipe SAGU - UNIVATES                |
// +----------------------------------------------------------------------+
// | Licen�a GPL: veja o COPYING.TXT ou no site da FSF em www.fsf.org     |
// |                                                                      |
// | Site: http://sagu.codigoaberto.org.br                                |
// | E-mail: sagu@univates.br                                             |
// +----------------------------------------------------------------------+
// | Objetivo: Objetivo deste arquivo...                                  |
// +----------------------------------------------------------------------+                     
// $Id$


Ambiente do SAGU2
=================
(Esta parte ainda est� muito dependente de outras padroniza��es que ainda ser�o
definidas: layout/fun��es/classes/..., mas j� � uma pr�via:)

- Codifica��o dos Arquivos:
===========================
As p�ginas ser�o criadas dinamicamente, de acordo com as configura��es e caracter�sticas
do usu�rio/browser/m�dulo/tema... os arquivo dever�o incluir os seguintes arquivos (nessa
ordem):

  - SAGU2_Interface
  - Business_Interface
  - ...
  - ...
  - ...

- Codifica��o das op��es padr�o:
================================
Cada arquivo ter� v�rias instru��es que ser�o acionadas de acordo com o conte�do definido
na vari�vel $funcao.

case $funcao=='list'  // Consulta
case $funcao=='add'   // Inclus�o de registro
case $funcao=='del'   // Exclus�o de registros
...
...
