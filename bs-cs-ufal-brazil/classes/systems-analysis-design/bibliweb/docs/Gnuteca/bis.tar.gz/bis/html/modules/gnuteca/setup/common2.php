<?
set_time_limit(120);

// inicializa��o padr�o
$LoginDB     = "sagu";
$HostDB      = "127.0.0.1";
$LoginPort   = "5432";
$LoginUID    = "postgres";
$LoginPWD    = "postgres";

/**
 *
 */
class Query
{
  var $conn;     // the connection id
  var $sql;      // the SQL command string
  var $result;   // the SQL command result set
  var $row;      // the current row index
  
  function Open()
  {
    $this->result = pg_exec($this->conn->id,$this->sql); 
    $this->row    = -1;
    
    return $this->result != null;
  }
  
  function Close()
  {
    if ( $this->result != null )
    {
      pg_freeresult($this->result);

      $this->result = null;
    }
  }

  function MovePrev()
  {
    if ( $this->row >= 0 )
    {
      $this->row--;
      
      return true;
    }
    
    return false;
  }
  
  function MoveNext()
  {
    if ( $this->row + 1 < $this->GetRowCount() )
    {
      $this->row++;
      
      return true;
    }

    return false;
  }
  
  function GetRowCount()
  {
    return pg_numrows($this->result);
  }

  function GetColumnCount()
  {
    return pg_numfields($this->result);
  }

  function GetColumnName($col)
  {
    return pg_fieldname($this->result,$col-1);
  }

  function GetValue($col)
  {
    return pg_result($this->result,$this->row,$col-1);
  }

  function GetRowValues()
  {
    return @pg_fetch_row($this->result,$this->row);
  }

  function SetConnection($c)
  {
    $this->conn = $c;
  }
};

/**
 *
 */
class Connection
{
  var $id;         // the connection identifier
  var $traceback;  // a list of transaction errors
  var $level;      // a counter for the transaction level

  function Open($no_assert=false)
  {
    global $SessionAuth,$LoginUID,$LoginPWD,$LoginDB,$HostDB,$LoginPort;

    $arg = "host=$HostDB dbname=$LoginDB port=$LoginPort user=$LoginUID password=$LoginPWD";

    $this->id = pg_Connect($arg);

    $this->level = 0;

    if ( empty($no_assert) || !$no_assert )
    {
      $err = @$this->GetError();
      saguAssert($this->id,"Connection : Open(\"user=$LoginUID\") : Connection refused!<br><br>$err");
    }

    return empty($this->id) ? 0 : $this->id;
 }

  // closes a previously opened connection
  function Close()
  {
    if ( $this->id )
    {
      saguAssert($this->level==0,"Transactions not finished!");

      pg_close($this->id);

      $this->id = 0;
    }
  }
  
  function Begin()
  {
    $this->Execute("begin transaction");
    
    $this->level++;
  }

  function Finish()
  {
    saguAssert($this->level>0,"Transaction level underrun!");
    
    $success = $this->GetErrorCount() == 0;
    
    if ( $success )
      $this->Execute("commit");
    else
      $this->Execute("rollback");

    $this->level--;
    
    return $success;
  }

  function GetError()
  {
    return pg_errormessage($this->id);
  }

  function GetErrorCount()
  {
    return empty($this->traceback) ? 0 : count($this->traceback);
  }

  function CheckError()
  {
    if ( empty($this->traceback) )
      return;

    $n = count($this->traceback);

    if ( $n > 0 )
    {
      $msg = "";

      for ( $i=0; $i<$n; $i++ )
        $msg .= $this->traceback[$i] . "<br>";

      FatalExit("Transaction Error",$msg);
    }
  }

  function Execute($sql)
  {

    $rs = pg_exec($this->id,$sql);

    $success = false;

    if ( $rs )
    {
      $success = true;

      pg_freeresult($rs);
    }

    else
      $this->traceback[] = $this->GetError();

    return $success;
  }

  function CreateQuery($sql="")
  {
    saguAssert($this->id,"Connection: CreateQuery: Connection ID");

    $q = new Query;

    $q->conn   = $this;
    $q->sql    = $sql;
    $q->result = 0;
    $q->row    = -1;

    if ( $sql != "" )
      $q->Open();

    return $q;
  }
};


// -----------------------------------------------------------
// Purpose: The exit function is used in order to provide a
//          consistent manner of error handling. This function
//          does not return from execution.
// -----------------------------------------------------------
function FatalExit($msg="",$info="",$href="")
{ global $ErrorURL;

  if ( $msg == "" )
    $msg = "Erro inesperado";

  if ( $info == "" )
    $info = "Causa desconhecida";

  if ( $href == "" )
    $href = "javascript:history.go(-1)";

  if ( $ErrorURL )
  {
    include($ErrorURL);
    die;
  }
 
  echo("<html>");
  echo("<head>");
  echo("<title>Untitled Document</title>");
  echo("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\">");
  echo("</head>");
  echo("");
  echo("<body bgcolor=\"#FFFFFF\">");
  echo("<table width=\"80%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\" height=\"90%\">");
  echo("  <tr> ");
  echo("    <td width=\"33%\"> ");
  echo("      <div align=\"center\"><img src=\"/images/univates.gif\" width=\"104\" height=\"94\" align=\"middle\"></div>");
  echo("    </td>");
  echo("    <td width=\"67%\">");
  echo("      <div align=\"center\"><b><font color=\"#000000\" size=\"4\" face=\"Verdana, Arial, Helvetica, sans-serif\">Aten&ccedil;&atilde;o</font></b></div>");
  echo("    </td>");
  echo("  </tr>");
  echo("  <tr> ");
  echo("    <td colspan=\"2\"> ");
  echo("      <div align=\"center\">");
  echo("        <p><b><font size=\"5\" face=\"Verdana, Arial, Helvetica, sans-serif\" color=\"#FF0000\">$msg");
  echo("</font></b><br><br><font size=\"3\" face=\"Verdana, Arial, Helvetica, sans-serif\" color=\"#000000\">Causa: $info</font></p>");
  echo("        <p>&nbsp;</p>");
  echo("      </div>");
  echo("    </td>");
  echo("  </tr>");
  echo("  <tr> ");
  echo("    <td colspan=\"2\"> ");
  echo("      <div align=\"center\"><font face=\"Verdana, Arial, Helvetica, sans-serif\" size=\"2\"><a href=\"$href\"><b>Voltar</b></a></font></div>");
  echo("    </td>");
  echo("  </tr>");
  echo("</table>");
  echo("</body>");
  echo("</html>");

  die();
}


function saguAssert($logico, $mensagem)
{
  if (! $logico)
    echo($mensagem);
}
?>
