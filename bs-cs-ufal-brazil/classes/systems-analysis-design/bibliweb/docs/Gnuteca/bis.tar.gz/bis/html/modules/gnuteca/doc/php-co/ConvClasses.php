<?
/*
 * Based on test_xml_parser.html by mlemos Exp
 * Conversion to PHP-Corg format by Pablo Dall'Oglio
 */

require("xml_parser.php");


Function DumpStructure(&$structure,&$positions,$path, $antPath)
{
  global $colega;
  global $funcaoaberta;
  global $fd, $parent;

  if(GetType($structure[$path])=="array")
  {
    for($element=0;$element<$structure[$path]["Elements"];$element++)
    DumpStructure(&$structure,&$positions,$path.",$element", $path, $element);
  }
  else
  {

    if ($structure[$antPath]["Tag"]=='classtitle')
    {
      fwrite($fd, "\n\nclass>" . $structure[$path]);
      $parent=null;
    }

    if ($structure[$antPath]["Tag"]=='classparent')
      $parent = $structure[$path];

    if ($structure[$antPath]["Tag"]=='funcdef')
    {
      $buffer = $structure[$path];
      $buffer = ereg_replace("\n", '', $buffer);
      $buffer = ereg_replace(chr(13), '', $buffer);
      $buffer = (trim($buffer)) ? (trim($buffer) . ' ') : trim($buffer);
      if (!$funcaoaberta)
        if (trim($buffer)=='object')
          fwrite($fd, "\nconstructor> " . $buffer);
        else
          fwrite($fd, "\nmethod> " . $buffer);
    }

    if ($structure[$antPath]["Tag"]=='function')
    {
      $funcaoaberta = true;
      $colega = false;
      fwrite($fd, "" . $structure[$path] . '(');
    }

    if ($structure[$antPath]["Tag"]=='shortdesc')
    {
      $buffer = $structure[$path];
      $buffer = ereg_replace("\n", '', $buffer);
      $buffer = ereg_replace(chr(13), '', $buffer);
      $buffer = trim($buffer);
      if ($funcaoaberta) fwrite($fd, ')');
      $funcaoaberta = false;
      fwrite($fd, ">$buffer");
      if ($parent)
      {
        fwrite($fd, "\nparent>" . $parent . ">\n");
        $parent=null;
      }
    }

    if ($structure[$antPath]["Tag"]=='parameter')
    {
      if ($colega) fwrite($fd,', ');
      fwrite($fd, $structure[$path]);
      $colega = true;
    }
  }
}

 $handle=opendir('xml');
 $fd = fopen('classes.txt','w+');
 while (($filename = readdir($handle))!==false)
 {
   if ($filename!='.' && $filename!='..' && $filename!='cache')
   {
     $cachefile = $filename;
     $filename = "xml/$filename";
     echo $filename;
     $funcaoaberta = false;
     $colega = false;

     $error=XMLParseFile(&$parser,$filename,1,"/tmp/$cachefile.cache");
     if(strcmp($error,""))
      echo "Parser error: $error\n";
     else
     {
      DumpStructure(&$parser->structure,&$parser->positions,"0","0", &$fd);
      echo "\n";
     }         
   }
 }
 fclose($fd);
 closedir($handle); 
?>
