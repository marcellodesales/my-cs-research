<?php

echo "<body onload=init() bgcolor=FFFFFF aLink=#c0c0c0 bgColor=#ffffff link=#003767 text=#222222 vLink=#4185aa>
<br>";
if ($banners) {
    include("banners.php");
}
echo "<br>
<center>

<STYLE type=text/css>
.menu {
	FONT-WEIGHT: bold; TEXT-DECORATION: none; font-color: #FFFFFF
}
.s_menu {
	FONT-WEIGHT: bold; TEXT-DECORATION: none
}
</STYLE>
<TABLE align=center border=0 cellPadding=0 cellSpacing=0 width=100%><TBODY><TR>
<TD align=left width=275>
<a href=$nuke_url><img src=themes/Kuro5hin/logo.gif Alt=\"".translate("Welcome to")." $sitename\" border=0></a>
</TD>
<TD align=right>
<TABLE border=0 cellPadding=0 cellSpacing=0>
<TBODY>
<TR>
<TD align=right vAlign=top><A class=s_menu href=index.php>Home</A></TD>
<TD align=middle vAlign=center>| </TD>
<TD align=middle vAlign=top><A class=s_menu href=topics.php>Topics</A></TD>
<TD align=middle vAlign=center>| </TD>
<TD align=middle vAlign=top><A class=s_menu href=sections.php>Sections</A></TD>
<TD align=middle vAlign=center>| </TD>
</TR>
<TR>
<TD align=right vAlign=top><A class=s_menu href=links.php>Web Links</A></TD>
<TD align=middle vAlign=center>| </TD>
<TD align=middle vAlign=top><A class=s_menu href=friend.php>Recomiendanos</A></TD>
<TD align=middle vAlign=center>| </TD>
<TD align=middle vAlign=top><A class=s_menu href=memberslist.php>Members List</A></TD>
<TD align=middle vAlign=center>| </TD>
</TR>
<TR>
<TD align=right vAlign=top><A class=s_menu href=user.php>Your Account</A></TD>
<TD align=middle vAlign=center>| </TD>
<TD align=middle vAlign=top><A class=s_menu href=submit.php>Submit News</A></TD>
<TD align=middle vAlign=center>| </TD>
<TD align=middle vAlign=top><A class=s_menu href=stats.php>Stats</A></TD>
<TD align=middle vAlign=center>| </TD>
</TR>
<TR>
<TD align=right vAlign=top><A class=s_menu href=top.php>Top 10</A></TD>
<TD align=middle vAlign=center>| </TD>
<TD align=middle vAlign=top><A class=s_menu href=faq.php>FAQ's</A></TD>
<TD align=middle vAlign=center>| </TD>
</TR>
</TD>
</TBODY>
</TABLE>
</TD>
</TR>
</TBODY>
</TABLE>
<TABLE align=center bgColor=#006699 border=0 cellPadding=1 cellSpacing=0 width=100%>
<TBODY><TR>&nbsp;&nbsp;</TR></TBODY></TABLE>

<table cellpadding=0 cellspacing=0 border=0 width=100% bgcolor=FFFFFF><tr><td>
<table cellpadding=0 cellspacing=1 border=0 width=100% bgcolor=006699><tr>
<td align=right>
<font color=white size=2><b>
<A class=menu href=user.php><FONT color=#ffffff>Your Account</FONT></A> | 
<A class=menu href=index.php><FONT color=#ffffff>FAQ's</FONT></A> | 
<A class=menu href=search.php><FONT color=#ffffff>Search</FONT></A> | 
<A class=menu href=submit.php><FONT color=#ffffff>Submit News</FONT></A> | 
<A class=menu href=pollBooth.php><FONT color=#ffffff>Poll</FONT></A>  
</b></td></tr></table></td></tr></table><P>
<table width=100% align=center cellpadding=0 cellspacing=0 border=0><tr><td valign=top rowspan=15>
</td><td>&nbsp;&nbsp;</td><td valign=top width=100%>";

?>