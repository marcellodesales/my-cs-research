<?php
include("config.php");
?>
<?php
cookiedecode($user);
$uname = $cookie[1];
if ($uname == "") {
        $uname = "Anonymous";
}
?>
<body bgcolor="#FFFFFF" text="#000000" link="#000000" vlink="navy" alink="#FFCC66" topmargin="0" marginheight="0">
<a name="top"></a>

<!-- TOP navbar -->
<TABLE cellspacing="0" cellpadding="0" width="100%" border="0">
<tr bgcolor="Red">
<td colspan="2"><img src="themes/Christmas/pix.gif" width="1" height="1" alt=""></td>
</tr></TABLE>
<TABLE cellspacing="0" cellpadding="1" width="100%" border="0">
<tr bgcolor="Red" valing="middle">
<td><font face="verdana,geneva,arial,sans-serif" size="-2" color="#CCCCCC">
&nbsp; <!-- NICE SPOT FOR LINKS TO AFFILIATES (use &nbsp;&middot;&nbsp; to devide them) -->
</font></td>
<td align="right"><font face="verdana,geneva,arial,sans-serif" size="-2" color="#CCCCCC">
&nbsp; <!-- NICE SPOT FOR LINKS TO AFFILIATES (use &nbsp;&middot;&nbsp; to devide them) -->
</font></td>
</tr></TABLE>
<TABLE cellspacing="0" cellpadding="0" width="100%" align=center border=0>
<tr><td nowrap background="themes/Christmas/bgx1.gif" bgcolor="#EEEEEE">
<img src="themes/Christmas/bgx1.gif" width="1" height="6" alt=""></td>
</tr></table>
<!-- end TOP navbar -->

<TABLE cellspacing="0" cellpadding="4" width="100%" align="center" border="0">
<tbody><tr>
<td bgcolor="White">
      <table cellspacing="0" cellpadding="0" width=130 border=0>
      <tbody><tr bgcolor="#FFFFFF"><td height="90" align=center>
      <a href="<?php $nuke_url ?>"><img src="themes/Christmas/santa2.gif" width=123 height=82 border="0" alt="<?php echo $sitename ?>"></a>
      </td></tr></tbody></table>
</td>
<td align=center width="100%" background="themes/Christmas/bgx.gif" alt="">
<a href="/"><img src="themes/Christmas/title.gif" width=400 height=88 border="0" alt="<?php echo "".translate("Welcome to").""; ?> <?php echo $sitename ?>"></a>
</td>
<td bgcolor="White">
      <TABLE cellspacing="0" cellpadding="0" width=130 border=0>
      <tbody>

<!-- begin search box -->
      <tr bgcolor="#FFFFFF">
      <form action="search.php" method=post><td height="90" align="center" valign="middle">
<font size="-2" color="#666666"><b><?php echo "".translate("Search").""; ?> <?php echo $sitename ?><br>
<input type=name name=query size="12"><br><br>
</b></font></td></form></tr>
<!-- end search box -->

</tbody></TABLE>
</td></tr></tbody></TABLE>

<TABLE width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
<tr><td colspan="3" bgcolor="#EEEEEE" background="themes/Christmas/bgx2.gif"><img src="themes/Christmas/bgx2.gif" width="1" height="6" alt=""></td>
</tr><tr><td width="45%" align="left" bgcolor="Red">
<font size="-1" color="#FFFFFF">
<?php
if ($uname == "Anonymous") {
    echo "<b>(Why not <font color=white><a href=\"user.php\">sign up</a></font> for a Newton, Kiwanis acount?)</b>";
}
else
{
    echo "$uname, Welcome to $sitename";
}
?>
</font></td>
<td width="10%" align="center" bgcolor="Red">
<font size="-1" color="#FFFFFF"><b>&nbsp
</b></font></td>
<td width="45%" align="right" bgcolor="Red"></td>
<font size="-1"color="#FFFFFF"><b>
<script language=JavaScript>
      <!--   // Array ofmonth Names
      var monthNames = new Array( "January","February","March","April","May","June","July","August","September","October","November","December");
      var now = new Date();
      thisYear = now.getYear();
      if(thisYear < 1900) {thisYear += 1900}; // corrections if Y2K display problem
      document.write(monthNames[now.getMonth()] + " " + now.getDate() + ", " + thisYear);
      // -->
</script></b></font>
</tr><tr><td background="themes/Christmas/bgx1.gif" colspan="3">
<img src="themes/Christmas/bgx1.gif" width="1" height="6" alt=""></td>
</tr></TABLE>


<TABLE width="100%" align="CENTER" cellspacing="0" cellpadding="0">
<tr><td valign=TOP rowspan="5">

<?php

mainblock();
global $admin;
if ($admin) {
    adminblock();
}
leftblocks();
if ($Ephemerids==1) {
    ephemblock();
}
headlines();

?>

</td><td width=1%>&nbsp;</td><td valign="TOP" width="100%">
<font color="#000000">

<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td><font color="#999999" size=+1><b>Latest News</b></font></td>
    <td align="right"><font color="#666666" size=-2><b>
    <a href="/submit.php"><?php echo "".translate("Submit News")."";?></a></b></font>
    </td>
  </tr>
  <tr bgcolor="#666666">
    <td colspan="2"><img src="themes/Christmas/pix.gif" width="1" height="1" alt=""></td>
  </tr>
  <tr>
    <td colspan="2"><img src="themes/Christmas/pix.gif" width="1" height="1" alt=""></td>
  </tr>
  <tr bgcolor="#666666">
    <td colspan="2"><img src="themes/Christmas/pix.gif" width="1" height="1" alt=""></td>
  </tr>
</table>
<BR>
<!-- end of header file -->
