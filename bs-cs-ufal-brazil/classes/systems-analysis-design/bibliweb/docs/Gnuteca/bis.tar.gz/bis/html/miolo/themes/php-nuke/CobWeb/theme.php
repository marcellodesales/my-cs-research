<?php

$bgcolor1 = "AAAAAA";
$bgcolor2 = "006699";
$textcolor1 = "576F87";
$textcolor2 = "576F87";


function themesidebox($title, $content) {
    mt_srand((double)microtime()*1000000);
    $rcolor = mt_rand(1, 4);
    if ($rcolor == 1) {
	$tcolor = "225071";
    } elseif ($rcolor == 2) {
	$tcolor = "225071";
    } elseif ($rcolor == 3) {
	$tcolor = "225071";
    } elseif ($rcolor == 4) {
	$tcolor = "225071";
    }
    echo "<table width=\"165\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tr><td>\n";
    echo "<table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\"><tr><td>\n";
    echo "<img src=\"themes/CobWeb/left$rcolor.gif\" alt=\"\" border=\"0\" width=\"5\" height=\"19\"></td>\n";
    echo "<td bgcolor=$tcolor width=\"100%\"><b><font size=\"2\" color=\"#C5D6DF\">$title</font></b></td>\n";
    echo "<td align=\"right\"><img src=\"themes/CobWeb/right$rcolor.gif\" alt=\"\" border=\"0\" width=\"5\" height=\"19\"></td></tr></table>\n";
    echo "</td></tr><tr><td align=\"center\" valign=\"top\">\n";
    echo "<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"1\" bgcolor=$tcolor><tr><td width=100%>\n";
    echo "<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"4\" bgcolor=$tcolor><tr><td width=\"100%\" valign=\"top\" bgcolor=\"#B1C6D2\">\n";
    echo "$content\n";
    echo "<table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\"><tr><td>\n";
    echo "<img src=\"pixel.gif\" width=\"1\" height=\"4\" alt=\"\" border=\"0\"></td></tr></table>\n";
    echo "</td></tr></table>\n";
    echo "</td></tr></table>\n";
    echo "</td></tr><tr>\n";
    echo "<td align=\"center\" valign=\"bottom\">\n";
    echo "<img width=\"100%\" height=\"5\" src=\"themes/CobWeb/bottom$rcolor.gif\" vspace=\"0\" border=\"0\"></td></tr></table>\n";
    echo "<br>\n\n";
}

function themebigbox($title, $content) {
    mt_srand((double)microtime()*1000000);
    $rcolor = mt_rand(1, 4);
    if ($rcolor == 1) {
	$tcolor = "225071";
    } elseif ($rcolor == 2) {
	$tcolor = "225071";
    } elseif ($rcolor == 3) {
	$tcolor = "225071";
    } elseif ($rcolor == 4) {
	$tcolor = "225071";
    }
    echo "<table width=100% border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tr><td>";
    echo "<table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\"><tr><td>";
    echo "<img src=\"themes/CobWeb/left$rcolor.gif\" alt=\"\" border=\"0\" width=\"5\" height=\"19\"></td>";
    echo "<td bgcolor=$tcolor width=100%><b><font size=\"2\" color=\"#C5D6DF\">$title</font></b></td>";
    echo "<td align=\"right\"><img src=\"themes/CobWeb/right$rcolor.gif\" border=\"0\" width=\"5\" height=\"19\"></td></tr></table>";
    echo "</td></tr><tr><td align=\"center\" valign=\"top\">";
    echo "<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"1\" bgcolor=$tcolor><tr><td width=100%>";
    echo "<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"4\" bgcolor=$tcolor><tr><td width=\"100%\" valign=\"top\" bgcolor=\"#B1C6D2\">";
    echo "$content";
    echo "<table width=\"100%\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\"><tr><td>";
    echo "<img src=\"pixel.gif\" width=\"1\" height=\"4\" alt=\"\" border=\"0\"></td></tr></table>";
    echo "</td></tr></table>";
    echo "</td></tr></table>";
    echo "</td></tr><tr>";
    echo "<td align=\"center\" valign=\"bottom\">";
    echo "<img width=\"100%\" height=\"5\" src=\"themes/CobWeb/bottom$rcolor.gif\" vspace=\"0\" border=\"0\"></td></tr></table>";
    echo "<br>";
}

function themeindex($aid, $informant, $time, $title, $counter, $topic, $thetext, $notes, $morelink, $topicname, $topicimage, $topictext) {
    global $tipath, $anonymous;
    echo "<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" bgcolor=576F87><tr><td>\n";
    echo "<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"5\" bgcolor=D5DBE1><tr><td>\n";
    echo "<a href=search.php?topic=$topic><img src=$tipath$topicimage Alt=\"$topictext\" border=0 align=right></a>\n";
    echo "<font size=3><img src=\"themes/CobWeb/bullet.gif\" border=0 hspace=3><b>$title</b><br>\n";
    echo "<font size=1 color=576F87>".translate("Posted by ")."";
    formatAidHeader($aid);
    echo " ".translate("on")." $time ($counter ".translate("reads").")<br><br>\n";
    if ("$aid" == "$informant") {
	echo "<font size=2 color=576F87>$thetext<br><br>\n";
    } else {
	if ($informant != "") {
	    $boxstuff = "<a href=user.php?op=userinfo&uname=$informant>$informant</a> ";
	} else {
	    $boxstuff = "$anonymous ";
	}
	$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes\n";
	echo "<font size=2 color=576F87>$boxstuff<br><br>\n";
    }
    echo "<font size=2>$morelink<br><img src=themes/CobWeb/line.gif border=0 vspace=4>\n";
    echo "</td></tr></table>\n";
    echo "</td></tr></table>\n";
    echo "<br>\n\n";
}

function themearticle($aid, $informant, $datetime, $title, $thetext, $topic, $topicname, $topicimage, $topictext) {
    global $admin, $sid, $tipath;
    echo "<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"0\" bgcolor=576F87><tr><td>\n";
    echo "<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"5\" bgcolor=D5DBE1><tr><td>\n";
    echo "<a href=search.php?topic=$topic><img src=$tipath$topicimage Alt=\"$topictext\" border=0 align=right></a>\n";
    echo "<font size=3><img src=\"themes/CobWeb/bullet.gif\" border=0 hspace=3><b>$title</b>\n";
    if ($admin) {
	echo "&nbsp;&nbsp; [ <a href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]<br>\n";
    } else {
	echo "<br>\n";
    }
    echo "<font size=1 color=576F87>".translate("Posted by ")."";
    formatAidHeader($aid);
    echo " ".translate("on")." $datetime<br>\n";
    if ($informant != "") {
        echo "".translate("Contributed by ")." <a href=user.php?op=userinfo&uname=$informant>$informant</a><br><br>\n";
    } else {
	echo "".translate("Contributed by ")." $anonymous<br><br>\n";
    }
    echo "<font size=2 color=C5D6DF>$thetext<br><br>\n";
    echo "</td></tr></table>\n";
    echo "</td></tr></table>\n\n";
}

?>