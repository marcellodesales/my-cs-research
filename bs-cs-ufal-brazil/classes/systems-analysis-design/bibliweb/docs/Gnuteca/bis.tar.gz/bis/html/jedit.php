<?php

  dl("libphp_java.so");
      
  echo getcwd() . "<br>\n";
  echo "$CLASSPATH<br>\n";
      
  chdir('/usr/local/bis/html');
  $jedit = new java('JEditTool');  
  $jedit->editFile($file);
  
  include $DOCUMENT_ROOT . '/' . $file;
  
  /*
  else
  {
    $address = '192.168.0.53';
    $port    = 10001;

    if (($sock = socket (AF_INET, SOCK_STREAM, 0)) < 0) 
    {
      echo "socket() failed: reason: " . strerror ($sock) . "\n";
      return;
    }

    if (($out = connect($sock,$address,$port)) < 0) 
    {
      echo "connect() failed: reason: " . strerror ($out) . "\n";
      return;
    }

    write($out,$file."\n",strlen($file));
    // read($out,$data,1);
    sleep(5);
    close($out);
    close($sock);
  }
  */

?>
