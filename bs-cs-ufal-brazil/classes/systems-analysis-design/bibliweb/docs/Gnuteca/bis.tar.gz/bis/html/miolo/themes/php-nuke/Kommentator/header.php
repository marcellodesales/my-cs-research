<?php

echo "<body onload=init() bgcolor=FFFFFF text=000000 link=1E1165 vlink=1E1165 topmargin=5 leftmargin=5 rightmargin=5 marginheight=5>
<br>";
if ($banners) {
    include("banners.php");
}
echo "<br>
<table border=0 cellpadding=0 cellspacing=0 width=100% align=center>
<tr>

<td><table border=0 cellspacing=0 cellpadding=0 width=100%>
<tr>

<td><table cellpadding=0 cellspacing=0 border=0 width=100% bgcolor=#1e1165>
<tr>

    <td valign=top align=left width=120 rowspan=2 bgcolor=#1e1165>
    <img src='themes/Kommentator/top.01.gif' width='120' height='75' border='0' alt=''></td>
    
    <td valign=top align=left width=486 rowspan=2 bgcolor=#1e1165>
    <a href=$nuke_url><img src=themes/Kommentator/top.02.gif width=248 height=61 border=0 Alt=\"".translate("Welcome to")." $sitename\"></a><br>
    <a href=/index.php><img src=themes/Kommentator/top.02.menu.forsiden.1.gif width=75 height=14 border=0 alt=Nyheter></a><a href=/submit.php><img src=themes/Kommentator/top.02.menu.forsiden.6.gif width=66 height=14 border=0 alt='Send inn'></a><a href=/user.php><img src=themes/Kommentator/top.02.menu.forsiden.2.gif width=63 height=14 border=0 alt=Temaer></a><a href=/links.php><img src=themes/Kommentator/top.02.menu.forsiden.3.gif width=54 height=14 border=0 alt=Linker></a><a href=/top.php><img src=themes/Kommentator/top.02.menu.forsiden.4.gif width=63 height=14 border=0 alt=Topp10></a><a href=/search.php><img src=themes/Kommentator/top.02.menu.forsiden.7.gif width=42 height=14 border=0 alt=S�k></a><a href=/faq.php><img src=themes/Kommentator/top.02.menu.forsiden.5.gif width=123 height=14 border=0 alt=FAQ></a></td>
    
    <td valign=top align=left width=100% bgcolor=#1e1165>
    <img src='themes/Kommentator/spot.gif' width='2' height='73' border='0' alt=''></td>
    
    <td valign=top align=right width=130 rowspan=2 bgcolor=#1e1165>
    <img src='themes/Kommentator/top.04.gif' width='130' height='75' border='0' alt=''></td>
    
</tr>
<tr>

    <td valign=top align=left bgcolor=#999999>
    <img src='themes/Kommentator/spot.gif' width='2' height='2' border='0' alt=''></td>

</tr>
</table></td>

</tr>
</table></td>

</tr>
</table>

<table border=0 cellpadding=0 cellspacing=0 width=100% align=center>
<tr>

        <td width=120 bgcolor=#e0e0e0>
				<img src='themes/Kommentator/gradient.gif' border='0' width='120' height='21' alt=''></td>

        <td width=14><img src='themes/Kommentator/spot.gif' border='0' width='14' height='1' alt=''></td>

        <td valign=middle align=left width=75%>
        <font face=Verdana,Arial,Helvetica,sans-serif size=1 color=#cc0000>
        <b>$sitename</b> &gt; $slogan</font></td>
        
        <td valign=middle align=right width=25%>
        <font face=Verdana,Arial,Helvetica,sans-serif size=1 color=#cc0000>
        <script language=JavaScript>

        <!--
        // Array ofmonth Names
        var monthNames = new Array( 'January','February','March','April','May','June','July','August','September','October','November','December');
        var now = new Date();
        thisYear = now.getYear();
        if(thisYear < 1900) {thisYear += 1900}; // corrections if Y2K display problem
        document.write(monthNames[now.getMonth()] + ' ' + now.getDate() + ', ' + thisYear);
        // -->
        </script></b></font></td>        
        
</tr>
</table>

<table width=100% cellspacing=0 cellpadding=0 border=0 align=center>
<tr>

		<td bgcolor=ffffff width=134><img src='themes/Kommentator/spot.gif' width='134' height='1' border='0' alt=''></td>

		<td bgcolor=e0e0e0 width=100%><img src='themes/Kommentator/spot.gif' width='1' height='1' border='0' alt=''></td>

</tr>
</table>    

<table border=0 cellpadding=0 cellspacing=0 width=100% align=center>
<tr>

<td valign=top width=100% bgcolor=FFFFFF>
<table border=0 cellspacing=0 cellpadding=0 width=100%>
<tr>

<td valign=top width=120 bgcolor=e0e0e0>";

mainblock();
adminblock();
leftblocks();
ephemblock();
headlines();

echo "<img src='theme/Kommentator/spot.gif' border='0' width='120' height='1' alt=''></td><td width=10><img src='themes/Kommentator/spot.gif' border='0' width='10' height='1' alt=''></td><td width=100% valign=top>&nbsp;";
?>