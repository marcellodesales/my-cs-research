<?php

$thename = "NukeNews";
$bgcolor1 = "#d8ecea";
$bgcolor2 = "#a6bab8";
$bgcolor3 = "#d8ecea";
$bgcolor4 = "#b7cbc9";
$textcolor1 = "#FFFFFF";
$textcolor2 = "#000000";
$pollcolor = "#e9edf5";
$hr = 0; # 1 to have horizonal rule in comments instead of table bgcolor


function themeindex ($aid, $informant, $time, $title, $counter, $topic, $thetext, $notes, $morelink, $topicname, $topicimage, $topictext) {
    global $anonymous, $tipath;
    echo "
    <table border=0 cellpadding=0 cellspacing=0 bgcolor=ffffff width=\"100%\"><tr><td>
    <table border=0 cellpadding=1 cellspacing=0 bgcolor=000000 width=\"100%\"><tr><td>
    <table border=0 cellpadding=0 cellspacing=0 bgcolor=d8ecea width=\"100%\"><tr><td>
    <TD bgcolor=\"#FFFFFF\"><IMG src=\"themes/OpenMind/images/pixel.gif\" width=1 height=1 alt=\"\" border=0></TD></tr>
    <tr><td align=left height=20>
    <font size=3 color=\"#363636\"><b>&nbsp;$title</b></font>
    </td></tr>
    <TD bgcolor=\"#aaaaaa\"><IMG src=\"themes/OpenMind/images/pixel.gif\" width=1 height=1 alt=\"\" border=0></TD></tr>
    </table></td></tr></table>
    <a href=\"search.php?query=&topic=$topic\"><img src=\"$tipath$topicimage\" border=0 Alt=\"$topictext\" align=right hspace=10 vspace=10></a>
    <FONT color=\"#999999\" size=1>Posted by ";
    formatAidHeader($aid);
    echo "
    on $time $timezone ($counter ".translate("reads").")<br><br></font>
    
    ";
    if ("$aid" == "$informant") {
	echo "<FONT size=2 color=\"#505050\">$thetext</FONT>";
    } else {
	if($informant != "") {
	    $boxstuff = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
	} else {
	    $boxstuff = "$anonymous ";
	}
	$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes\n";
	echo "<font size=2 color=\"#505050\">$boxstuff</font>\n";
    }
    echo "
    <br><br><div align=left><img src=\"themes/OpenMind/images/point.gif\" border=0 alt=\"\">&nbsp;<font size=2>$morelink</div>
    </td></tr></table>
    <br><br>";
}

function themearticle ($aid, $informant, $datetime, $title, $thetext, $topic, $topicname, $topicimage, $topictext) {
    global $admin, $sid, $tipath;
    echo"
    <table border=0 cellpadding=0 cellspacing=0 bgcolor=ffffff width=\"100%\"><tr><td>
    <table border=0 cellpadding=1 cellspacing=0 bgcolor=000000 width=\"100%\"><tr><td>
    <table border=0 cellpadding=0 cellspacing=0 bgcolor=d8ecea width=\"100%\"><tr>
    <TD bgcolor=\"#FFFFFF\"><IMG src=\"themes/OpenMind/images/pixel.gif\" width=1 height=1 alt=\"\" border=0></TD></tr>
    <tr><td align=left height=20>
    <font size=3 color=\"#363636\"><b>&nbsp;$title</b></font>
    </td></tr>
    <tr><TD bgcolor=\"#AAAAAA\"><IMG src=\"themes/OpenMind/images/pixel.gif\" width=1 height=1 alt=\"\" border=0></TD></tr>
    </td></tr></table></td></tr></table>
    <font size=2 color=\"#363636\">".translate('Posted on')." $datetime by ";
    formatAidHeader($aid);
    if ($admin) {
	echo "&nbsp;&nbsp;[ <a href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]</font>";
    }
    echo "<br>";
    echo "<a href=\"search.php?query=&topic=$topic\"><img src=\"$tipath$topicimage\" border=0 Alt=\"$topictext\" align=right hspace=10 vspace=10></a>";
    if($informant != "") {
	echo "<font size=2>Contributed by: <a href=\"user.php?op=userinfo&uname=$informant\">$informant</a></font><br><br>";
    } else {
        echo "<font size=2>Contributed by: $anonymous</font><br><br>";
    }
    echo "$thetext";
    echo "</td></tr></table><br>";
}

function themesidebox($title, $content) {
    global $tbl;
    if (!isset($tbl)) {
	$tbl = 150;
    }
    echo "
	<table border=0 cellpadding=1 cellspacing=0 bgcolor=000000 width=$tbl><tr><td>
	<table border=0 cellpadding=0 cellspacing=0 bgcolor=d8ecea width=\"100%\"><tr>
	<TD bgcolor=\"#FFFFFF\"><IMG src=\"themes/OpenMind/images/pixel.gif\" width=1 height=1 alt=\"\" border=0></TD></tr>
	<tr><td align=left height=20>\n
	<font size=2 color=\"#363636\"><b>&nbsp;&nbsp;$title</b></font></td></tr>\n
	<tr><TD bgcolor=\"#aaaaaa\"><IMG src=\"themes/OpenMind/images/pixel.gif\" width=1 height=1 alt=\"\" border=0></TD>
	</tr></table></td></tr></table>
	<table border=0 cellpadding=0 cellspacing=0 bgcolor=ffffff width=$tbl>
	<tr valign=top><td bgcolor=ffffff>
	<font size=2>$content</font>
	</td></tr>
	<tr><td><br><img src=\"themes/OpenMind/images/shadow.gif\" width=$tbl border=0 alt=\"\">
	</td></tr></table>
	<br>\n\n\n";
}

?>
