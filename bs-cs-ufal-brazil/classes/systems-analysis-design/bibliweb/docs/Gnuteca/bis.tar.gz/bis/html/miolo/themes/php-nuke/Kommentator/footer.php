<?php

if ($index == 1) {
    echo "<table width=100% cellpadding=0 cellspacing=0 border=0><tr><td width=50% valign=top>";
		oldNews(5);
		echo "</font></td><td width=1 bgcolor=e0e0e0 valign=top><img src=images/spot.gif width=1 height=1 border=0></td><td width=10 valign=top><table cellpadding=0 cellspacing=0 width=10 border=0><tr><td width=100% bgcolor=#868686>&nbsp;</td></tr></table></td><td width=50% valign=top>";

$result = mysql_query("select sid, title, time, counter from stories order by counter DESC limit 0,$top");

echo "<table cellpadding=0 cellspacing=0 width=100% border=0><tr><td width=100% bgcolor=#868686 valign=top><font color=ffffff><b>10 mest popul�re noensinne:</b></td></tr><tr><td width=100% valign=top><font face=Arial,Helvetica,sans-serif>&nbsp;<br>";
$lugar=1;
while(list($sid, $title, $time, $counter) = mysql_fetch_row($result)) {
    if($counter>0) {
	echo "<b>$lugar:</b> <a href=article.php?sid=$sid>$title</a> <!-- (".translate("read:")." ($counter) ".translate("times").") --><br>";
	$lugar++;
    }
}

    echo "</font></td></tr></table></td></tr></table></td><td bgcolor=#e0e0e0><img src=images/spot.gif height=10 width=1 border=0></td><td bgcolor=white valign=\"top\">";
    category();
    pollNewest();
    loginbox();
    userblock();
    rightblocks();
    echo "</td>";
}
echo "
</td></tr></table></td></tr></table><p>
<table width=100% cellspacing=0 cellpadding=0 border=0>
<tr><td bgcolor=e0e0e0><img src=images/nada.gif width=1 height=1 border=0></td></tr>
<tr><td bgcolor=FFFFFF><img src=images/nada.gif width=1 height=1 border=0></td></tr>
</table>";
footmsg();
?>