<?php

if ($index == 1) {
    echo "</td><td>&nbsp;&nbsp;</td><td valign=\"top\" bgcolor=\"#65889C\">";
    category();
    pollNewest();
    bigstory();
    searchbox();
    loginbox();
    userblock();
    oldNews($storynum);
    rightblocks();
    ephemblock();
    headlines();
    echo "</td>";
}
echo "</td></tr></table></td></tr></table>";
footmsg();
?>