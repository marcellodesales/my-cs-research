<html>
<head>
 <title> MIOLO - Classe context</title>
 <link rel="stylesheet" href="/miolo/doc/doc.css">
</head>
<body>
<? include '/usr/local/bis/html//miolo/doc/header.inc' ?>
<h2>Classe: Context</h2>
<blockquote>
extends <a href="#.class.php">SuperClasse</a>
</blockquote>
<p>TODO: Escrever documenta��o da classe Context.</p>
<h3>M�todos:</h3>
<dl>
 <dt><a href="/miolo/doc/miolo/context.Context.php">Context()</a></dt>
 <dd>Descri��o do m�todo Context. </dd>
 <dt><a href="/miolo/doc/miolo/context.Create.php">Create($module,$action,$item)</a></dt>
 <dd>Descri��o do m�todo Create. </dd>
 <dt><a href="/miolo/doc/miolo/context.GetAction.php">GetAction($index=0)</a></dt>
 <dd>Descri��o do m�todo GetAction. </dd>
 <dt><a href="/miolo/doc/miolo/context.ShiftAction.php">ShiftAction()</a></dt>
 <dd>Descri��o do m�todo ShiftAction. </dd>
 <dt><a href="/miolo/doc/miolo/context.PushAction.php">PushAction($a)</a></dt>
 <dd>Descri��o do m�todo PushAction. </dd>
 <dt><a href="/miolo/doc/miolo/context.ComposeURL.php">ComposeURL()</a></dt>
 <dd>Descri��o do m�todo ComposeURL. </dd>
</dl>
<p>&nbsp;</p>
<? include '/usr/local/bis/html//miolo/doc/footer.inc' ?>
</body>
</html>
