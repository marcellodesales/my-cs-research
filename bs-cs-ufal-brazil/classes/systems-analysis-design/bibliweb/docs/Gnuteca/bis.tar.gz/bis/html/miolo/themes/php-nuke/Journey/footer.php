<?PHP

if ($index == 1) {
    echo "<td>&nbsp;</td><td valign=\"top\">";
    searchbox();
    category();
    pollNewest();
    bigstory();
    loginbox();
    userblock();
    oldNews($storynum);
    rightblocks();
    echo "</td>";
}

?>

</td></tr></table></td></tr></table>

 </td>
      </tr>
    </table>
    <table border="0" width="100%" cellspacing="0" cellpadding="0">
      <tr>
        <td width="10%" valign="bottom"><img src="themes/Journey/corner3.gif" WIDTH="23" HEIGHT="19"></td>
        <td width="80%" valign="bottom"></td>
        <td width="10%" valign="bottom"><p align="right"><img src="themes/Journey/corner4.gif" WIDTH="23" HEIGHT="19"></td>
      </tr>
    </table>
    </td>
  </tr>
  
</table>
</center></div>
<?php
footmsg();
?>