<?
// Portal Gnutella Brasil http://portal.gnutella.com.br
// Mikhail Miguel <mikhail@gnutella.com.br>

if ($index == 1) {
	echo "</td><td>&nbsp;&nbsp;</td><td valign=\"top\" bgcolor=\"#FfFfFf\">";
	category();	
	pollNewest();
	loginbox();
	userblock();
	rightblocks();
	bigstory();
	oldNews($storynum);
	
	echo "</td>";
}


echo "
</td>
</tr>
</table>
</td>
</tr>
</table>
<hr width=\"96%\" noshade align=\"center\" size=\"1\">
<center>$slogan</center>";
footmsg();
?>
