<html>
<head>
 <title> MIOLO - miolo:GetActionURL</title>
 <link rel="stylesheet" href="/miolo/doc/doc.css">
</head>
<body>
<? include '/usr/local/bis/html//miolo/doc/header.inc' ?>
<h3 align="right">Classe: <a href="/miolo/doc/miolo/miolo.class.php">MIOLO</a></h3>
<h2>GetActionURL($module='',$action='NONE',$item='')</h2>
<p>TODO: Escrever documenta��o da fun��o GetActionURL.</p>
<h3>Par�metros:</h3>
<dl>
 <dt>$module</dt>
 <dd>Descri��o par�metro $module.</dd>
 <dt>$action</dt>
 <dd>Descri��o par�metro $action.</dd>
 <dt>$item</dt>
 <dd>Descri��o par�metro $item.</dd>
</dl>
<p>&nbsp;</p>
<pre>
<?php
highlight_string(
'<?php
    ...
    $miolo->GetActionURL($module,$action,$item); 
    ...
?>');
?>
</pre>
<? include '/usr/local/bis/html//miolo/doc/footer.inc' ?>
</body>
</html>
