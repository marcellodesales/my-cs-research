<?php

$thename = "Freshmeat";
$bgcolor1 = "#FFFFFF";
$bgcolor2 = "#000000";
$bgcolor3 = "#FFFFFF";
$bgcolor4 = "#e7e7e7";
$textcolor1 = "#FFFFFF";
$textcolor2 = "#000000";
$hr = 1; # 1 to have horizonal rule in comments instead of table bgcolor


function themeindex ($aid, $informant, $time, $title, $counter, $topic, $thetext, $notes, $morelink, $topicname, $topicimage, $topictext) {
	global $tipath, $anonymous;
	if ("$aid" == "$informant") { ?>

<TABLE bgColor=#000000 border=0 cellPadding=2 cellSpacing=0 width="100%">
 <TBODY>
  <TR>
   <TD colSpan=2>
    <TABLE bgColor=#ffffff border=0 cellPadding=3 cellSpacing=0 width="100%">
      <TBODY>
       <TR>
        <TD><FONT face=Lucida,Verdana,Helvetica,Arial><B>
	    <FONT size=+2><?php echo"$title"; ?></FONT></B><BR>
	    <SMALL><?php echo translate("Posted by "); ?> <b><?php formatAidHeader($aid) ?> </B> <?php echo translate("on"); ?> <?php echo"$time $timezone"; ?>(<?php echo $counter; ?> <?php echo translate("reads"); ?>)</SMALL><p>
	    <a href="search.php?query=&topic=<?php echo"$topic"; ?>&author="><img src=<?php echo"$tipath$topicimage"; ?> border=0 Alt=<?php echo"\"$topictext\""; ?> align=right hspace=10 vspace=10 border=0></a><br>
            <DIV align=justify>
              <P><?php echo"$thetext</P>
	    </DIV>
        </TD>
       </TR>
      </TBODY>
    </TABLE>
  </TD>
 </TR>
 <TR>
  <TD vAlign=center>&nbsp;
   <FONT face=Lucida,Verdana,Helvetica,Arial>
   <FONT color=#ffffff><B><SMALL>$morelink"; ?></SMALL></B>
   </FONT></FONT></TD>
  <TD align=right>&nbsp;</TD>
 </TR>
</TBODY>
</TABLE>
<HR SIZE=0 width=0>


<?php	} else {
		if($informant != "") $boxstuff = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
		else $boxstuff = "$anonymous ";
		$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes";
?>

<TABLE bgColor=#000000 border=0 cellPadding=2 cellSpacing=0 width="100%">
 <TBODY>
  <TR>
   <TD colSpan=2>
    <TABLE bgColor=#ffffff border=0 cellPadding=3 cellSpacing=0 width="100%">
      <TBODY>
       <TR>
        <TD><FONT face=Lucida,Verdana,Helvetica,Arial><B>
	    <FONT size=+2><?php echo"$title"; ?></FONT></B><BR>
	    <SMALL><?php echo translate("Posted by "); ?> <b><?php formatAidHeader($aid) ?> </B> <?php echo translate("on"); ?> <?php echo"$time $timezone"; ?>(<?php echo $counter; ?> <?php echo translate("reads"); ?>)</SMALL><p>
	    </SMALL><p>
	    <a href="search.php?query=&topic=<?php echo"$topic"; ?>&author="><img src=<?php echo"$tipath$topicimage"; ?> border=0 Alt=<?php echo"\"$topictext\""; ?> align=right hspace=10 vspace=10 border=0></a><br>
            <DIV align=justify>
              <P><?php echo"$boxstuff</P>
	    </DIV>
        </TD>
       </TR>
      </TBODY>
    </TABLE>
  </TD>
 </TR>
 <TR>
  <TD vAlign=center>&nbsp;
   <FONT face=Lucida,Verdana,Helvetica,Arial>
   <FONT color=#ffffff><B><SMALL>$morelink"; ?></SMALL></B>
   </FONT></FONT></TD>
  <TD align=right>&nbsp;</TD>
 </TR>
</TBODY>
</TABLE>
<HR SIZE=0 width=0>


<?php	}
}

function themearticle ($aid, $informant, $datetime, $title, $thetext, $topic, $topicname, $topicimage, $topictext) {
	global $admin, $sid, $tipath;
	if ("$aid" == "$informant") {

echo "
<TABLE bgColor=#000000 border=0 cellPadding=2 cellSpacing=0 width=100%>
 <TBODY>
  <TR>
   <TD colSpan=2>
    <TABLE bgColor=#ffffff border=0 cellPadding=3 cellSpacing=0 width=100%>
      <TBODY>
       <TR>
        <TD><FONT face=Lucida,Verdana,Helvetica,Arial><B>
	    <FONT size=+2>$title</FONT></B><BR>
	    <SMALL>";
?>	    <?php echo translate("Posted by "); ?> 
<?php 	    echo "<b>$aid</b> ".translate("on")." $datetime $timezone</SMALL><p>";
	    if ($admin) {
	        echo "&nbsp;&nbsp; $font2 [ <a href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]";
	    }
	    echo "<a href=search.php?query=&topic=$topic&author=><img src=$tipath$topicimage border=0 Alt=$topictext\ align=right hspace=10 vspace=10 border=0></a><br>
	    <DIV align=justify>
            <P>$thetext</P>
	    </DIV>
        </TD>
       </TR>
      </TBODY>
    </TABLE>
  </TD>
 </TR>
 <TR>
  <TD vAlign=center>&nbsp;
   <FONT face=Lucida,Verdana,Helvetica,Arial>
   <FONT color=#000000><B><SMALL>$morelink</SMALL></B>
   </FONT></FONT></TD>
  <TD align=right>&nbsp;</TD>
 </TR>
</TBODY>
</TABLE>
<HR SIZE=0 width=0>";

	} else {
		if($informant != "") $informant = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
		else $boxstuff = "$anonymous ";
		$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes";

echo "
<TABLE bgColor=#000000 border=0 cellPadding=2 cellSpacing=0 width=100%>
 <TBODY>
  <TR>
   <TD colSpan=2>
    <TABLE bgColor=#ffffff border=0 cellPadding=3 cellSpacing=0 width=100%>
      <TBODY>
       <TR>
        <TD><FONT face=Lucida,Verdana,Helvetica,Arial><B>
	    <FONT size=+2>$title</FONT></B><BR>
	    <SMALL>$font2 ".translate("Contributed by")." $informant ".translate("on")." $datetime</font></SMALL>";
	    if ($admin) {
	         echo "&nbsp;&nbsp; $font2 [ <a href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]";
	    }
	    echo "<a href=search.php?query=&topic=$topic&author=><img src=$tipath$topicimage border=0 Alt=$topictext\ align=right hspace=10 vspace=10 border=0></a><br>
            <DIV align=justify>
              <P>$thetext</P>
	    </DIV>
        </TD>
       </TR>
      </TBODY>
    </TABLE>
  </TD>
 </TR>
 <TR>
  <TD vAlign=center>&nbsp;
   <FONT face=Lucida,Verdana,Helvetica,Arial>
   <FONT color=#ffffff><B><SMALL>$morelink</SMALL></B>
   </FONT></FONT></TD>
  <TD align=right>&nbsp;</TD>
 </TR>
</TBODY>
</TABLE>
<HR SIZE=0 width=0>

";

	}
}

?>
