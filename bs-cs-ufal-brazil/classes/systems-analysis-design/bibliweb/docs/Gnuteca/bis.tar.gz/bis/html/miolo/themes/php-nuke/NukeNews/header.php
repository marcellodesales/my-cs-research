<?php
cookiedecode($user);
$username = $cookie[1];
if ($username == "") {
        $username = "Anonymous";
}
?>
<?php
echo "<body onload=init() topmargin=\"0\" leftmargin=\"0\" marginwidth=\"0\" marginheight=\"0\" bgcolor=\"#505050\" text=\"#000000\" link=\"#363636\" vlink=\"#363636\" alink=\"#d5ae83\">
<br>";
if ($banners) {
    include("banners.php");
}
echo "<br>


<TABLE cellpadding=0 cellspacing=0 width=\"95%\" border=\"0\" align=\"center\" bgcolor=\"#ffffff\">
<tr>
<td bgcolor=ffffff>
<IMG height=16 alt=\"\" hspace=0 src=\"themes/NukeNews/corner-top-left.gif\" width=17 align=left>
<img src=themes/NukeNews/logo3.jpg align=left></td>
<td bgcolor=999999><IMG src=\"themes/NukeNews/pixel.gif\" width=1 height=1 alt=\"\" border=0 hspace=0></td>
<td bgcolor=cfcfbb align=middle>
<CENTER><form action=\"search.php\" method=post><font size=2 color=\"#000000\"><b>".translate("Search")." </b>
<input type=name name=query size=\"14\"></font></form></CENTER></TD>
<td bgcolor=cfcfbb align=middle>
<CENTER><form action=\"search.php\" method=get><FONT size=2><B>".translate("Topics")." </B>";

    $toplist = mysql_query("select topicid, topictext from topics order by topictext");
    echo "<SELECT NAME=\"topic\"onChange='submit()'>" ;
    echo "<OPTION VALUE=\"\">".translate("All Topics")."</option>\n";
    while(list($topicid, $topics) = mysql_fetch_row($toplist)) {
    if ($topicid==$topic) { $sel = "selected "; }
	echo "<option $sel value=\"$topicid\">$topics</option>\n";
    $sel = "";
    }

echo "</SELECT></FONT></FORM></CENTER></TD>
<td bgcolor=cfcfbb valign=top><IMG height=17 alt=\"\" hspace=0 src=\"themes/NukeNews/corner-top-right.gif\" width=17 align=right></td>
</tr></table>

<TABLE cellpadding=0 cellspacing=0 width=\"95%\" border=\"0\" align=\"center\" bgcolor=\"#fefefe\">
<TR>
<TD bgcolor=\"#000000\" colspan=4><IMG src=\"themes/NukeNews/pixel.gif\" width=1 height=1 alt=\"\" border=0 hspace=0></TD>
        </TR>
        <TR valign=\"center\" bgcolor=\"#dedebb\">
<TD width=\"15%\" nowrap><font size=\"2\" color=\"#363636\"><b>";

if ($username == "Anonymous") {
    echo "&nbsp;&nbsp;<b><font color=#363636><a href=\"user.php\">Create</a></font> an account</b>";
}
else
{
    echo "&nbsp;&nbsp;Welcome $username!";
}
echo "
</b></font></TD>
<TD align=\"middle\" height=\"20\" width=70%><FONT size=\"2\"><B>
<A href=\"/\">Home</A>
&nbsp;&middot;&nbsp;
<A href=\"submit.php\">Submit</A>
&nbsp;&middot;&nbsp;
<A href=\"reviews.php\">Reviews</A>
&nbsp;&middot;&nbsp;
<A href=\"user.php\">Your Account</A>
&nbsp;&middot;&nbsp;
<A href=\"forum.php\">Forums</A>
&nbsp;&middot;&nbsp;
<A href=\"opendir.php\">Open Directory</A>
</B></FONT>
</TD>
<TD align=\"right\" width=\"15%\"><FONT size=\"2\"><b>
<script language=JavaScript>
      <!--   // Array ofmonth Names
      var monthNames = new Array( \"January\",\"February\",\"March\",\"April\",\"May\",\"June\",\"July\",\"August\",\"September\",\"October\",\"November\",\"December\");
      var now = new Date();
      thisYear = now.getYear();
      if(thisYear < 1900) {thisYear += 1900}; // corrections if Y2K display problem
      document.write(monthNames[now.getMonth()] + \" \" + now.getDate() + \", \" + thisYear);
      // --> 
</script></b></FONT></TD>
<td>&nbsp;</td>
</tr>";
?>

        <TR>
                <TD bgcolor="#000000" colspan=4><IMG src="themes/NukeNews/pixel.gif" width=1 height=1 alt="" border=0 hspace=0></TD>
        </TR>
        </TABLE>


<!-- FIN DEL TITULO -->

<table width="95%" cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff" align="center"><tr valign=top>
<td bgcolor=ffffff><img src=themes/NukeNews/pixel.gif width=1 height=20 border=0></td></tr></table>

<table width="95%" cellpadding="0" cellspacing="0" border="0" bgcolor="#ffffff" align="center"><tr valign=top>
<td bgcolor=ffffff><img src=themes/NukeNews/pixel.gif width=10 height=1 border=0></td>
<td bgcolor=ffffff width=150 valign=top>

<?php
mainblock();
online();
adminblock();
leftblocks();
ephemblock();
headlines();
?>
</td><td><img src=themes/NukeNews/pixel.gif width=15 height=1 border=0></td><td width=100%>
