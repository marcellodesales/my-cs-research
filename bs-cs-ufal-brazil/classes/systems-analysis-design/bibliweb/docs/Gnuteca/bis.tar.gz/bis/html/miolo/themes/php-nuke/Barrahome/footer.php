<?PHP

if ($index == 1) {
    echo "<td>&nbsp;</td><td valign=\"top\">";
    pollNewest();
    bigstory();
    loginbox();
    userblock();
    oldNews($storynum);
    rightblocks();
    echo "</td>";
}
echo "</td></tr></table></td></tr></table>";

?>