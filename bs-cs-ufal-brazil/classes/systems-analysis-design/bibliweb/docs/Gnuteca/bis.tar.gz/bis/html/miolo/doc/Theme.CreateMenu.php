<html>
<head>
 <title> MIOLO - Theme:CreateMenu</title>
 <link rel="stylesheet" href="doc.css">
</head>
<body>
<? include 'header.inc' ?>
<h3 align="right">Classe: <a href="Theme.class.php">Theme</a></h3>
<h2>CreateMenu($param1,$param2,$param3)</h2>
<p>TODO: Escrever documenta��o da fun��o CreateMenu.</p>
<h3>Par�metros:</h3>
<dl>
 <dt>$param1</dt>
 <dd>Descri��o par�metro 1. </dd>
 <dt>$param2</dt>
 <dd>Descri��o par�metro 2</dd>
 <dt>$param3</dt>
 <dd>Descri��o par�metro 3</dd>
</dl>
<p>&nbsp;</p>
<pre>
<?php
highlight_string(
'<?php
    ...
    CreateMenu(...); 
    ...
?>');
?>
</pre>
<? include 'footer.inc' ?>
</body>
</html>
