<?php

$thename = "LinuxCom";

$TablebgColor_A ="#000000";
$TablebgColor_B ="#FFFFFF";
$LinksTableRowColor = "#e9edf5";
$bgcolor1 = "#cccccc";
$bgcolor2 = "#e9edf5";
$bgcolor3 = "#e6e6e6";
$textcolor1 = "#FFFFFF";
$textcolor2 = "#000000";
$pollcolor = "#e9edf5";
$hr = 0; # 1 to have horizonal rule in comments instead of table bgcolor

function themefeature($fulltext)
{
?>
<!-- feature start -->
        <TABLE width="100%" cellpadding=0 cellspacing=0 border=0>
        <TR valign="bottom">
<TD align="left"><br><B>Feature Story</B><BR><IMG src="themes/LinuxCom/pixel.gif" height=3 width=1 alt=""></TD>
<TD align="right" width="1%"><IMG height=14 alt="" src="themes/LinuxCom/endcap-grey.gif" width=14></TD>
</tr>
<TR valign="bottom"><TD bgcolor="#cecece" width="100%" colspan=2><IMG src="themes/LinuxCom/pixel.gif" width=1 height=1 alt=""></TD></TR>
        </TABLE><P><FONT size="-1"><P align="center">
<P>
<FONT size="-1" color="#505050">
  <?php echo"$fulltext"; ?>
</FONT>
<P>
        <TABLE width="100%" cellpadding=0 cellspacing=0 border=0>
		<tr><td colspan=2 background="themes/LinuxCom/checkerboard.gif" height="1"><IMG src="themes/LinuxCom/pixel.gif" height="1" width="1" alt=""></TD></tr>
        <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
		<TR valign="bottom">
        <TD align="left"><B> News Articles </B><BR><IMG src="themes/LinuxCom/pixel.gif" height=3 width=1 alt=""></TD>
<TD align="right" width="1%"><IMG height=14 alt="" src="themes/LinuxCom/endcap.gif" width=15></TD>
</TR>
        <TR valign="bottom"><TD bgcolor="#000000" width="100%" colspan=2><IMG 
                src="themes/LinuxCom/pixel.gif" width=1 height=1
                alt=""></TD></TR>
        </TABLE>
		<br><p>
<?php
}

function themeindex ($aid, $informant, $time, $title, $counter, $topic, $thetext, $notes, $morelink, $topicname, $topicimage, $topictext) {
	if (!$config_called) {if (!isset($config)) {if (!isset($config)) { include("config.php"); }}}
	if ("$aid" == "$informant") { ?>
<!-- title -->
<table width=100% cellpadding=0 cellspacing=0 border=0>
<tr valign="bottom"><td align="left"><FONT color="#486591" scolor="#000000"><B><?php echo"$title"; ?></B></FONT><BR><IMG src="themes/LinuxCom/pixel.gif" height=3 width=1 alt=""><br></td>
<td align="right" width="1%"><IMG height=14 alt="" src="themes/LinuxCom/endcap-grey.gif" width=14></td></tr>
<TR valign="bottom"><TD bgcolor="#cecece" width="100%" colspan=2><IMG src="themes/LinuxCom/pixel.gif" width=1 height=1 alt=""></TD></TR>
</table>
<!-- topic -->
<FONT color="#999999"><B><a href="search.php?query=&topic=<?php echo"$topic"; ?>&author="><img src=<?php echo"$tipath$topicimage"; ?> border=0 Alt=<?php echo"\"$topictext\""; ?> align=right hspace=10 vspace=10></a></B></FONT>

<FONT size="-1" color="#505050"><P><?php echo"$thetext"; ?>
</FONT>

<DIV align="right">
<FONT color="#999999"><?php echo"$time $timezone"; ?> - <?php formatAidHeader($aid) ?>  </FONT>
<FONT size="-1" color="#cccccc"><I>&gt;&gt;</I></FONT><br>
<?php echo"$morelink"; ?>
<P></P></DIV>
<P>

<?php	} else {
		if($informant != "") $boxstuff = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
		else $boxstuff = "$anonymous ";
		$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i><br> $notes";
?>

<FONT color="#999999"><B><a href="search.php?query=&topic=<?php echo"$topic"; ?>&author="><img src=<?php echo"$tipath$topicimage"; ?> border=0 Alt=<?php echo"\"$topictext\""; ?> align=right hspace=10 vspace=10></a></B></FONT>
<!-- title -->
<FONT color="#486591" scolor="#000000"><B><?php echo"$title"; ?></B> <?php echo translate("Posted by "); ?><?php formatAidHeader($aid) ?></FONT><BR>
<FONT size="-1" color="#505050"><P>
      <?php echo"$time $timezone"; ?>&nbsp;&nbsp;&nbsp; [ <a href="search.php?query=&topic=<?php echo"$topic"; ?>&author="><b><?php echo"$topictext"; ?></b></a> ]<br>
      <?php echo"$boxstuff"; ?>
      </font>
<!-- end story block -->
<?php echo"$morelink"; ?>
<br>
<?php	}
}


function themearticle ($aid, $informant, $datetime, $title, $thetext, $topic, $topicname, $topicimage, $topictext) {
	if (!$config_called) {if (!isset($config)) {if (!isset($config)) { include("config.php"); }}}
	if ("$aid" == "$informant") {
echo"
<!-- article -->
<FONT color='#486591' scolor='#000000'><B>$title</B></FONT><BR>
".translate('Posted on')." $datetime ";
global $admin, $sid;
if ($admin) {
    echo "&nbsp;&nbsp; $font2 [ <a href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]";
}
echo "
<a href=search.php?query=&topic=$topic&author=><img src=$tipath$topicimage border=0 Alt=\"$topictext\" align=right hspace=10 vspace=10></a>
$thetext
<br>
";
	} else {
		if($informant != "") $informant = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
		else $boxstuff = "$anonymous ";
		$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes";
echo "
<b>$title</b><br><font face=Arial,Helvetica size=2>".translate("Contributed by ")." $informant ".translate("on")." $datetime</font>
";
global $admin, $sid;
if ($admin) {
    echo "&nbsp;&nbsp; $font2 [ <a href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]";
}
echo "
<a href=search.php?query=&topic=$topic&author=><img src=$tipath$topicimage border=0 Alt=\"$topictext\" align=right hspace=10 vspace=10></a>
$thetext
<br>
";

	}
}

function themesidebox($title, $content) {
     ?><br>
<!-- start side box -->
<TABLE width="100%" cellpadding=0 cellspacing=0 border=0>
<TR valign="bottom">
<TD align="left"><B><FONT color="#000000"><?php echo"$title"; ?></FONT></B><IMG src="pixel.gif" height=3 width=1 alt=""></TD>
<TD align="right" width="1%"><IMG height=14 alt="" src="themes/LinuxCom/endcap-grey.gif" width=14></TD>
</TR>
<TR valign="bottom"><TD bgcolor="#cecece" width="100%" colspan=2><IMG src="themes/LinuxCom/pixel.gif" width=1 height=1 alt=""></TD></TR>
<tr><td>
  <?php echo"$content"; ?>
</td></tr>
</TABLE>
<?php }
?>
