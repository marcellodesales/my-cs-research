<?php

$thename = "Barahome";
$lnkcolor = "FFFFFF";
$bgcolor1 = "006699";
$bgcolor2 = "006699";
$bgcolor3 = "CCCCCC";
$textcolor1 = "000000";
$textcolor2 = "FFFFFF";
$hr = 1; # 1 to have horizonal rule in comments instead of table bgcolor

function themeindex ($aid, $informant, $time, $title, $counter, $topic, $thetext, $notes, $morelink, $topicname, $topicimage, $topictext) {
    global $tipath, $anonymous;
    if ("$aid" == "$informant") { ?>
	<table border=0 cellpadding=0 cellspacing=0 align=center bgcolor=FFFFFF width=100%>
	<tr><td>
	<table border=0 cellpadding=3 cellspacing=1 width=100%>
	<tr><td bgcolor=006699>
	<b><?php echo"$title"; ?></b><br>
	<font size=1>
	<?php echo translate("Posted by "); ?> <b><?php formatAidHeader($aid) ?></b> <?php echo translate("on"); ?> <?php echo"$time $timezone"; ?> (<?php echo $counter; ?> <?php echo translate("reads"); ?>)
	<br></td></tr><tr><td bgcolor=8B8B64>
	<a href="search.php?query=&topic=<?php echo"$topic"; ?>&author="><img src=<?php echo"$tipath$topicimage"; ?> border=2 Alt=<?php echo"\"$topictext\""; ?> align=right hspace=10 vspace=10></a>
	<?php echo"$thetext<br><br>
	</td></tr><tr><td bgcolor=555555 align=right>
	<font size=2>$morelink"; ?>
	</td></tr></table></td></tr></table><br>

<?php	} else {

	if($informant != "") $boxstuff = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
	else $boxstuff = "$anonymous ";
	$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes";
?>
	<table border=0 cellpadding=0 cellspacing=0 align=center bgcolor=006699 width=100%>
	<tr><td>
	<table border=0 cellpadding=3 cellspacing=1 width=100%>
	<tr><td bgcolor=555555>
	<b><?php echo"$title"; ?></b><br>
	<font size=1>
	<?php echo translate("Posted by "); ?> <?php formatAidHeader($aid); ?> <?php echo translate("on"); ?> <?php echo"$time $timezone"; ?> (<?php echo $counter; ?> <?php echo translate("reads"); ?>)
	<br></td></tr><tr><td bgcolor=666666>
	<a href="search.php?query=&topic=<?php echo"$topic"; ?>&author="><img src=<?php echo"$tipath$topicimage"; ?> border=2 Alt=<?php echo"\"$topictext\""; ?> align=right hspace=10 vspace=10></a>
	<?php echo"$boxstuff<br><br>
	</td></tr><tr><td bgcolor=8B8B64 align=right>
	<font size=2>$morelink"; ?>
	</td></tr></table></td></tr></table><br>
<?php	}
}

function themearticle ($aid, $informant, $datetime, $title, $thetext, $topic, $topicname, $topicimage, $topictext) {
    global $admin, $sid, $tipath;
    if ("$aid" == "$informant") {
	echo"
	<table border=0 cellpadding=0 cellspacing=0 align=center bgcolor=006699 width=100%><tr><td>
	<table border=0 cellpadding=3 cellspacing=1 width=100%><tr><td bgcolor=555555>
	<b>$title</b><br><font size=2>".translate("Posted on ")." $datetime";
    if ($admin) {
	echo "&nbsp;&nbsp; <font size=2> [ <a href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]";
    }
    echo "
	</td></tr><tr><td bgcolor=666666>
	<a href=search.php?query=&topic=$topic&author=><img src=$tipath$topicimage border=2 Alt=\"$topictext\" align=right hspace=10 vspace=10></a>
	$thetext
	</td></tr></table></td></tr></table><br>";
    } else {
	if($informant != "") $informant = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
	else $boxstuff = "$anonymous ";
	$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes";
	echo "
	<table border=0 cellpadding=0 cellspacing=0 align=center bgcolor=000000 width=100%><tr><td>
	<table border=0 cellpadding=3 cellspacing=1 width=100%><tr><td bgcolor=555555>
	<b>$title</b><br><font size=2>".translate("Contributed by ")." $informant ".translate("on")." $datetime</font>
	";
    if ($admin) {
	echo "&nbsp;&nbsp; <font size=2>[ <a href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]";
    }
	echo "
	</td></tr><tr><td bgcolor=006666>
	<a href=search.php?query=&topic=$topic&author=><img src=$tipath$topicimage border=2 Alt=\"$topictext\" align=right hspace=10 vspace=10></a>
	<font size=3>$thetext</td></tr></table></td></tr></table><br>";
    }
}

function themesidebox($title, $content) {
    echo "
    <table border=0 cellspacing=0 cellpadding=0 width=100% bgcolor=000000><tr><td>
    <table width=100% border=0 cellspacing=1 cellpadding=3><tr><td colspan=1 bgcolor=555555>
    <font size=2>$title</td></tr><tr><td bgcolor=666666>
    <font size=2>$content</td></tr></table></td></tr></table><br>";
}

?>