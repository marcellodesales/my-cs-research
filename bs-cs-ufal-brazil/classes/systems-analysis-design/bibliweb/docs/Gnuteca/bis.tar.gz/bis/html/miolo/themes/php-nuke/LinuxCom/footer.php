<?PHP

if ($index == 1) {
?>
<TD width="16"><IMG src="themes/LinuxCom/pixel.gif" height="1" width="16" alt=""></TD>
<TD background="themes/LinuxCom/checkerboard.gif" width="1"><IMG src="themes/LinuxCom/pixel.gif" height="1" width="1" alt=""></TD>
<TD width="16"><IMG src="themes/LinuxCom/pixel.gif" height="1" width="8" alt=""></TD>
<?php
    echo "<td valign=\"top\">";
    category();
    pollNewest();
    bigstory(); 
    loginbox();
    userblock();
    oldNews($storynum);
    rightblocks();
    echo "</td>";
}

?>
<td width="10">&nbsp</td>
<tr>
<TD align="middle" height=17 colspan=11>
                <IMG height=17 alt="" hspace=0 src="themes/LinuxCom/roundcorner-bl.gif" width=17 align=left >
                <IMG height=17 alt="" hspace=0 src="themes/LinuxCom/roundcorner-br.gif" width=17 align=right >
        </TD>
      </TR>
    </TABLE>
	</td></tr></table>
<?php
footmsg();
?>