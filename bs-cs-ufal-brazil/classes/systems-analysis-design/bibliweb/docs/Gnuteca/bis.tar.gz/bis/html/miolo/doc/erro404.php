<?php
    
    include 'config.inc';
    
    /**
     *
     */
    function Introspect($path, &$classname)
    {   global $DOCUMENT_ROOT,$MIOLO_DOC;
        
        // echo "introspect('$path');\n<br>\n";
        
        $dir    = dirname($path);
        $classe = strtok(basename($path),'.');
        $file   = strtolower($path);
        
        if ( ! file_exists($file) )
          return $false;
        
        include $file;    
        
        // echo "Classe: $classe\n<br>\n";
        
        $classname = $classse;
        
        // $methods = get_class_methods($classname);
        
        $fp = fopen($file,'r');
                    
        while (! feof($fp))
        {
            $linha = chop(fgets($fp, 1024));
            
            if ( ! $methods )
            {
                if ( eregi("^ *class +([^ ]+)",$linha,$regs) )
                {
                  $classname = $regs[1];
                  
                  $methods = get_class_methods($classname);
                }
                
                continue;
            }
            
            if ( eregi("^ *class +",$linha) )
              break;
              
            if ( eregi("^ *extends +([^ ]+)",$linha,$regs) )
              $extends = $regs[1];            
            
            foreach ($methods as $m)
            {
                if ( eregi("^ *function +(($m) *\\(+.*\$)",$linha,$regs) )
                {
                  $struct[$regs[2]] = $regs[1];
                }
            }
        }
        
        fclose($fp);
        
        // informa��es adicionais
        $struct['.classname'] = $classname;
        
        if ( $extends )
          $struct['.extends'] = $extends;
        
        $fp = fopen(strtolower(".$classe.ser"),'w');
        fputs($fp,serialize($struct));
        fclose($fp);
        
        return $struct;
    }

    /**
     *
     */
    function MakeDirectories($path)
    {
        if ( ! is_dir($path) )
        {
            foreach ( explode('/',$path) as $d )
            {
                if ( $dir )
                    $dir .= '/';
                
                $dir .= $d;
                
                if ( ! is_dir($dir) )
                {
                    // echo "MkDir: '$dir'<br>\n";
                    
                    mkdir($dir,0777);
                }
            }
        }
    }
    
    $docbase = $MIOLO_DOC;
    
    $dir  = dirname($REQUEST_URI);
    $name = basename($REQUEST_URI);
    
    if ((substr($dir,0,strlen($docbase)) != $docbase) || (substr($name,-4) != '.php' ))
    {
        echo("<p><b>ERRO 404:</b> $REQUEST_URI n�o encontado! </p>");
        echo('<HR>');
        include('$DOCUMENT_ROOT/$MIOLO_DOC/index.php');
        exit;        
    }
    
    $dir = substr($dir,strlen($docbase)+1);
    
    if ( $dir != '' )
      MakeDirectories($dir);    
    
    $file = $dir . '/' . $name;

    $fp = fopen($file,'w');

    list($classe, $func, $ext) = explode('.',$name);

    if ($func == 'class')
    {
        $classname = $classe;
        $source    = $DOCUMENT_ROOT . '/' . $dir . '/' . $classe . '.class';
        
        $struct = introspect($source,&$classname);
        
        fputs($fp,"<html>\n");
        fputs($fp,"<head>\n");
        fputs($fp," <title> MIOLO - Classe $classe</title>\n"); 
        fputs($fp," <link rel=\"stylesheet\" href=\"$MIOLO_DOC/doc.css\">\n"); 
        fputs($fp,"</head>\n");
        fputs($fp,"<body>\n");
        fputs($fp,"<? include '$DOCUMENT_ROOT/$MIOLO_DOC/header.inc' ?>\n");
        fputs($fp,"<h2>Classe: $classname</h2>\n");
        fputs($fp,"<blockquote>\n");
        fputs($fp,"extends <a href=\"#.class.php\">SuperClasse</a>\n");
        fputs($fp,"</blockquote>\n");
        fputs($fp,"<p>TODO: Escrever documenta��o da classe $classname.</p>\n");
        fputs($fp,"<h3>M�todos:</h3>\n");
        fputs($fp,"<dl>\n");
        
        if ( $struct )
        {
            /*
            echo "<pre>\n";
            var_dump($struct);
            echo "</pre>\n";
            */
            
            $prefix = $MIOLO_DOC . '/' . $dir;
        
            foreach ( $struct as $mname => $mproto )
            {
              if ( substr($mname,0,1) == '.' )
                continue;
                
              fputs($fp, " <dt><a href=\"$prefix/$classe.$mname.php\">$mproto</a></dt>\n");
              fputs($fp, " <dd>Descri��o do m�todo $mname. </dd>\n");
            }
        }
        
        else
        {
            fputs($fp," <dt><a href=\"#\">foo()</a></dt>\n");
            fputs($fp," <dd>Descri��o do m�todo foo</dd>\n");
            fputs($fp," <dt><a href=\"#\">bar()</a></dt>\n");
            fputs($fp," <dd>Descri��o do m�todo bar</dd>\n");
            fputs($fp," <dt><a href=\"#\">rin()</a></dt>\n");
            fputs($fp," <dd>Descri��o do m�todo rin</dd>\n");
        }
        
        fputs($fp,"</dl>\n");
        fputs($fp,"<p>&nbsp;</p>\n");
        fputs($fp,"<? include '$DOCUMENT_ROOT/$MIOLO_DOC/footer.inc' ?>\n");
        fputs($fp,"</body>\n");
        fputs($fp,"</html>\n");
    }
    
    else
    {
        $classname = $classe;
        
        $sername = strtolower(".$classe.ser");
        
        if ( file_exists($sername) )
        {
          $ser = fopen($sername,'r');
          $struct = unserialize(fread($ser,filesize($sername)));
          fclose($ser);
          
          $classname = $struct['.classname'];        
        }
        
        fputs($fp,"<html>\n");
        fputs($fp,"<head>\n");
        fputs($fp," <title> MIOLO - $classe:$func</title>\n"); 
        fputs($fp," <link rel=\"stylesheet\" href=\"$MIOLO_DOC/doc.css\">\n"); 
        fputs($fp,"</head>\n");
        fputs($fp,"<body>\n");
        fputs($fp,"<? include '$DOCUMENT_ROOT/$MIOLO_DOC/header.inc' ?>\n");
        fputs($fp,"<h3 align=\"right\">Classe: <a href=\"$MIOLO_DOC/$dir/$classe.class.php\">$classname</a></h3>\n");
        
        if ( $struct )
        {
            fputs($fp,"<h2>$struct[$func]</h2>\n");
            fputs($fp,"<p>TODO: Escrever documenta��o da fun��o $func.</p>\n");
            
            $proto = $struct[$func];
            
            $p0 = strpos($proto,'(');
            $p1 = strpos($proto,')');
            
            $args = substr($proto,$p0+1,$p1-$p0-1);
            
            if ( $args )
            {
                fputs($fp,"<h3>Par�metros:</h3>\n");
                
                fputs($fp,"<dl>\n");
                
                foreach ( explode(',',$args) as $a )
                {
                  $a = strtok($a,'=');
                  
                  if ( $args2 )
                    $args2 .= ',';
                    
                  $args2 .= $a;
                  
                  fputs($fp," <dt>$a</dt>\n");
                  fputs($fp," <dd>Descri��o par�metro $a.</dd>\n");
                }
                
                fputs($fp,"</dl>\n");
            }
            
            fputs($fp,"<p>&nbsp;</p>\n");
            fputs($fp,"<pre>\n");
            fputs($fp,"<?php\n");
            fputs($fp,"highlight_string(\n");
            fputs($fp,"'<?php\n");
            fputs($fp,"    ...\n");
            fputs($fp,"    \${$classe}->{$func}($args2); \n");
            fputs($fp,"    ...\n");
            fputs($fp,"?>');\n");
            fputs($fp,"?>\n");
            fputs($fp,"</pre>\n");
        }
        
        else
        {
            fputs($fp,"<h2>$func(\$param1,\$param2,\$param3)</h2>\n");
            fputs($fp,"<p>TODO: Escrever documenta��o da fun��o $func.</p>\n");
            fputs($fp,"<h3>Par�metros:</h3>\n");
            fputs($fp,"<dl>\n");
            fputs($fp," <dt>\$param1</dt>\n");
            fputs($fp," <dd>Descri��o par�metro 1. </dd>\n");
            fputs($fp," <dt>\$param2</dt>\n");
            fputs($fp," <dd>Descri��o par�metro 2</dd>\n");
            fputs($fp," <dt>\$param3</dt>\n");
            fputs($fp," <dd>Descri��o par�metro 3</dd>\n");
            fputs($fp,"</dl>\n");
            fputs($fp,"<p>&nbsp;</p>\n");
            fputs($fp,"<pre>\n");
            fputs($fp,"<?php\n");
            fputs($fp,"highlight_string(\n");
            fputs($fp,"'<?php\n");
            fputs($fp,"    ...\n");
            fputs($fp,"    \${$classe}->{$func}(...); \n");
            fputs($fp,"    ...\n");
            fputs($fp,"?>');\n");
            fputs($fp,"?>\n");
            fputs($fp,"</pre>\n");
        }
        
        fputs($fp,"<? include '$DOCUMENT_ROOT/$MIOLO_DOC/footer.inc' ?>\n");
        fputs($fp,"</body>\n");
        fputs($fp,"</html>\n");        
    }

    fclose($fp);
    
    chmod($file,0777);
    
    include($file);
    
?>
