<html>
<head>
 <title> MIOLO - miolo:Assert</title>
 <link rel="stylesheet" href="/miolo/doc/doc.css">
</head>
<body>
<? include '/usr/local/bis/html//miolo/doc/header.inc' ?>
<h3 align="right">Classe: <a href="/miolo/doc/miolo/miolo.class.php">MIOLO</a></h3>
<h2>Assert($cond,$msg='',$goto='')</h2>
<p>TODO: Escrever documenta��o da fun��o Assert.</p>
<h3>Par�metros:</h3>
<dl>
 <dt>$cond</dt>
 <dd>Descri��o par�metro $cond.</dd>
 <dt>$msg</dt>
 <dd>Descri��o par�metro $msg.</dd>
 <dt>$goto</dt>
 <dd>Descri��o par�metro $goto.</dd>
</dl>
<p>&nbsp;</p>
<pre>
<?php
highlight_string(
'<?php
    ...
    $miolo->Assert($cond,$msg,$goto); 
    ...
?>');
?>
</pre>
<? include '/usr/local/bis/html//miolo/doc/footer.inc' ?>
</body>
</html>
