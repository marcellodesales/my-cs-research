<?php

if ($index == 1) {
    echo "</td><td><img src=\"themes/OpenTheme/pixel.gif\" width=15 height=1 border=0 alt=\"\"></td><td width=150>";
    category();
    pollNewest();
    bigstory(); 
    loginbox();
    userblock();
    oldNews($storynum);
    rightblocks();
}
echo "</td></tr></table>
<br><br>
<TABLE cellpadding=0 cellspacing=0 width=\"100%\" border=\"0\" align=\"center\" bgcolor=\"#fefefe\">
<TR><TD bgcolor=\"#000000\">
<IMG src=\"themes/OpenTheme/pixel.gif\" width=1 height=1 alt=\"\" border=0></TD>
</tr><tr>
<TD bgcolor=\"#FFFFFF\">
<IMG src=\"themes/OpenTheme/pixel.gif\" width=1 height=1 alt=\"\" border=0></TD>
</TR><TR valign=\"middle\" bgcolor=\"#d8ecea\">
<TD align=\"middle\" height=\"20\"><FONT size=\"2\">

<A href=\"pollBooth.php\">Surveys</A>&nbsp;&nbsp;&middot;&nbsp;
<A href=\"stats.php\">Web Stats</A>&nbsp;&nbsp;&middot;&nbsp;
<A href=\"topics.php\">Topics</A>&nbsp;&nbsp;&middot;&nbsp;
<A href=\"faq.php\">FAQ</A>

</FONT>
</TD></tr>";
?>

<TR>
<TD bgcolor="#cccccc"><IMG src="themes/OpenTheme/pixel.gif" width=1 height=1 alt="" border=0></TD>
</tr><tr>
<TD bgcolor="#000000"><IMG src="themes/OpenTheme/pixel.gif" width=1 height=1 alt="" border=0></TD>
</tr><tr><td background="themes/OpenMind/images/background.gif" height=120>
<?php
footmsg();
echo "</TR></TABLE>";
?>