<?php

echo "
</TD></TR><TR VALIGN=\"top\">
<BR><BR><BR>
<TD COLSPAN=\"3\" ALIGN=\"right\">
<TABLE WIDTH=\"\" CELLPADDING=\"0\"><TR><TD BGCOLOR=\"#000000\">
    <TABLE WIDTH=\"100%\" CELLPADDING=\"4\"><TR><TD BGCOLOR=\"#fefefe\">
	<FONT SIZE=\"-2\">
	$sitename - $slogan
	</FONT>
    </TD></TR></TABLE>
</TD></TR></TABLE>
</TD></TR></TABLE>
</CENTER>";
footmsg();
?>