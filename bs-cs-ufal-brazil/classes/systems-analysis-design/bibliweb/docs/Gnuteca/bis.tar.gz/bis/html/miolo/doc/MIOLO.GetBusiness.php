<html>
<head>
 <title> MIOLO - MIOLO:GetBusiness</title>
 <link rel="stylesheet" href="doc.css">
</head>
<body>
<? include 'header.inc' ?>
<h3 align="right">Classe: <a href="MIOLO.class.php">MIOLO</a></h3>
<h2>GetBusiness($module,$name='main')
</h2>
<p>TODO: Escrever documenta��o da fun��o GetBusiness.</p>
<h3>Par�metros:</h3>
<dl>
 <dt>$module</dt>
 <dd>Descri��o par�metro $module.</dd>
 <dt>$name</dt>
 <dd>Descri��o par�metro $name.</dd>
</dl>
<p>&nbsp;</p>
<pre>
<?php
highlight_string(
'<?php
    ...
    $MIOLO->GetBusiness($module,$name); 
    ...
?>');
?>
</pre>
<? include 'footer.inc' ?>
</body>
</html>
