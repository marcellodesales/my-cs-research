<?php
cookiedecode($user);
$uname = $cookie[1];
if ($uname == "") {
        $uname = "Anonymous";
}
?>
<script language="JavaScript">
<!--
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
// -->

function pviiClassNew(obj, new_style) {
    obj.className = new_style;
}
//-->
</script>
<body onload=init() text="#000000" bgcolor="#6699CC" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<br>
<?php
if ($banners) {
    include("banners.php");
}
?>
<br>
<table BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%" HEIGHT="100%" >
<tr BGCOLOR="#CCE6FF">
<td VALIGN=TOP ROWSPAN="2" BGCOLOR="#CCE6FF">
<table BORDER=0 CELLSPACING=0 CELLPADDING=0 HEIGHT="100%" >
<tr>
<td VALIGN=TOP><img src="themes/Butterflies/logo.gif" NAME="<? echo"$slogan"?>" ALT="<? echo"$slogan"?>" height=181 width=153></td>
</tr>
<tr>
<td VALIGN=TOP BGCOLOR="#6699CC">
<?php

mainblock();
adminblock();
leftblocks();
ephemblock();
headlines();

?>
</td>
</tr>
<tr>
<td ALIGN=CENTER BGCOLOR="#336699">

</td>
</tr>

<tr>
<td ALIGN=CENTER VALIGN=TOP BGCOLOR="#6699CC"><img src="themes/Butterflies/navtop.gif" height=20 width=153></td>
</tr>

<tr>
<td ALIGN=LEFT VALIGN=BOTTOM HEIGHT="100%"><img src="themes/Butterflies/decor.gif" height=87 width=153></td>
</tr>
</table>

</td>
<td VALIGN=TOP WIDTH="100%" colspan=2>

<table BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%" HEIGHT="83" >

<tr BGCOLOR="#CCE6FF">
<td HEIGHT="80"><a href="<? echo"$nuke_url"?>"><img src="themes/Butterflies/name.gif" ALT="<? echo"$slogan"?>" BORDER=0 height=80 width=276></a></td>
<td ALIGN=RIGHT HEIGHT="80"><img src="themes/Butterflies/corner.jpg" ALT="Butterflies" height=80 width=220></td>
</tr>

<tr BGCOLOR="#336699">
<td COLSPAN="2" HEIGHT="3"><img src="themes/Butterflies/spacer.gif" height=3 width=1></td>
</tr>

</table>

</td>
</tr>

<tr>
<td ALIGN=LEFT VALIGN=TOP width="80%" BGCOLOR="#FFFFFF">

