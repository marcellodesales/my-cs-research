<html>
<head>
 <title> MIOLO - Classe database</title>
 <link rel="stylesheet" href="/miolo/doc/doc.css">
</head>
<body>
<? include '/usr/local/bis/html//miolo/doc/header.inc' ?>
<h2>Classe: Database</h2>
<blockquote>
extends <a href="#.class.php">SuperClasse</a>
</blockquote>
<p>TODO: Escrever documenta��o da classe Database.</p>
<h3>M�todos:</h3>
<dl>
 <dt><a href="/miolo/doc/miolo/database.Database.php">Database($host,$db,$user,$pass)</a></dt>
 <dd>Descri��o do m�todo Database. </dd>
 <dt><a href="/miolo/doc/miolo/database.Close.php">Close()</a></dt>
 <dd>Descri��o do m�todo Close. </dd>
 <dt><a href="/miolo/doc/miolo/database.GetErrors.php">GetErrors()</a></dt>
 <dd>Descri��o do m�todo GetErrors. </dd>
 <dt><a href="/miolo/doc/miolo/database.Execute.php">Execute($sql)</a></dt>
 <dd>Descri��o do m�todo Execute. </dd>
 <dt><a href="/miolo/doc/miolo/database.ExecuteBatch.php">ExecuteBatch($sql_array)</a></dt>
 <dd>Descri��o do m�todo ExecuteBatch. </dd>
 <dt><a href="/miolo/doc/miolo/database.Query.php">Query($sql,$maxrows=0)</a></dt>
 <dd>Descri��o do m�todo Query. </dd>
 <dt><a href="/miolo/doc/miolo/database.QueryChunk.php">QueryChunk($sql, $maxrows, $offset, &$total)</a></dt>
 <dd>Descri��o do m�todo QueryChunk. </dd>
</dl>
<p>&nbsp;</p>
<? include '/usr/local/bis/html//miolo/doc/footer.inc' ?>
</body>
</html>
