<?
  include_once 'grid.class';

  if (strtoupper(substr(PHP_OS, 0, 3)) == 'WIN')
    dl('php_gtk.dll');
  else
    dl('php_gtk.so');

  $grade = new Grid('Teste da grade', array("C�digo", "T�tulo", "Autor"), 600, 100);

  $Contents[] = array("001", "aaaaaa", "AAAAAAAA");
  $Contents[] = array("002", "bbbbbc", "BBBBBBBB");
  $Contents[] = array("003", "cccccc", "CCCCCCCC");

  $grade->AdicionaLinhas($Contents);
  $grade->Exibe();
  Gtk::main();

?>