<?
// -----------------------------------------------------------
// Purpose: Checks a field value for valid content. This
//          function is mainly for convenience in order to
//          generate a standardized message for an invalid
//          field input.
//
//          When $cond is false, the function generates an
//          error message and does not return from execution.
// -----------------------------------------------------------
function CheckFormParameters($list)
{
  $n = count($list);

  for ( $i=0; $i<$n; $i++ )
  {
    $name  = $list[$i];

    if ( !$name )
      continue;

    $value = $GLOBALS[$name];

    if ( empty($value) )
    {
      $msg = "Campo obrigat�rio [<b><i>$name</i></b>] n�o informado!";
    }
  }
}
?>