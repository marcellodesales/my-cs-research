<html>
<head>
 <title> MIOLO - Classe miolo</title>
 <link rel="stylesheet" href="/miolo/doc/doc.css">
</head>
<body>
<? include '/usr/local/bis/html//miolo/doc/header.inc' ?>
<h2>Classe: MIOLO</h2>
<blockquote>
extends <a href="#.class.php">SuperClasse</a>
</blockquote>
<p>TODO: Escrever documenta��o da classe MIOLO.</p>
<h3>M�todos:</h3>
<dl>
 <dt><a href="/miolo/doc/miolo/miolo.MIOLO.php">MIOLO($home=null,$db='sagu')</a></dt>
 <dd>Descri��o do m�todo MIOLO. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.SetDatabase.php">SetDatabase($db)</a></dt>
 <dd>Descri��o do m�todo SetDatabase. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.Assert.php">Assert($cond,$msg='',$goto='')</a></dt>
 <dd>Descri��o do m�todo Assert. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.SetTheme.php">SetTheme($theme)</a></dt>
 <dd>Descri��o do m�todo SetTheme. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.GetActionURL.php">GetActionURL($module='',$action='NONE',$item='')</a></dt>
 <dd>Descri��o do m�todo GetActionURL. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.CheckLogin.php">CheckLogin()</a></dt>
 <dd>Descri��o do m�todo CheckLogin. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.CheckAccess.php">CheckAccess($module, $access, $deny=false)</a></dt>
 <dd>Descri��o do m�todo CheckAccess. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.GetRights.php">GetRights($module, $login)</a></dt>
 <dd>Descri��o do m�todo GetRights. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.GetUsersAllowed.php">GetUsersAllowed($module, $action)</a></dt>
 <dd>Descri��o do m�todo GetUsersAllowed. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.GetLogin.php">GetLogin()</a></dt>
 <dd>Descri��o do m�todo GetLogin. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.SetLogin.php">SetLogin($login)</a></dt>
 <dd>Descri��o do m�todo SetLogin. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.Uses.php">Uses($name,$module=null)</a></dt>
 <dd>Descri��o do m�todo Uses. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.GetDatabase.php">GetDatabase($other=null)</a></dt>
 <dd>Descri��o do m�todo GetDatabase. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.GetBusiness.php">GetBusiness($module,$name='main')</a></dt>
 <dd>Descri��o do m�todo GetBusiness. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.GetLookup.php">GetLookup($module)</a></dt>
 <dd>Descri��o do m�todo GetLookup. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.GetAutoComplete.php">GetAutoComplete($module,$item,$hint)</a></dt>
 <dd>Descri��o do m�todo GetAutoComplete. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.GetUI.php">GetUI()</a></dt>
 <dd>Descri��o do m�todo GetUI. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.GetAbsolutePath.php">GetAbsolutePath($rel=null)</a></dt>
 <dd>Descri��o do m�todo GetAbsolutePath. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.GetAbsoluteURL.php">GetAbsoluteURL($rel,$module=null)</a></dt>
 <dd>Descri��o do m�todo GetAbsoluteURL. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.GetModulePath.php">GetModulePath($module,$file)</a></dt>
 <dd>Descri��o do m�todo GetModulePath. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.Error.php">Error($msg='',$goto='')</a></dt>
 <dd>Descri��o do m�todo Error. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.Information.php">Information($msg,$goto='')</a></dt>
 <dd>Descri��o do m�todo Information. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.Confirmation.php">Confirmation($msg,$gotoOK='',$gotoCancel='')</a></dt>
 <dd>Descri��o do m�todo Confirmation. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.Question.php">Question($msg,$gotoYes='',$gotoNo='')</a></dt>
 <dd>Descri��o do m�todo Question. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.Prompt.php">Prompt($prompt)</a></dt>
 <dd>Descri��o do m�todo Prompt. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.LogSQL.php">LogSQL($sql,$force=false)</a></dt>
 <dd>Descri��o do m�todo LogSQL. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.LogError.php">LogError($error)</a></dt>
 <dd>Descri��o do m�todo LogError. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.ProfileTime.php">ProfileTime()</a></dt>
 <dd>Descri��o do m�todo ProfileTime. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.ProfileEnter.php">ProfileEnter($name)</a></dt>
 <dd>Descri��o do m�todo ProfileEnter. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.ProfileExit.php">ProfileExit($name)</a></dt>
 <dd>Descri��o do m�todo ProfileExit. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.ProfileDump.php">ProfileDump()</a></dt>
 <dd>Descri��o do m�todo ProfileDump. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.UsesDump.php">UsesDump()</a></dt>
 <dd>Descri��o do m�todo UsesDump. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.Dump.php">Dump($var,$info=null)</a></dt>
 <dd>Descri��o do m�todo Dump. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.Trace.php">Trace($msg)</a></dt>
 <dd>Descri��o do m�todo Trace. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.TraceDump.php">TraceDump()</a></dt>
 <dd>Descri��o do m�todo TraceDump. </dd>
 <dt><a href="/miolo/doc/miolo/miolo.InvokeHandler.php">InvokeHandler($module,$name)</a></dt>
 <dd>Descri��o do m�todo InvokeHandler. </dd>
 <dt><a href="/miolo/doc/miolo/miolo._InvokeHandler.php">_InvokeHandler($module,$name)</a></dt>
 <dd>Descri��o do m�todo _InvokeHandler. </dd>
</dl>
<p>&nbsp;</p>
<? include '/usr/local/bis/html//miolo/doc/footer.inc' ?>
</body>
</html>
