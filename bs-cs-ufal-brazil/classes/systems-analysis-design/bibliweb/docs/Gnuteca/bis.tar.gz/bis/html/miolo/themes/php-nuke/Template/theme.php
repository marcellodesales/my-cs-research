<?php

/*****************************************************************/
/* Colors variables valid only for this theme                    */
/* Used for site's tables border, backgrounds, textcolor, etc.   */
/*****************************************************************/

$bgcolor1   = "#FFFFFF";
$bgcolor2   = "#CCCCCC";
$bgcolor3   = "#FFFFFF";
$bgcolor4   = "#EEEEEE";
$textcolor1 = "#FFFFFF";
$textcolor2 = "#000000";

/*****************************************************************/
/* Function themeindex() is to create the article box displayed  */
/* on home                                                       */
/*                                                               */
/* $aid = Administrator ID                                       */
/* $informant = Who sent the story                               */
/* $time = Published date                                        */
/* $title = Article Title                                        */
/* $counter = Reads counter                                      */
/* $topic = Topic ID to parse to search.php                      */
/* $thetext = The story text (All)                               */
/* $notes = Webmaster notes                                      */
/* $morelink = Bar to show "read more", "comment?" links etc.    */
/* $topicname = One word topic name                              */
/* $topicimage = Image file name for this topic                  */
/* $topictext = Topic full text                                  */
/* $anonymous = Anonymous user name                              */
/* $tipath = Path to topics images directory                     */
/*****************************************************************/

function themeindex ($aid, $informant, $time, $title, $counter, $topic, $thetext, $notes, $morelink, $topicname, $topicimage, $topictext) {
    global $tipath, $anonymous;
    echo "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\" bgcolor=\"#000000\" width=\"100%\"><tr><td>"
	."<table border=\"0\" cellpadding=\"3\" cellspacing=\"1\" width=\"100%\"><tr><td bgcolor=\"#FFFFFF\">"
	."<b>$title</b><br>"
	."<font size=\"1\">"
	."".translate("Posted by ")."<b>";
	formatAidHeader($aid);
	echo "</b> ".translate("on")." $time $timezone ($counter ".translate("reads").")<br>";
    if ($aid == $informant) {
	$boxstuff = "$thetext";
    } else {
	if ($informant != "") {
	    $boxstuff = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
	} else {
	    $boxstuff = "$anonymous ";
	}
	$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes";
    }
    echo "<b>".translate("Topic").":</b> <a href=\"search.php?query=&topic=$topic\">$topictext</a><br>"
	."</td></tr><tr><td bgcolor=\"#FFFFFF\">"
	."<a href=\"search.php?query=&topic=$topic\"><img src=\"$tipath$topicimage\" Alt=\"$topictext\" align=\"right\" border=\"0\"></a>"
	."$boxstuff<br><br>"
	."</td></tr><tr><td bgcolor=\"#FFFFFF\" align=\"right\">"
	."<font size=2>$morelink"
	."</td></tr></table></td></tr></table><br>";
}

/*****************************************************************/
/* Function themearticle() is to create the article page, shown  */
/* when you click on "comments" or "read more" link from home    */
/*****************************************************************/


function themearticle ($aid, $informant, $datetime, $title, $thetext, $topic, $topicname, $topicimage, $topictext) {
    global $admin, $sid, $tipath;
    echo "<table border=0 cellpadding=0 cellspacing=0 align=center bgcolor=000000 width=100%><tr><td>"
	."<table border=0 cellpadding=3 cellspacing=1 width=100%><tr><td bgcolor=FFFFFF>"
	."<b>$title</b><br><font size=1>".translate("Posted on ")." $datetime";
    if ($admin) {
        echo "&nbsp;&nbsp;[ <a href=\"admin.php?op=EditStory&sid=$sid\">".translate("Edit")."</a> | <a href=\"admin.php?op=RemoveStory&sid=$sid\">".translate("Delete")."</a> ]";
    }
    echo "<br>".translate("Topic").": <a href=\"search.php?query=&topic=$topic&author=\">$topictext</a>"
	."</td></tr><tr><td bgcolor=ffffff>";
    if ($aid == $informant) {
	$boxstuff = "$thetext";
    } else {
	if($informant != "") {
	    $boxstuff = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
	} else {
	    $boxstuff = "$anonymous ";
	}
	$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes";
    }
    echo "<a href=\"search.php?query=&topic=$topic\"><img src=\"$tipath$topicimage\" Alt=\"$topictext\" align=\"right\" border=\"0\"></a>"
	."$boxstuff";
    echo "</td></tr></table></td></tr></table><br>";
}

/*****************************************************************/
/* Function themesidebox() is to create left and right boxes on  */
/* the site                                                      */
/*****************************************************************/

function themesidebox($title, $content) {
    echo "<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\" bgcolor=\"#000000\"><tr><td>"
	."<table width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"3\"><tr><td bgcolor=\"#FFFFFF\">"
	."<font size=\"2\">$title</td></tr><tr><td bgcolor=\"#FFFFFF\"><font size=\"2\">"
	."$content"
	."</td></tr></table></td></tr></table><br>";
}

?>