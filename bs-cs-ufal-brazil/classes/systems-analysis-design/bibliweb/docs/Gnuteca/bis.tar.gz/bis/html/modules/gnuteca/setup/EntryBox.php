<?
function strToInt($conteudo)
{
  for($n=0; $n<=strlen($conteudo); $n++)
  {
    $letrinha = substr($conteudo,$n,1);
    if (eregi("^[_0-9-]+)*", $letrinha))
      $retorno .= $letrinha;
  }
  return $retorno;
}

/*******************************************************************************/
/* Cria Caixa com bot�es para consulta
/*******************************************************************************/
function CreateEntryBox(&$field, $max_lenght, $horizontal, $title, $spacing, $child_w, $child_h, $layout)
{
  $frame = &new GtkFrame($title);
  if ($horizontal)
    $bbox = &new GtkHButtonBox();
  else
    $bbox = &new GtkVButtonBox();

  $bbox->set_border_width(5);
  $bbox->set_layout($layout);
  $bbox->set_spacing($spacing);
  $bbox->set_child_size($child_w, $child_h);
  $frame->add($bbox);
  $bbox->show();

  $field->set_text('');
  $field->set_max_length($max_lenght);
  $bbox->pack_start($field, false, true);
  $field->show();

  $frame->show();
  return $frame;
}
?>