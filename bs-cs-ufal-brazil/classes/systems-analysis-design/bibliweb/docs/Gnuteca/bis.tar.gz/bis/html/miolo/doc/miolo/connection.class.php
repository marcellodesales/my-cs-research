<html>
<head>
 <title> MIOLO - Classe connection</title>
 <link rel="stylesheet" href="/miolo/doc/doc.css">
</head>
<body>
<? include '/usr/local/bis/html//miolo/doc/header.inc' ?>
<h2>Classe: Connection</h2>
<blockquote>
extends <a href="#.class.php">SuperClasse</a>
</blockquote>
<p>TODO: Escrever documenta��o da classe Connection.</p>
<h3>M�todos:</h3>
<dl>
 <dt><a href="/miolo/doc/miolo/connection.Connection.php">Connection()</a></dt>
 <dd>Descri��o do m�todo Connection. </dd>
 <dt><a href="/miolo/doc/miolo/connection.Open.php">Open($dbhost,$LoginDB,$LoginUID,$LoginPWD,$persistent=true)</a></dt>
 <dd>Descri��o do m�todo Open. </dd>
 <dt><a href="/miolo/doc/miolo/connection.Close.php">Close()</a></dt>
 <dd>Descri��o do m�todo Close. </dd>
 <dt><a href="/miolo/doc/miolo/connection.Begin.php">Begin()</a></dt>
 <dd>Descri��o do m�todo Begin. </dd>
 <dt><a href="/miolo/doc/miolo/connection.Finish.php">Finish()</a></dt>
 <dd>Descri��o do m�todo Finish. </dd>
 <dt><a href="/miolo/doc/miolo/connection.GetError.php">GetError()</a></dt>
 <dd>Descri��o do m�todo GetError. </dd>
 <dt><a href="/miolo/doc/miolo/connection.GetErrors.php">GetErrors()</a></dt>
 <dd>Descri��o do m�todo GetErrors. </dd>
 <dt><a href="/miolo/doc/miolo/connection.GetErrorCount.php">GetErrorCount()</a></dt>
 <dd>Descri��o do m�todo GetErrorCount. </dd>
 <dt><a href="/miolo/doc/miolo/connection.CheckError.php">CheckError()</a></dt>
 <dd>Descri��o do m�todo CheckError. </dd>
 <dt><a href="/miolo/doc/miolo/connection.Execute.php">Execute($sql)</a></dt>
 <dd>Descri��o do m�todo Execute. </dd>
 <dt><a href="/miolo/doc/miolo/connection.CreateQuery.php">CreateQuery($sql="")</a></dt>
 <dd>Descri��o do m�todo CreateQuery. </dd>
</dl>
<p>&nbsp;</p>
<? include '/usr/local/bis/html//miolo/doc/footer.inc' ?>
</body>
</html>
