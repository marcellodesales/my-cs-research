<?
  // Toggles
  $show_poll = 1;  	          // toggles the poll on/off
  $show_slogan_bar = 1;       // toggles the slogan-bar

  // some paths
  $theme_path = "themes/Savage/";
  $image_path = $theme_path . "images/";

  // the window corners
  $corner_top_left     = $image_path . "pix.gif";
  $corner_top_right    = $image_path . "pix.gif";
  $corner_bottom_left  = $image_path . "pix.gif";
  $corner_bottom_right = $image_path . "pix.gif";

  // the window edges
  $bar_left    = $image_path . "pix.gif";
  $bar_right   = $image_path . "pix.gif";
  $bar_top     = $image_path . "pix.gif";
  $bar_bottom  =$image_path . "pix.gif";
  
  // some background images
  $background1 = $image_path . "background1.jpg";
  $background2 = $image_path . "background2.jpg";
  $background3 = $image_path . "background3.jpg";

  // images
  $logo = $image_path . "conan-logo.jpg";
  $logo2= $image_path . "conan-image2.jpg";
  $display_shadow = 1;     // 1 for yes, 0 for no
  $shadow = $image_path . "shadow.jpg";
  
  // Use IE style for nice borders
  $ie_style = 1;
  $style_type = 'groove';
  $style_height = 11;
  
  // font sizes
  $fontsize1 = 3;
  $fontsize2 = 2;
  $fontsize3 = 1;
  
  // change textcolor for lighter or darker backgrounds
  $textcolor1 = "000000";  
  $textcolor2 = "000000";  
  
  // the width of the menu and left boxes
  $themesidebox_width = "150";
  
  // other physical measurements
  $c_width  = 1;  // window corner width
  $c_height = 1;  // window corner height
  $l_width  = 1;  // left edge width
  $r_width  = 1;  // right edge width
  $t_height = 1;  // top bar height
  $b_height = 1;  // bottom bar height
?>