<?php
    
    // header ("Cache-Control: no-cache, must-revalidate");  // HTTP/1.1
    // header ("Pragma: no-cache");                          // HTTP/1.0
    header ("Cache-Control: cache");  // HTTP/1.1
    
    include_once 'miolo/miolo.php';    
            
    $MIOLO->Trace("HTTP_REFERER='" . getenv("HTTP_REFERER") . "'<br>\n");
    
    $MIOLO->Uses('ui/lookuptheme.class');
    $MIOLO->Uses('ui/listing.class');
    $MIOLO->Uses('ui/form.class');
    $MIOLO->Uses('ui/pagenavigator.class');
    
    $lookup = $MIOLO->GetLookup($module); 
    
    $theme = new LookupTheme();
    
    $MIOLO->SetTheme($theme);
    
    $ok = $MIOLO->InvokeHandler($module,'lookup');
    
    if ( ! $ok )      
        $MIOLO->Error("Module '$module' n�o definido!");
    
    $theme->Generate();    
?>
