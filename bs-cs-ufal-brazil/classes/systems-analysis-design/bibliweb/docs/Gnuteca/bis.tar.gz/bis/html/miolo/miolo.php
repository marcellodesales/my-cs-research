<?php
// +-----------------------------------------------------------------+
// | MIOLO - Miolo Development Team - UNIVATES Centro Universit�rio  |
// +-----------------------------------------------------------------+
// | Copyleft (l) 2001 UNIVATES, Lajeado/RS - Brasil                 |
// +-----------------------------------------------------------------+
// | Licensed under GPL: see COPYING.TXT or FSF at www.fsf.org for   |
// |                     further details                             |
// |                                                                 |
// | Site: http://miolo.codigoaberto.org.br                          |
// | E-mail: vgartner@univates.br                                    |
// |         ts@interact2000.com.br                                  |
// +-----------------------------------------------------------------+
// | Abstract: This file starts all the process                      |
// |                                                                 |
// | Created: 2001/08/14 Thomas Spriestersbach                       |
// |                     Vilson Cristiano G�rtner,                   |
// |                                                                 |
// | History: Initial Revision                                       |
// +-----------------------------------------------------------------+

    include_once 'miolo/login.class';
    include_once 'miolo/miolo.conf';
    include_once 'miolo/miolo.class';
    
    session_start();
    session_register('login');
    
    $MIOLO  = new MIOLO;
    
    $MIOLO->SetLogin($login);
    
    $login = $MIOLO->GetLogin();
    
    $MIOLO->Dump($login);
    
    if ( $MIOLOCONF['login']['check'] && ! $login )
    {
        $auto = $MIOLOCONF['login']['auto'];
        
        if ( $auto )
        {
            $login = new Login($MIOLOCONF['login'][$auto]['id'],
                               $MIOLOCONF['login'][$auto]['password'],
                               $MIOLOCONF['login'][$auto]['name']);
            
            $MIOLO->SetLogin($login);
        }
    }
    
    $MIOLO->ProfileEnter('miolo.php');
    
    $MIOLO->CheckLogin();
    
    $theme = $MIOLO->GetTheme();
    
    //
    // Obtain Context Object
    //
    
    $context = new Context();
    
    // gettext placeholder
    // if you compiled php with support for gettext
    // comment the next line
    if ( ! function_exists('_') )
    {
        // function _($t) { return '[' . $t . ']'; }
        function _($t) { return $t; }
        // _('bom dia');
    }
?>
