<?php
cookiedecode($user);
$username = $cookie[1];
if ($username == "") {
        $username = "Anonymous";
}
?>
<body onload=init() topmargin="0" leftmargin="0" marginwidth="0" marginheight="0" bgcolor="#505050" text="#000000" link="#3661a1" vlink="#6f6c81" alink="#d5ae83">
<br>
<?php
if ($banners) {
    include("banners.php");
}
?>
<br>
<TABLE cellpadding=0 cellspacing=0 width="95%" border="0" align="center" bgcolor="#fefefe">
<TR valign="top" bgcolor="#eeeeee">
<TD align="middle" bgcolor="#ffffff" background="themes/LinuxCom/streamline-bg.gif">
<IMG height=16 alt="" hspace=0 src="themes/LinuxCom/roundcorner-tl.gif" width=17 align=left >
<A href="/"><IMG alt="<?php echo $sitename ?>" hspace=0 src="themes/LinuxCom/title.gif" vspace=4 border=0></A></TD>
<TD bgcolor="#999999"><IMG src="themes/LinuxCom/pixel.gif" width=1 height=1 alt="" border=0 hspace=0></TD>
<TD align="middle">
<CENTER><form action="search.php" method=post><font size="-1" color="#000000"><br><b><?php echo "".translate("Search").""; ?> <?php echo $sitename ?></b><br>
<input type=name name=query size="14"></font></form></CENTER></TD>
<TD align="middle">
<IMG height=17 alt="" hspace=0 src="themes/LinuxCom/roundcorner-tr.gif" width=17 align=right >
<CENTER><form action="search.php" method=get><FONT size="-1"><BR><B><?php echo "".translate("Search").""; ?></B> Topic:<BR>
<!-- Topic Selection -->
<?php
    $toplist = mysql_query("select topicid, topictext from topics order by topictext");
    echo "<SELECT NAME=\"topic\"onChange='submit()'>" ;
    echo "<OPTION VALUE=\"\">".translate("All Topics")."</option>\n";
    while(list($topicid, $topics) = mysql_fetch_row($toplist)) {
    if ($topicid==$topic) { $sel = "selected "; }
	echo "<option $sel value=\"$topicid\">$topics</option>\n";
    $sel = "";
    }
    echo "</SELECT>";
?>
 </FONT></FORM></CENTER>
        </TD>
        </TR>
</TABLE>
        <TABLE cellpadding=0 cellspacing=0 width="95%" border="0" align="center" bgcolor="#fefefe">
        <TR>
                <TD bgcolor="#000000" colspan=6><IMG src="themes/LinuxCom/pixel.gif" width=1 height=1 alt="" border=0 hspace=0></TD>
        </TR>
        <TR valign="center" bgcolor="#e9edf5">
<TD width="28%" nowrap><font size="-1" color="#3661a1"><b>
<?php
if ($username == "Anonymous") {
    echo "<b>(Why not <font color=#3661a1><a href=\"user.php\">sign up</a></font> for an account?*)</b>";
}
else
{
    echo "Welcome $username";
}
?>
</b></font></TD>
<TD align="middle" height="20" colspan=2 nowrap><FONT size="-1"><B>
<A href="/">Home</A>
::
<A href="submit.php">Submit</A>
::
<A href="links.php">Links!</A>
::
<A href="user.php">Prefs</A>
::
<A href="?theme=.print">Print*</A>
::
<A href="sections.php">Sections</A>
</B></FONT>
</TD>
<TD align="right" width="25%" colspan=2 nowrap><FONT size="-1"><b>
<script language=JavaScript>
      <!--   // Array ofmonth Names
      var monthNames = new Array( "January","February","March","April","May","June","July","August","September","October","November","December");
      var now = new Date();
      thisYear = now.getYear();
      if(thisYear < 1900) {thisYear += 1900}; // corrections if Y2K display problem
      document.write(monthNames[now.getMonth()] + " " + now.getDate() + ", " + thisYear);
      // --> 
</script></b>&nbsp;&nbsp;</FONT></TD>
<td>&nbsp;</td>
</tr>		
        <TR>
                <TD colspan=6 bgcolor="#000000"><IMG src="themes/LinuxCom/pixel.gif" width=1 height=1 alt="" border=0 hspace=0></TD>
        </TR>
        </TABLE>
<TABLE width="95%" cellpadding="0" cellspacing="0" border="0" bgcolor="#fefefe" align="center" nowrap >
	<!-- tr><td colspan="5">&nbsp</td><td width=80%><IMG src="themes/LinuxCom/pix.gif" height="1" width="350" alt=""></td><td colspan="5">&nbsp</td><tr -->
      <TR valign="top">
        <TD bgcolor="#ffffff" colspan=11 nowrap><IMG src="themes/LinuxCom/pixel.gif" width="1" height="16"></TD>
        </TR>
        <TR valign="top"><TD width="50"><IMG src="themes/LinuxCom/pixel.gif" height="1" width="16" alt=""></TD>
        <TD width="120">
        <P align="center">
        <P>     <P>
        <TABLE width="100%" cellpadding="0" cellspacing="0" border="0">
        <TR valign="bottom">
<?php
mainblock();
online();
adminblock();
leftblocks();
ephemblock();
headlines();
?>

<TD width="16"><IMG src="themes/LinuxCom/pixel.gif" height="1" width="16" alt=""></TD>
<TD background="themes/LinuxCom/checkerboard.gif" width="1"><IMG src="themes/LinuxCom/pixel.gif" height="1" width="1" alt=""></TD>
<TD width="16"><IMG src="themes/LinuxCom/pixel.gif" height="1" width="16" alt=""></TD>
<td>
<P><H2 align="center"> </H2>
<P align="center"><P>
