<?
// Portal Gnutella Brasil http://portal.gnutella.com.br
// Mikhail Miguel <mikhail@gnutella.com.br>

echo "<body onload=init() bgcolor=ffffff text=000000 link=006600 vlink=000000 topmargin=10 leftmargin=0 rightmargin=0 marginheight=0>
<br>";
if ($banners) {
    include("banners.php");
}
echo "<br>
<table width=\"96%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\">
  <tr>
    <td bgcolor=\"a8ff30\"><a href=$nuke_url><img src=themes/PortalGnutellaBrasil/logo.gif alt=\"".translate("Welcome to")." $sitename\" border=0></a>
    </td>
    <td bgcolor=\"a8ff30\" align=\"right\">
      <form action=search.php method=post>
        <font size=2 color=000000> ".translate("Search")." 
        <input type=text name=query2>
        </font>&nbsp;
        </form>
      
    </td>
  </tr>
</table>

<br>


<table border=0 cellpadding=0 cellspacing=0 width=96% align=center>
<tr>
<td bgcolor=FfFfFf>

<table border=0 cellspacing=0 cellpadding=2 width=100%>
<tr>
<td valign=top width=150 bgcolor=FfFfFf>";

mainblock();
leftblocks();
ephemblock();
headlines();
online();
adminblock();

echo "<img src=images/pix.gif border=0 width=150 height=1></td><td>&nbsp;&nbsp;</td><td width=100% valign=top>";


?>



<table width="96%" border="0" cellspacing="0" cellpadding="0" align="center" dwcopytype="CopyTableRow">
  <tr> 
    <td colspan="4"> <font face="tahoma, verdada, Helvetica, arial" size="-2"><b>DOWNLOAD</b></font></td>
  </tr>
  <tr> 
    <td colspan="4"><font size="-2"> Sele&ccedil;&atilde;o das melhores vers&otilde;es 
      do gnutella:</font></td>
  </tr>
  <tr> 
    <td width="25%" bgcolor="#CCFF00"><font size="-2">Windows</font></td>
    <td width="25%" bgcolor="#CCFF00"><font size="-2">Linux/Unix</font></td>
    <td width="25%" bgcolor="#CCFF00"><font size="-2">Mac</font></td>
    <td width="25%" bgcolor="#CCFF00"><font size="-2">Multiplataforma</font></td>
  </tr>
  <tr> 
    <td width="25%"> <font size="-2"><a href="http://www.bearshare.com/downloads/BearShare123.exe">BearShare 
      v1.23</a></font></td>
    <td width="25%"><font size="-2"><a href="http://gtk-gnutella.sourceforge.net/download/gtk-gnutella-0.12.tar.gz" target="_blank">Gtk-Gnutella</a></font></td>
    <td width="25%"><font size="-2"><a href="ftp://ftp.cxc.com/servents/Mactella_PPC.sit" target="_blank">MacTella</a></font></td>
    <td width="25%"><font size="-2"><a href="http://www.limewire.com/" target="_blank">LimeWare 
      b0.6d</a></font></td>
  </tr>
</table>
            <br>
            <br>
           
            