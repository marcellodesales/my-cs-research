<?PHP

if ($index == 1) {
    echo "<td>&nbsp;</td><td valign=\"top\">";
    category();
    pollNewest();
    bigstory();
    loginbox();
    userblock();
    oldNews($storynum);
    rightblocks();
    echo "</td>";
}

?>

</td></tr></table>
</td></tr></table>
</td></tr></table>

<center><b><font color=AAAAAA size=2><br>All trademarks and copyrights on this page are owned by their respective owners.<br> Comments are owned by the Poster. The Rest � 1999-2000 James Knickelbein<br><a href="http://www.phpnuke.org" target="_blank">Site Engine Powered by PHP-Nuke 4.1</a></font></b></center>
</center></div>
<?php
footmsg();
?>