<html>
<head>
 <title> MIOLO - theme:AddStyle</title>
 <link rel="stylesheet" href="/miolo/doc/doc.css">
</head>
<body>
<? include '/usr/local/bis/html//miolo/doc/header.inc' ?>
<h3 align="right">Classe: <a href="/miolo/doc/miolo/ui/theme.class.php">Theme</a></h3>
<h2>AddStyle($url)</h2>
<p>TODO: Escrever documenta��o da fun��o AddStyle.</p>
<h3>Par�metros:</h3>
<dl>
 <dt>$url</dt>
 <dd>Descri��o par�metro $url.</dd>
</dl>
<p>&nbsp;</p>
<pre>
<?php
highlight_string(
'<?php
    ...
    $theme->AddStyle($url); 
    ...
?>');
?>
</pre>
<? include '/usr/local/bis/html//miolo/doc/footer.inc' ?>
</body>
</html>
