PHP NUKE AQUA THEME (based on macosX aqua look):
================================================



Author:
=======

Hericord olivier
Cannes
France

Email:
ohericord@free.fr ; hangon@mac.com


THANKS:
=======

Thanks to kde.themes.org for the phpnuke's KDE THEME on which i based all
my work.

Thank to Apple for macOSX which has the power and stability of a Unix
system and the ease of use of the legendary macOS.
Php, perl and MySQL associated to BBedit make my mac the best dev environnement
i ever seen (easy fast fun beautifull ....)



INSTALL:
========

Just drop the AQUA folder on the themes folder of phpnuke







Olivier
(sorry for my poor english, i'm just french   :)  )