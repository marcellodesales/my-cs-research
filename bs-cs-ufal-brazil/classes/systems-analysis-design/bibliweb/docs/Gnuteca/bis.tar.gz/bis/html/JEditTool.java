import java.net.*;
import java.io.*; 

public class JEditTool implements Runnable
{
  public static final int PORT = 10001;
  
  static Thread server;
  
  public void run()
  {
    try
    {
      ServerSocket srvsock = new ServerSocket(PORT,0,InetAddress.getLocalHost());
      
      System.err.println("JEditTool is listening");
      
      while ( true )
      {
        try
        {
          Socket cltsock = srvsock.accept();
          
          DataInputStream in = new DataInputStream(cltsock.getInputStream());
          String file = in.readLine();
          in.close();
          
          if ( ! file.startsWith("/") )
              file = "/usr/local/bis/html/" + file;
          
          System.out.println("Editing: " + file);
          
          Runtime.getRuntime().exec("/usr/local/bin/jedit " + file);
        }
        
        catch(IOException e)
        {
          e.printStackTrace();
        }
      }
      
      // srvsock.close();
    }
    
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }
  
  public void startServer()
  {
    System.err.println("Starting server");
    server = new Thread(this);
    server.start();
  }
  
  public void stopServer()
  {
    server.stop();
  }
  
  public void editFile(String file)
  {
    try
    {
        Socket sock = new Socket(InetAddress.getLocalHost(),PORT);
      
        DataOutputStream out = new DataOutputStream(sock.getOutputStream());
        out.writeBytes(file+"\n");
        out.close();
    }
    
    catch(Exception e)
    {
        e.printStackTrace();
    }
  }
  
  public static void main(String args[])
  {
    if ( args.length != 1 )
    {
      System.err.println("Usage: JEditTool -S | file");
      System.exit(-1);
    }
    
    JEditTool instance = new JEditTool(); 
    
    if ( args[0].equals("-S") )
      instance.startServer(); 
    
    else
      instance.editFile(args[0]);
  }
}
