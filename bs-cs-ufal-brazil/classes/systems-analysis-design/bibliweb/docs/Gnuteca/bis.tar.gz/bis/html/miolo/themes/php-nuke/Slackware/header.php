<?php

include("config.php");

?>

<BODY onload=init() BACKGROUND="/themes/Slackware/background.jpg" BGCOLOR="#fefefe" TEXT="#000000" LINK="#000000" VLINK="#000000" ALINK="#000000">
<br>
<?php
if ($banners) {
    include("banners.php");
}
?>
<br>
<CENTER>

<TABLE BORDER="0" WIDTH="100%" CELLSPACING="0" CELLPADDING="0"><TR><TD COLSPAN="3">
    <TABLE WIDTH="95%" CELLSPACING="0" CELLPADDING="0"><TR><TD ALIGN="center" VALIGN="bottom" WIDTH="55%">
	<TABLE WIDTH="80%" CELLPADDING="0"><TR><TD BGCOLOR="#000000">
	    <TABLE WIDTH="100%" CELLPADDING="6"><TR><TD BGCOLOR="#fefefe">
		<CENTER><B><?php echo $slogan ?></B></CENTER>
	    </TD></TR></TABLE>
	</TD></TR></TABLE>
    </TD><TD VALIGN="bottom" ALIGN="right">
	<TABLE CELLPADDING="0"><TR><TD BGCOLOR="##000000">
	    <TABLE CELLPADDING="0"><TR><TD BGCOLOR="#ffffff">
		<A HREF="<?php echo $nuke_url ?>"><IMG SRC="/themes/Slackware/logo.gif" ALT="<?php echo "".translate("Welcome to")." $sitename"; ?>" BORDER="0"></A>
	    </TD></TR></TABLE>
	</TD></TR></TABLE>
    </TD></TR><TR><TD COLSPAN="2"><BR>
    </TD></TR></TABLE>
    </TD></TR><TR VALIGN="top"><TD WIDTH="10%">


<?php

mainblock();
if (isset($cookie[3])) $storynum = $cookie[3]; else $storynum = $storyhome;
category();
adminblock();
loginbox();
userblock();
pollNewest();
bigstory();
oldNews($storynum);
leftblocks();
rightblocks();
ephemblock();
headlines();
online();

?>

<P></TD>
<TD> &nbsp; </TD>
<TD>