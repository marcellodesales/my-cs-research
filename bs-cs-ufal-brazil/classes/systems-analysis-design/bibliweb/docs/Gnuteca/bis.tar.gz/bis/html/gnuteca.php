<?php

    header ("Cache-Control: no-cache, must-revalidate");  // HTTP/1.1
    header ("Pragma: no-cache");                          // HTTP/1.0

    // gettext placeholder
    function _($t) { return '[' . $t . ']'; }

    include_once 'miolo/miolo.class';
    
    $MIOLO  = new MIOLO;
    
    $MIOLO->SetDispatcher('/gnuteca.php');
    
    session_start();
    session_register('login');
    
    $MIOLO->ProfileEnter('miolo.php');
      
    $theme = $MIOLO->GetTheme();
    
    //
    // Obtain Context Object
    // 
    
    $context = new Context();    
   
    $MIOLO->Trace("HTTP_REFERER='" . getenv("HTTP_REFERER") . "'<br>\n");
    $MIOLO->Trace("HTTP_USER_AGENT='$HTTP_USER_AGENT'<br>\n");
    $MIOLO->Uses('ui/statusbar.class');

    // registrar scripts externos (os modulos podem registrar scripts 
    // individuais nos handlers)     
    $theme->AddScript("/miolo/common.js");
    
    // variaveis globais que utilizamos em todos os modulos
    $theme   = & $MIOLO->GetTheme();
    
    $login = $MIOLO->GetLogin();
    
    if (! $login)
    {
        $login = $MIOLO->Authenticate('guest','guest');        
    }
    
    $online = ( time() - $login->time ) / 60; 
    
	$sb = new StatusBar();
	$sb->AddInfo('<div align="center">Usu�rio: ' . ($login->id ? $login->id : '-') . '</div>');
	$sb->AddInfo('<div align="center">Hora Login: ' . ($login->id ? Date('H:i',$login->time) . 
                 ' (' . sprintf('%02d:%02d',$online/60,$online%60) . ')' : '--:--') . '</div>');        
	$sb->AddInfo('<div align="center">Data: '. ($login->id ? Date('d/m/Y',$login->time) : '--/--/----') . '</div>');        
	$sb->AddInfo('<div align="center">MIOLO Version: ' . MIOLO_VERSION . '</div>');        

	$theme->Status($sb);

    $menu    = $theme->CreateMenu('GNUTECA','default');
    $topmenu = $theme->CreateMenu('Menu Principal','flow');

    $module = $context->module;
    $action = $context->action;
    $item   = $context->item;
    
	if ( $module == 'main' || ! $module ) 
        $module = 'gnuteca';
    
    $a = $context ? $context->ShiftAction() : 'main';
    
    if ( ! $a )
        $a = 'main';
    
    $MIOLO->Trace('Module = ' . $module);
    $MIOLO->Trace('Action = ' . $a);
    
    if ( ! $login->pessoa )
      $MIOLO->InvokeHandler('gnuteca','login');   
    
    else
      $MIOLO->InvokeHandler($module,$a);   

  	$theme->Commands($menu);
	$theme->Title($topmenu);
	$theme->TraceStatus(new ParsingTimeStatus);
    $theme->Generate();
    
    // $MIOLO->dump($theme);
?>
