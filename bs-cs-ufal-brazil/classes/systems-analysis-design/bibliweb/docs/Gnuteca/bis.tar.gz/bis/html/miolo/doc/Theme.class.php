<html>
<head>
 <title> MIOLO - Classe Theme</title>
 <link rel="stylesheet" href="doc.css">
</head>
<body>
<? include 'header.inc' ?>
<h2>Classe Theme</h2>
<blockquote>
extends <a href="#.class.php">SuperClasse</a>
</blockquote>
<p>TODO: Escrever documenta��o da classe Theme.</p>
<h3>M�todos:</h3>
<dl>
 <dt>foo()</dt>
 <dd>Descri��o do m�todo foo</dd>
 <dt>bar()</dt>
 <dd>Descri��o do m�todo bar</dd>
 <dt>rin()</dt>
 <dd>Descri��o do m�todo rin</dd>
</dl>
<p>&nbsp;</p>
<? include 'footer.inc' ?>
</body>
</html>
