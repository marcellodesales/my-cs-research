<?php

echo "<body onload=init() background=themes/Grid/grid.gif text=000000 link=000000 vlink=000000 topmargin=5 leftmargin=0 rightmargin=0 marginheight=5>
<br>";
if ($banners) {
    include("banners.php");
}
echo "<br>
<table border=0 cellpadding=4 cellspacing=0 width=100% align=center><tr><td>
<table border=0 cellspacing=0 cellpadding=1 width=100% bgcolor=000000><tr><td>
<table border=0 cellspacing=0 cellpadding=3 width=100% bgcolor=999999><tr><td>
<a href=$nuke_url><img src=themes/Grid/logo.gif Alt=\"".translate("Welcome to")." $sitename\" border=0></a>
</td><td align=right>
    <form action=search.php method=post><font size=2 color=ffffff>
    ".translate("Search")."
    <input type=text name=query>
    </form>
</tr><tr bgcolor=CCCCCC><td colspan=2 bgcolor=CCCCCC>
<font size=3 color=333333>$slogan</td>
</td></tr></table></td></tr></table></td></tr><tr><td valign=top width=100%>
<table border=0 cellspacing=0 cellpadding=2 width=100%><tr><td valign=top width=150>";

mainblock();
adminblock();
leftblocks();
ephemblock();
headlines();
online();

echo "<img src=images/pix.gif border=0 width=150 height=1></td><td width=100% valign=top>";
?>