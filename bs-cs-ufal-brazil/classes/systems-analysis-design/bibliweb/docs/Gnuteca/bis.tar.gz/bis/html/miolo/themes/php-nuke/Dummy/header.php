<?php
include("config.php");
include("themes/Dummy/vars.php");

function newonline() {
    global $user, $cookie, $textcolor2;
    cookiedecode($user);
    $ip = getenv("REMOTE_ADDR");
    $username = $cookie[1];
    if (!isset($username)) {
        $username = "$ip";
        $guest = 1;
    }
    $past = time()-900;
    mysql_query("DELETE FROM session WHERE time < $past");
    $result = mysql_query("SELECT time FROM session WHERE username='$username'");
    $ctime = time();
    if ($row = mysql_fetch_array($result)) {
	  mysql_query("UPDATE session SET username='$username', time='$ctime', host_addr='$ip', guest='$guest' WHERE username='$username'");
    } else {
 	  mysql_query("INSERT INTO session (username, time, host_addr, guest) VALUES ('$username', '$ctime', '$ip', '$guest')");
    }

    $result = mysql_query("SELECT username FROM session where guest=1");
    $guest_online_num = mysql_num_rows($result);
    $result = mysql_query("SELECT username FROM session where guest=0");
    $member_online_num = mysql_num_rows($result);
    $who_online_num = $guest_online_num + $member_online_num;
    $who_online = translate("<font color=$textcolor2 size=1><b>People online:</b><br>")." $guest_online_num ".translate("guest(s) and")." $member_online_num ".translate("member(s)")."<BR>";
    $content = "$who_online";
    if ($user) {
	  $content .= "".translate("You are logged in as")." <b>$username</b>.</font>";
    } else {
	  $content .= "".translate("You are an Anonymous user. You can register for free by clicking <a href=user.php>here</a>.</font>")."";
    }
	echo $content;
}

echo "
  <body onload=init() text=222222 link=101070 vlink=222222 background=$background1>
  <br>";
if ($banners) {
    include("banners.php");
}
echo "<br>
  <center>
  <table cellpadding=0 cellspacing=0 border=0 width=99% align=center><tr><td align=left>
  <a href=$nuke_url><img align=left src=$logo border=0></a></td><td align=left>";

newonline();
echo "
</td><td><img align=right src=$logo2></td><td align=left></td>
";
global $admin;
if ($admin) {
    $res = mysql_query("select * from queue");
    $num = mysql_num_rows($res);
    echo "</td></tr><tr><td></td><td align=left><font color=$textcolor2 size=1>".translate("New Submissions: ")."$num";
    echo "</td></tr></table>";
} else {
    echo "</td></tr></table><br>";
}

if($show_slogan_bar) {
echo "
  <table cellpadding=0 cellspacing=1 border=0 width=99% bgcolor=101070>
    <tr>
	  <td>
        <table cellpadding=5 cellspacing=1 border=0 width=100% bgcolor=ffffff background=$background3>
		  <tr>
		    <td><font size=2 color=$textcolor2><b>$slogan</b></td>
	      </tr>
		</table>
	  </td>
	</tr>
  </table>
  <P>"; }
  echo "
<table width=99% align=center cellpadding=0 cellspacing=0 border=0><tr><td valign=top rowspan=5>";

mainblock();
leftblocks();
ephemblock();
adminblock();
headlines();
online();

echo "</td><td>&nbsp;</td><td valign=top width=100%>";
?>

