<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body bgcolor="#FFFFFF" text="#000000">
<form name="myform" method="post" action="multitext.php" onSubmit="return _MIOLO_Form_onSubmit(this)">
<table border="0" cellspacing="10" cellpadding="0" bgcolor="#ffffff">
<?
  $max_rows = 4;
  $max_cols = 3;

  if ( ! isset($Submit) )
  {
    for ( $i=1; $i<=$max_rows; $i++ )
    { 
      for ( $j=1; $j<=$max_rows; $j++ )
      {
        for ( $n=0; $n<5; $n++ )
          eval("\$mtf{$i}{$j}_list[$n]=$n+1;");
      }
    }
  }
?>
<? for ( $row=1; $row<=$max_rows; $row++ ) { ?>
	<tr>
		<? for ( $col=1; $col<=$max_cols; $col++ ) 
			 { 
				 $mtf_name = 'mtf' . $row . $col;

				 $JS_form_submit_code .= "  _MIOLO_MultiTextField_onSubmit(frmObj,'$mtf_name');\n";
		?>
		<td>
			<table border="0" cellspacing="0" cellpadding="2" bgcolor="#ffffcf">
				<tr> 
					<td colspan="2"><b>MultiTextField <?=$mtf_name?></b></td>
				</tr>
				<tr> 
					<td width="212"> 
						<select name="<?=$mtf_name?>_list[]" size="3" cols="40" style="width:200;" multiple onKeyDown="return _MIOLO_MultiTextField_onKeyDown(this,this.form,'<?=$mtf_name?>',event);">
						<?
						foreach ( $GLOBALS["{$mtf_name}_list"] as $m )
							echo "<option>$m</option>\n";
						?> 
						</select>
					</td>
					<td width="90" valign="top"> 
						<input type="button" name="<?=$mtf_name?>_remove" value="Remove" style="width:80;" onClick="_MIOLO_MultiTextField_remove(this.form,'<?=$mtf_name?>')">
					</td>
				</tr>
				<tr> 
					<td width="212"> 
						<input type="text" name="<?=$mtf_name?>_text" style="width:200;" onKeyDown="return _MIOLO_MultiTextField_onKeyDown(this,this.form,'<?=$mtf_name?>',event);">
					</td>
					<td width="90"> 
						<input type="button" name="<?=$mtf_name?>_add" value="Add" style="width:80;" onClick="_MIOLO_MultiTextField_add(this.form,'<?=$mtf_name?>')">
					</td>
				</tr>
			</table>
		</td>
		<? } // for $col ?>
	</tr>
  <? } // for $row ?>
</table>
<div align="center">
  <input type="submit" name="Submit" value="Submit">
</div>
<script language="JavaScript">

/**
 * Esta fun��o ser� gerada da pr�pria classe Form. Ela serve para
 * poder fazer um tratamento dependendo dos campos de entrada, antes
 * que o formul�rio ser� enviado.
 *
 * No caso dos componentes MultiTextField, utilizamos est� fun��o
 * para selecionar todos os itens da lista.
 */
function _MIOLO_Form_onSubmit(frmObj)
{
  /*** START OF MIOLO DYNAMICALLY GENERATED STATEMENTS ***/
<?=$JS_form_submit_code?>
  /*** END OF MIOLO DYNAMICALLY GENERATED STATEMENTS ***/

  return true;
}

/**
 * Fun��o que simplesmente seleciona todos os itens, para que
 * ser�o incluidos ao enviar o formul�rio
 */
function _MIOLO_MultiTextField_onSubmit(frmObj,mtfName)
{
  var list = frmObj[mtfName+'_list[]'];
  for ( var i=0; i<list.length; i++ )
    list.options[i].selected = true;
}

/**
 * Fun��o que intercepta a tecla Enter, para que o conte�do do
 * campo de texto � adicionado a lista.
 */
function _MIOLO_MultiTextField_onKeyDown(source,frmObj,mtfName,event)
{
  // IE and compatibles use 'keyCode', NS and compatibles 'which'
  var key = ( document.all != null ) ? event.keyCode : event.which;

  if ( source.name == mtfName + '_text' )
  {
    if ( key == 13 ) // enter key
    {
      _MIOLO_MultiTextField_add(frmObj,mtfName);
      return false;
    }
  }

  else if ( source.name == mtfName + '_list[]' )
  {
    // alert(key);

    if ( key == 46 ) // delete key
    {
      _MIOLO_MultiTextField_remove(frmObj,mtfName);
      return false;
    }
  }
}

/**
 * Func��o que adiciona o conte�do do campo de texto a lista.
 */
function _MIOLO_MultiTextField_add(frmObj,mtfName)
{
  var list = frmObj[mtfName+'_list[]'];
  var tf   = frmObj[mtfName+'_text'];
  if ( tf.value != '' )
  {
    var i = list.length;
    list.options[i] = new Option(tf.value);
    for ( var j=0; j<=i; j++ )
      list.options[i].selected = j<i;
    tf.value = '';
  }
}

/**
 * Func��o que exclui o item atualmente selecionado
 */
function _MIOLO_MultiTextField_remove(frmObj,mtfName)
{
  var list = frmObj[mtfName+'_list[]'];

  for ( var i=0; i<list.length; i++ )
  {
    if ( list.options[i].selected )
    {
      list.options[i] = null;

      if ( i >= list.length )
        i = list.length - 1;

      if ( i >= 0 )
        list.options[i].selected = true;

      break;
    }
  }
}
</script>
</form>
<hr>
<?php
if ( isset($Submit) )
{
  echo "<pre>\n";
  var_dump($HTTP_POST_VARS); 
  echo "</pre>\n";
}
?>
</body>
</html>
