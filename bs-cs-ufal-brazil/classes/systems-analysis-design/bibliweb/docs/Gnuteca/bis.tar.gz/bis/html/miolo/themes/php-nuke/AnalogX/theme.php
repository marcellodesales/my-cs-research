<?php

$thename = "AnalogX";
$lnkcolor = "3E6EB6";
$bgcolor1 = "#B3C0D7";
$bgcolor2 = "#6E7684";
$bgcolor3 = "#B3C0D7";
$bgcolor4 = "#AAA0C7";
$textcolor1 = "#FFFFFF";
$textcolor2 = "#000000";
$hr = 1; # 1 to have horizonal rule in comments instead of table bgcolor

function themeindex ($aid, $informant, $time, $title, $counter, $topic, $thetext, $notes, $morelink, $topicname, $topicimage, $topictext) {
	global $tipath, $anonymous;
	if ("$aid" == "$informant") { ?>
<table border=1 cellpadding=0 cellspacing=0 width=100% bordercolor=6E7684>
<tr><td width=100%>
<font color=6E7684><b><i>&nbsp;<?php echo"$title"; ?></i></b></font>
<font color=6E7684 size=-2>&nbsp;[<?php formatAidHeader($aid) ?>]</td></tr>
<tr><td align=right width=100% bgcolor=6E7684>
<font color=FFFFFF size=-2><?php echo"$time $timezone"; ?>&nbsp; </font>
</td></tr></table><table border=0 cellpadding=0 cellspacing=0 width=100%><tr><td>
<p><a href="search.php?query=&topic=<?php echo"$topic"; ?>&author=">
<img src=<?php echo"$tipath$topicimage"; ?> border=0 Alt=<?php echo"\"$topictext\""; ?> align=left hspace=10 vspace=10></a>
&nbsp;&nbsp;&nbsp;&nbsp;<?php echo"$thetext
</td></tr><tr><td align=right>
<font size=-2>$morelink"; ?>
</td></tr></table><br>

<?php	} else {
		if($informant != "") $boxstuff = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
		else $boxstuff = "$anonymous ";
		$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes";
?>

<table border=1 cellpadding=0 cellspacing=0 width=100% bordercolor=6E7684>
<tr><td width=100%>
<font color=6E7684><b><i>&nbsp;<?php echo"$title"; ?></i></b></font>
<font color=6E7684 size=-2>&nbsp;[<?php formatAidHeader($aid) ?>]</td></tr>
<tr><td align=right width=100% bgcolor=6E7684>
<font color=FFFFFF size=-2><?php echo"$time $timezone"; ?>&nbsp; </font>
</td></tr></table><table border=0 cellpadding=0 cellspacing=0 width=100%><tr><td>
<p><a href="search.php?query=&topic=<?php echo"$topic"; ?>&author=">
<img src=<?php echo"$tipath$topicimage"; ?> border=0 Alt=<?php echo"\"$topictext\""; ?> align=left hspace=10 vspace=10></a>
&nbsp;&nbsp;&nbsp;&nbsp;<?php echo"$boxstuff
</td></tr><tr><td align=right>
<font size=-2>$morelink"; ?>
</td></tr></table><br>

<?php	}
}

function themearticle ($aid, $informant, $datetime, $title, $thetext, $topic, $topicname, $topicimage, $topictext) {
	global $admin, $sid, $tipath;
	if ("$aid" == "$informant") {

echo"
<table border=1 cellpadding=0 cellspacing=0 width=100% bordercolor=6E7684>
<tr><td width=100%>
<font color=6E7684><b><i>&nbsp;$title</i></b></font>
<font color=6E7684 size=-2>&nbsp;";

if ($admin) {
    echo "&nbsp;&nbsp; [ <a href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]";
}

echo"
</td></tr>
<tr><td align=right width=100% bgcolor=6E7684>
<font color=FFFFFF size=-2>".translate("Posted on ")." $datetime &nbsp; </font>
</td></tr></table><table border=0 cellpadding=0 cellspacing=0 width=100%><tr><td>
<p><a href=search.php?query=&topic=$topic&author=>
<img src=$tipath$topicimage border=0 Alt=\"$topictext\" align=left hspace=10 vspace=10></a>
&nbsp;&nbsp;&nbsp;&nbsp;$thetext
</td></tr></table><br>";

	} else {
		if($informant != "") $informant = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
		else $boxstuff = "$anonymous ";
		$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes";
echo "

<table border=1 cellpadding=0 cellspacing=0 width=100% bordercolor=6E7684>
<tr><td width=100%>
<font color=6E7684><b><i>&nbsp;$title</i></b> - ".translate("Contributed by ")." $informant </font>
<font color=6E7684 size=-2>&nbsp;";
if ($admin) {
    echo "&nbsp;&nbsp; [ <a href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]";
}
echo"
</td></tr>
<tr><td align=right width=100% bgcolor=6E7684>
<font color=FFFFFF size=-2>".translate("Posted on ")." $datetime &nbsp; </font>
</td></tr></table><table border=0 cellpadding=0 cellspacing=0 width=100%><tr><td>
<p><a href=search.php?query=&topic=$topic&author=>
<img src=$tipath$topicimage border=0 Alt=\"$topictext\" align=left hspace=10 vspace=10></a>
&nbsp;&nbsp;&nbsp;&nbsp;$thetext
</td></tr></table><br>";
	}
}

function themesidebox($title, $content) {
    echo "
    <tr><td background=themes/AnalogX/images/menutitle.gif height=28 width=150 valign=top>
    <font size=-2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp</font>
    <b><font size=-2>$title</font></b>
    </td></tr><tr><td bgcolor=B3C0D7 width=17%>
    </td></tr><tr><td bgcolor=B3C0D7 width=83% valign=top> 
    <font size=-2>$content</font><br>
    </td></tr><tr><td>&nbsp;</td></tr>";
}

?>
