<?
// +-----------------------------------------------------------------+
// | GNUTECA Development Team - UNIVATES Centro Universit�rio        |
// | Copyleft (l) 2002 UNIVATES, Lajeado/RS - Brasil                 |
// +-----------------------------------------------------------------+
// | Licensed under GPL: www.fsf.org for further details             |
// |                                                                 |
// | Site:   http://gnuteca.codigoaberto.org.br                      |
// | E-mail: gnuteca@univates.br                                     |
// +-----------------------------------------------------------------+
// | Abstract: M�dulo principal do GnuTeca vers�o Empr�stimo         |
// |                                                                 |
// | Created by Pablo Dall'Oglio  (pablo@univates.br)                |
// |            Jo�o Alex Fritsch (joaoalex@univates.br)             |
// +-----------------------------------------------------------------+

/***********************************************************/
/* Classe Visual
/* Estrutura de Lista
/***********************************************************/
class GnuTecaLocalMainModule
{
  var $CodigoDaPessoa;
  var $codigoLivro;
  var $senhaPessoa;
  var $NomeDaPessoa;
  var $nomeLivro;
  var $senhaPessoa;
  var $startButton;
  var $window;
  var $HelpWindow;
  var $clist;
  var $slist;
  var $StatusBar;
  var $clistRows;
  var $Politica;
  var $Ambiente;

  /*******************************************************************************/
  /* Fun��o Fecha LocalMainModule
  /*******************************************************************************/
  function FechaLista()
  {
    $this->window->hide();
    return true;
  }

  function Logout()
  {
    GnuTecaLogin::Logout();
    //Gtk::main_quit();
    $this->window->hide();
    return true;
  }

  /*******************************************************************************/
  /* M�todo construtor do M�dulo principal
  /*******************************************************************************/
  function GnuTecaLocalMainModule()
  {
    global $MIOLO;
    $Login = $MIOLO->login;

    $this->window = &new GtkWindow;
    $this->window->connect_object('delete-event', array(&$this,'FechaLista'));
    $this->window->set_title('M�dulo Empr�stimo - ' . $Login->id);
    $this->window->set_border_width(0);
    $this->window->set_default_size(600, 100);
    $this->window->set_uposition(80, 80);

    $this->window->add_events(GDK_KEY_PRESS_MASK);
    $this->window->connect_object('key_press_event', array(&$this,'KeyTest'), 'Emprestimo');

    $vbox = &new GtkVBox();
    $this->window->add($vbox);
    $vbox->show();

    $hbox = &new GtkHBox();
    $vbox->pack_start($hbox, false, false);
    $hbox->show();
    $this->window->realize();

    $hbox->pack_start($this->CreateHeaderBox('Funcionalidades'), true, true, 10);
    //$Functions = &new GtkLabel('[F1] Ajuda          [F2] Finaliza Retirada       [F3] Finaliza Devolu��o');
    //$hbox->pack_start($this->CreateLabelBox($Functions, 592, 20, 'Funcionalidades'), true, false, 10);

    $hbox = &new GtkHBox();
    $vbox->pack_start($hbox, false, false);
    $hbox->show();
    $this->window->realize();

    $this->CodigoDaPessoa  = &new GtkEntry();
    $hbox->pack_start($this->CreateEntryBox($this->CodigoDaPessoa, 10, 'Pessoa'), false, false, 10);
    $this->CodigoDaPessoa->connect_object('key_press_event', array(&$this,'KeyTest'), 'Pessoa');
    $this->CodigoDaPessoa->set_usize(80,20);

    $this->senhaPessoa  = &new GtkEntry();
    $hbox->pack_start($this->CreateEntryBox($this->senhaPessoa, 10, 'Senha'), false, false, 10);
    $this->senhaPessoa->connect_object('key_press_event', array(&$this,'KeyTest'),'Senha');
    $this->senhaPessoa->set_visibility(false);
    $this->senhaPessoa->set_usize(50,20);

    $this->NomeDaPessoa = &new GtkLabel('');
    $hbox->pack_start($this->CreateLabelBox($this->NomeDaPessoa, 360, 20, 'Nome'), false, false, 10);

    $hbox2 = &new GtkHBox();
    $vbox->pack_start($hbox2, false, false);
    $hbox2->show();
    $this->window->realize();

    $this->codigoLivro  = &new GtkEntry();
    $hbox2->pack_start($this->CreateEntryBox($this->codigoLivro, 10, 'Exemplar'), false, false, 10);
    $this->codigoLivro->connect_object('key_press_event', array(&$this,'KeyTest'), 'Livro');
    $this->codigoLivro->set_usize(80,20);

    $this->nomeLivro = &new GtkLabel('');
    $hbox2->pack_start($this->CreateLabelBox($this->nomeLivro, 462, 20, 'Livro'), false, false, 10);

    $scrolled_win = &new GtkScrolledWindow();
    $scrolled_win->set_border_width(5);
    $scrolled_win->set_policy(GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);

    $titles = array("C�digo", "T�tulo", "Autor");

    $this->clist = &new GtkCList(3, $titles);
    $scrolled_win->add($this->clist);
    $this->clist->show();

    $hbox = &new GtkHBox(false, 5);
    $hbox->set_border_width(5);
    $vbox->pack_start($hbox, false, false);
    $hbox->show();

    $vbox->pack_start($scrolled_win);
    $scrolled_win->show();

    $hbox = &new GtkHBox(false, 5);
    $hbox->set_border_width(5);
    $vbox->pack_start($hbox, false, false);
    $hbox->show();

    $hbox->pack_start($this->StatusDaPessoa(), false,true, 8);

    $this->clist->set_row_height(18);
    $this->clist->set_usize(-1, 150);

    $clist_rows = 0;
    for ($i = 1; $i < 12; $i++)
      $this->clist->set_column_width($i, 40);

    $this->clist->set_column_width(0, 76);
    $this->clist->set_column_width(1, 260);
    $this->clist->set_column_width(2, 238);

    $this->clist->set_column_resizeable(0, true);
    $this->clist->set_column_resizeable(1, true);
    $this->clist->set_column_resizeable(2, true);
    $this->clist->set_selection_mode(GTK_SELECTION_EXTENDED);
    $this->clist->set_column_justification(1, GTK_JUSTIFY_LEFT);
    $this->clist->set_column_justification(2, GTK_JUSTIFY_LEFT);

    $frame = &new GtkFrame();
    $frame->set_shadow_type(GTK_SHADOW_IN);
    $vbox->pack_start($frame, false);
    $frame->show();

    $hbox2 = &new GtkHBox();
    $hbox2->set_border_width(2);
    $frame->add($hbox2);
    $hbox2->show();

    $label = &new GtkLabel('Opera��o Selecionada :');
    $hbox2->pack_start($label, false);
    $label->show();

    $this->StatusBar['Operacao'] = &new GtkLabel((string)$this->StatusBar['Operacao']);
    $hbox2->pack_start($this->StatusBar['Operacao'], false, true, 5);
    $this->StatusBar['Operacao']->show();

    $style = &new GtkStyle();
    $style->fg[GTK_STATE_NORMAL] = new GdkColor(60000, 0, 0);
    $style->font = gdk::font_load ("-adobe-helvetica-bold-r-*-*-*-136-*-*-*-*-*-*");
    $this->StatusBar['Operacao']->set_style($style);

    $this->window->set_focus($this->CodigoDaPessoa);
    $this->window->show();

    $this->TrocaAmbiente(1); // J� deixa posicionado no Empr�stimo;

    $frame->show();
  }

  /***********************************************************/
  /* M�todo que troca de contexto, entre empr�stimo e devolu��o
  /***********************************************************/
  function TrocaAmbiente($Ambiente)
  {
    // Ambiente = 1 -> Empr�stimo
    // Ambiente = 2 -> Devolu��o

    $this->Ambiente = $Ambiente;
    $Operacao = ($Ambiente==1) ? 'Empr�stimo' : 'Devolu��o';
    $this->StatusBar['Operacao']->set_text((string) $Operacao);

    $this->LoadHeader();

    if ($Ambiente=='1')
    {
      $this->ReinicializaJanela(false);
      $this->window->set_focus($this->CodigoDaPessoa);
    }
    else
    {
      $this->ReinicializaJanela(false);
      $this->window->set_focus($this->codigoLivro);
    }
  }

  /***********************************************************/
  /* M�todo que finaliza opera��o de acordo com o contexto
  /***********************************************************/
  function FinalizaOperacao()
  {
    if ($this->Ambiente == 1)
    { $this->FinalizaEmprestimo(); }
    else
    { $this->FinalizaDevolucao(); }
  }


  /***********************************************************/
  /* M�todo que testa teclas pressionadas no ambiente principal
  /***********************************************************/
  function KeyTest($p1, $p2)
  {

    $Funcionalidades['Ajuda'][65307]      = '$this->HelpWindow->hide();';
    $Funcionalidades['Emprestimo'][65470] = '$this->Ajuda();';
    $Funcionalidades['Emprestimo'][65471] = '$this->TrocaAmbiente(1);';
    $Funcionalidades['Emprestimo'][65472] = '$this->TrocaAmbiente(2);';
    $Funcionalidades['Emprestimo'][65473] = '$this->FinalizaOperacao();';

    $Funcionalidades['Emprestimo'][65475] = '$this->ReservaMaterial();';
    $Funcionalidades['Emprestimo'][65476] = '$this->VerificaMaterial();';
    $Funcionalidades['Emprestimo'][65477] = '$this->VerificaSituacao();';
    $Funcionalidades['Emprestimo'][65535] = '$this->RemoveDaLista();';

    $Funcionalidades['Emprestimo'][65479] = '$this->Historico();';
    $Funcionalidades['Emprestimo'][65480] = '$this->Outros();';
    $Funcionalidades['Emprestimo'][65481] = '$this->Logout();';

    $Funcionalidades['Pessoa'][65293]     = '$this->VerificaUsuario();';
    $Funcionalidades['Livro'][65293]      = '$this->VerificaLivro();';
    $Funcionalidades['Senha'][65293]      = '$this->VerificaSenha();';

    $Funcionalidades['Pessoa'][65421]     = '$this->VerificaUsuario();';
    $Funcionalidades['Livro'][65421]      = '$this->VerificaLivro();';
    $Funcionalidades['Senha'][65421]      = '$this->VerificaSenha();';

    if (count($Funcionalidades[$p2])>0)
      eval ($Funcionalidades[$p2][$p1->keyval]);
  }

  /***********************************************************/
  /* M�todo que Abre Janela de Reserva Obra ou Exemplares
  /***********************************************************/
  function ReservaMaterial()
  {
    if (!$this->ReservaMaterial)
    { $this->ReservaMaterial = new ReservaMaterial();
      $this->ReservaMaterial->ExibeReservaMaterial();  }
    else
    { $this->ReservaMaterial->ExibeReservaMaterial();  }
  }

  /***********************************************************/
  /* M�todo que Abre janela para consultar Situa��o de Usu�rio
  /*   Empr�stimos, Reservas e Multas
  /***********************************************************/
  function VerificaSituacao()
  {
    if (!$this->VerificaSituacao)
    { $this->VerificaSituacao = new VerificaSituacao();  }
    else
    { $this->VerificaSituacao->ExibeVerificaSituacao();  }
  }

  function Historico()
  {
    if (!$this->Historico)
    { $this->Historico = new Historico();  }
    else
    { $this->Historico->ExibeHistorico();  }
  }

  /***********************************************************/
  /* M�todo que Abre janela para consultar Material
  /*   suas tags MARC21, se h� empr�stimos ou reservas
  /***********************************************************/
  function VerificaMaterial()
  {
    if (!$this->VerificaMaterial)
    { $this->VerificaMaterial = new VerificaMaterial();  }
    else
    { $this->VerificaMaterial->ExibeVerificaMaterial();  }
  }

  /***********************************************************/
  /* M�todo que Abre janela com outras op��es
  /***********************************************************/
  function Outros()
  {
    if (!$this->MenuOutros)
    {
      $Menu[1] = array('Altera Senha|Altera Senha de Usu�rio.',            'GnutecaLogin','AlteraSenha');
      $Menu[2] = array('Financeiro  |Acessa Consultas M�dulo Financeiro.', '',            '');

      $this->MenuOutros = new GnutecaMenu('Op��es', $Menu);
      $this->MenuOutros->ExibeMenu();
    }
    else
    { $this->MenuOutros->ExibeMenu(); }
  }

  /***********************************************************/
  /* M�todo que Finaliza Empr�stimo
  /* Dentre os C�digos de Exemplares lidos verifica se a
  /*  transi��o de estados pode ocorrer, verifica se est�
  /*  reservado, ou emprestado, realiza o empr�stimo ao final
  /***********************************************************/
  function FinalizaEmprestimo()
  {
    global $MIOLO;
    //$GNUTECA = $MIOLO->GetBusiness('gnuteca');
    $BusinessEmprestimo = $MIOLO->GetBusiness('gnuteca','Emprestimo');
    $BusinessMaterial   = $MIOLO->GetBusiness('gnuteca','Material');
    $BusinessExemplar   = $MIOLO->GetBusiness('gnuteca','Exemplar');
    $BusinessReserva    = $MIOLO->GetBusiness('gnuteca','Reserva');
    $BusinessGenero     = $MIOLO->GetBusiness('gnuteca','Genero');
    $BusinessPessoa     = $MIOLO->GetBusiness('gnuteca','Pessoa');
    $BusinessOperacao   = $MIOLO->GetBusiness('gnuteca','Operacao');
    $BusinessTransicao  = $MIOLO->GetBusiness('gnuteca','Transicao');
    $BusinessEstado     = $MIOLO->GetBusiness('gnuteca','Estado');
    $BusinessDireito    = $MIOLO->GetBusiness('gnuteca','Direito');
    $BusinessGrupo      = $MIOLO->GetBusiness('gnuteca','Grupo');
    $BusinessPolitica   = $MIOLO->GetBusiness('gnuteca','Politica');

    $Operacao           = $BusinessOperacao->ObtemOperacaoPorMnemonico('EMPRESTIMO');
    $CodigoDaPessoa     = $this->CodigoDaPessoa->get_text();
    $CodigoDoGrupo      = $BusinessPessoa->ObtemGrupo($CodigoDaPessoa);
    $Grupo              = $BusinessGrupo->ObtemGrupo($CodigoDoGrupo);

    if ($CodigoDaPessoa)
    {
      for ($n=0; $n<$this->clistRows; $n ++)
      {
        $CodigoDoExemplar    = $this->clist->get_text($n,0);
        $EmprestimoImpedido  = false;

        $Exemplar            = $BusinessExemplar->ObtemExemplar($CodigoDoExemplar);
        $NumeroDoTombo       = $Exemplar->NumeroDoTombo;
        $NumeroDaObra        = $Exemplar->NumeroDaObra;
        $Transicao           = $BusinessTransicao->ObtemTransicao($Exemplar->CodigoDoEstado,
                                                                  $Operacao->CodigoDaOperacao);

        $CodigoDoGenero      = $BusinessMaterial->ObtemConteudoEtiqueta($NumeroDaObra,
                                                                        GENERO_CAMPO,
                                                                        GENERO_SUBCAMPO);
        $Genero = $BusinessGenero->ObtemGenero($CodigoDoGenero);

        $TemDireito = $BusinessDireito->VerificaDireito($CodigoDoGrupo, $Operacao->CodigoDaOperacao, $CodigoDoGenero );
        $Emprestimo = $BusinessEmprestimo->ObtemEmprestimoPorTombo($NumeroDoTombo);

        $Reservas1 = $BusinessReserva->ObtemReservas($NumeroDoTombo, array('ATENDIDA'), true);
        $Reservas2 = $BusinessReserva->ObtemReservas($NumeroDoTombo, array('SOLICITADA', 'COMUNICADA'));
        $Reservas = array_merge($Reservas1,$Reservas2);
        $Reserva = $Reservas[0];


        if ($Emprestimo != null) // Verifica se est� emprestado
        {
          $Pessoa = $BusinessPessoa->ObtemPessoa($Emprestimo->CodigoDaPessoa);
          $EmprestimoImpedido = true;

          if ($Emprestimo->CodigoDaPessoa == $CodigoDaPessoa) //renovacao
          {
            $Politica = $BusinessPolitica->ObtemPolitica($CodigoDoGrupo, $CodigoDoGenero);
            if ($Politica)
            {
              $QuantidadeRenovacoes = $Politica->LimiteDeRenovacao;

              if ($Emprestimo->QuantidadeDeRenovacoes < $QuantidadeRenovacoes)
              {
                $NovaQuantidade = $Emprestimo->QuantidadeDeRenovacoes +1;
                $DataDevolucao = $BusinessEmprestimo->CalculaDataDevolucao($Politica->DiasDeEmprestimo);
                $BusinessEmprestimo->RenovaEmprestimo($Emprestimo->CodigoDoEmprestimo, $DataDevolucao, $NovaQuantidade);
                $DataDevolucaoBr = MDate::DateOfDateTime($DataDevolucao);
                $DataDevolucaoBr = MDate::DateToData($DataDevolucaoBr);

                $Status[] = array($NumeroDoTombo, 'Renova��o com sucesso', $DataDevolucaoBr);
              }
              else
              {
                $Status[] = array($NumeroDoTombo, 'Renovacoes Esgotadas', "Grupo:  {$Grupo->CodigoDoGrupo} - {$Grupo->Descricao}");
                $Status[] = array('',             '',                     "G�nero: {$CodigoDoGenero} - {$Genero->Descricao}");
              }
            }
            else
            {
              $Status[] = array($NumeroDoTombo, 'Falta Pol�tica', "Grupo:  {$Grupo->CodigoDoGrupo} - {$Grupo->Descricao}");
              $Status[] = array('',             '',               "G�nero: {$CodigoDoGenero} - {$Genero->Descricao}");
            }
          }
          else
          {
            $Status[] = array($NumeroDoTombo, 'J� est� Emprestado', "$Pessoa->CodigoDaPessoa - $Pessoa->Nome");
            //aqui
          }
        }

        elseif ($Reserva != null) // Verifica se est� reservado
        {
          $Pessoa = $BusinessPessoa->ObtemPessoa($Reserva->CodigoDaPessoa);

          if ($Reserva->CodigoDaPessoa==$CodigoDaPessoa)
          {
            $BusinessReserva->FinalizaReserva($Reserva, $NumeroDoTombo);
            $Status[] = array($NumeroDoTombo, 'Reserva', 'Confirmada');
          }
          else
          {
            $Status[] = array($NumeroDoTombo, 'Est� Reservado', "$Pessoa->CodigoDaPessoa - $Pessoa->Nome");
            $EmprestimoImpedido = true;
          }
        }

        else if ($Transicao == null) // verificar se transacao possivel
        {
          $Estado = $BusinessEstado->ObtemEstado($Exemplar->CodigoDoEstado);
          $Status[] = array($NumeroDoTombo, 'Transi��o N�o Permitida', "{$Estado->CodigoDoEstado} - {$Estado->Descricao}");
          $EmprestimoImpedido = true;
        }

        else if (!$TemDireito) // Verifica Direitos
        {
          $Status[] = array($NumeroDoTombo, 'Falta de Direitos', "Grupo:    {$Grupo->CodigoDoGrupo} - {$Grupo->Descricao}");
          $Status[] = array('',             '',                  "Opera��o: {$Operacao->CodigoDaOperacao} - {$Operacao->Descricao}");
          $Status[] = array('',             '',                  "G�nero:   {$CodigoDoGenero} - {$Genero->Descricao}");

          $EmprestimoImpedido = true;
        }


        if (!$EmprestimoImpedido)
        {
          $Politica = $BusinessPolitica->ObtemPolitica($CodigoDoGrupo, $CodigoDoGenero);
          if ($Politica)
          {
            $ArrayPolitica = $this->Politica[$CodigoDoGenero];
            $QuantidadeEmprestimos = $ArrayPolitica[3];
            $QuantidadePossivel = $ArrayPolitica[7];

            if ($QuantidadePossivel > 0)
            {
              $DataDevolucao = $BusinessEmprestimo->CalculaDataDevolucao($Politica->DiasDeEmprestimo);

              $NovoEmprestimo = new GnutecaEmprestimo;

              $Login = $MIOLO->login;
              $CodigoDoOperador = $Login->id;

              $NovoEmprestimo->CodigoDaPessoa             = $CodigoDaPessoa;
              $NovoEmprestimo->NumeroDoTombo              = $NumeroDoTombo;
              $NovoEmprestimo->DataHoraPrevisaoDevolucao  = $DataDevolucao;
              $NovoEmprestimo->CodigoDoOperadorEmprestimo = $CodigoDoOperador;

              $DataDevolucaoBr = MDate::DateOfDateTime($DataDevolucao);
              $DataDevolucaoBr = MDate::DateToData($DataDevolucaoBr);

              $BusinessEmprestimo->NovoEmprestimo($NovoEmprestimo);

              $Status[] = array($NumeroDoTombo, 'Empr�stimo com sucesso', $DataDevolucaoBr);
              $BusinessExemplar->AlteraEstado($NumeroDoTombo, $Transicao->CodigoDoEstadoFuturo);

              $this->Politica[$CodigoDoGenero][3] ++;
              $this->Politica[$CodigoDoGenero][7] --;
            }
            else
            {
              $Status[] = array($NumeroDoTombo, 'Limite Esgotado', "Grupo:  {$Grupo->CodigoDoGrupo} - {$Grupo->Descricao}");
              $Status[] = array('',             '',                "G�nero: {$CodigoDoGenero} - {$Genero->Descricao}");
            }
          }
          else
          {
            $Status[] = array($NumeroDoTombo, 'Falta Pol�tica', "Grupo:  {$Grupo->CodigoDoGrupo} - {$Grupo->Descricao}");
            $Status[] = array('',             '',               "G�nero: {$CodigoDoGenero} - {$Genero->Descricao}");
          }
        }
      }
    }
    if (count($Status)>0)
    {
      $Grade = new GnutecaGrid('Status do Empr�stimo', array('N�mero do Tombo',
                        'Status                              ', ''),   700, 200);
      $Grade->AdicionaLinhas($Status);
      $Grade->Exibe();
    }

    $this->ReinicializaJanela();
    $this->TrocaAmbiente(1); // J� deixa posicionado no Empr�stimo;
  }



  /***********************************************************/
  /* M�todo que Finaliza Devolu��o
  /* Dentre os C�digos de Exemplares lidos verifica
  /***********************************************************/
  function FinalizaDevolucao()
  {
    global $MIOLO;
    $BusinessEmprestimo = $MIOLO->GetBusiness('gnuteca','Emprestimo');
    $BusinessReserva    = $MIOLO->GetBusiness('gnuteca','Reserva');
    $BusinessExemplar   = $MIOLO->GetBusiness('gnuteca','Exemplar');
    $BusinessOperacao   = $MIOLO->GetBusiness('gnuteca','Operacao');
    $BusinessTransicao  = $MIOLO->GetBusiness('gnuteca','Transicao');
    $BusinessMulta      = $MIOLO->GetBusiness('gnuteca','Multa');
    $BusinessGrupo      = $MIOLO->GetBusiness('gnuteca','Grupo');
    $BusinessGenero     = $MIOLO->GetBusiness('gnuteca','Genero');
    $BusinessPessoa     = $MIOLO->GetBusiness('gnuteca','Pessoa');
    $BusinessPolitica   = $MIOLO->GetBusiness('gnuteca','Politica');
    $BusinessMaterial   = $MIOLO->GetBusiness('gnuteca','Material');
    $Operacao           = $BusinessOperacao->ObtemOperacaoPorMnemonico('DEVOLUCAO');

    $Login              = $MIOLO->login;
    $CodigoDoOperador   = $Login->id;

    for ($n=0; $n<$this->clistRows; $n ++)
    {
      $CodigoDoExemplar   = $this->clist->get_text($n,0);
      $Exemplar           = $BusinessExemplar->ObtemExemplar($CodigoDoExemplar);
      $NumeroDoTombo      = $Exemplar->NumeroDoTombo;
      $Emprestimo         = $BusinessEmprestimo->ObtemEmprestimoPorTombo($NumeroDoTombo);
      $CodigoDoEmprestimo = $Emprestimo->CodigoDoEmprestimo;

      if ($Emprestimo)
      {
        $Transicao    = $BusinessTransicao->ObtemTransicao($Exemplar->CodigoDoEstado,
                                                          $Operacao->CodigoDaOperacao);

        $Reservas = $BusinessReserva->ObtemReservas($NumeroDoTombo, array('SOLICITADA', 'COMUNICADA'));
        if ($Reservas)
        {
          $Reserva = $Reservas[0]; // primeira reserva
          $BusinessReserva->AlteraSituacao($Reserva->CodigoDaReserva, 'ATENDIDA');
          $BusinessReserva->ConfirmaReserva($Reserva, $NumeroDoTombo);

          $Status[] = array($NumeroDoTombo, 'Reserva', 'Atendida');
        }

        $BusinessEmprestimo->FinalizaEmprestimo($CodigoDoEmprestimo, $CodigoDoOperador);
        $BusinessExemplar->AlteraEstado($NumeroDoTombo, $Transicao->CodigoDoEstadoFuturo);

        // processa multa comeca aqui
        if ($Emprestimo->EstaAtrasado == 't')
        {
          $CodigoDoGrupo      = $BusinessPessoa->ObtemGrupo($Emprestimo->CodigoDaPessoa);

          $NumeroDaObra       = $Exemplar->NumeroDaObra;
          $CodigoDoGenero     = $BusinessMaterial->ObtemConteudoEtiqueta($NumeroDaObra,
                                                        GENERO_CAMPO, GENERO_SUBCAMPO);
          $Politica           = $BusinessPolitica->ObtemPolitica($CodigoDoGrupo, $CodigoDoGenero);

          if ($Politica)
          {
            $ValorDaMulta = $BusinessMulta->CalculaValor($Emprestimo->DataHoraPrevisaoDevolucao, $Politica->ValorDaMulta);
            $NovaMulta = new GnutecaReserva;
            $NovaMulta->CodigoDaMulta      = $BusinessMulta->ProximoCodigo();
            $NovaMulta->CodigoDaPessoa     = $Emprestimo->CodigoDaPessoa;
            $NovaMulta->CodigoDoEmprestimo = $CodigoDoEmprestimo;
            $NovaMulta->Valor = $ValorDaMulta;

            $BusinessMulta->NovaMulta($NovaMulta);
            $ValorDaMulta = number_format($ValorDaMulta, 2, ',','.');

            $Status[] = array($NumeroDoTombo, 'Multa Processada', "R\$ $ValorDaMulta");
          }
          else
          {
            $Grupo    = $BusinessGrupo->ObtemGrupo($CodigoDoGrupo);
            $Genero   = $BusinessGenero->ObtemGenero($CodigoDoGenero);

            $Status[] = array($NumeroDoTombo, 'Falta Pol�tica', "Grupo:  {$Grupo->CodigoDoGrupo} - {$Grupo->Descricao}");
            $Status[] = array('',             '',               "G�nero: {$CodigoDoGenero} - {$Genero->Descricao}");
          }
        }
        $Status[] = array($NumeroDoTombo, 'Devolu��o com sucesso', 'V');
      }
      else
      {
        $Status[] = array($NumeroDoTombo, 'N�o est� emprestado', 'X');
      }
    }

    $this->ReinicializaJanela();
    $this->TrocaAmbiente(1); // J� deixa posicionado no Empr�stimo;

    if (count($Status)>0)
    {
      $Grade = new GnutecaGrid('Status da Devolu��o', array('N�mero do Tombo',
                        'Status                              ', ''),   700, 200);
      $Grade->AdicionaLinhas($Status);
      $Grade->Exibe();
    }


  }

  /***********************************************************/
  /* Reseta vari�veis (atributos) da janela
  /***********************************************************/
  function ReinicializaJanela($ClearLists = true)
  {
    if ($ClearLists)
    {
      $this->clist->clear();
      $this->slist->clear();
      $this->clistRows = 0;
      $this->Direitos = null;
    }

    $this->CodigoDaPessoa->set_text('');
    $this->codigoLivro->set_text('');
    $this->senhaPessoa->set_text('');
    $this->NomeDaPessoa->set_text('');
    $this->nomeLivro->set_text('');
    $this->senhaPessoa->set_text('');
    $this->window->set_focus($this->CodigoDaPessoa);
  }


  /*******************************************************************************/
  /* Fun��o que verifica logo depois de ler o c�digo do usu�rio
  /*******************************************************************************/
  function verificaUsuario()
  {
    global $MIOLO;
    $BusinessPessoa = $MIOLO->GetBusiness('gnuteca', 'Pessoa');
    $CodigoDaPessoa = trim($this->CodigoDaPessoa->get_text());

    $Pessoa = $BusinessPessoa->ObtemPessoa($CodigoDaPessoa);
    $NomeDaPessoa = substr($Pessoa->Nome,0,36);

    //system("cat out.txt >/dev/tty");

    if (!$Pessoa)
    {
      $this->NomeDaPessoa->set_text('** N�o Encontrado **');
      return null;
    }

    $this->NomeDaPessoa->set_text($NomeDaPessoa);
    $CodigoDoGrupo = $BusinessPessoa->ObtemGrupo($CodigoDaPessoa);

    if (!$CodigoDoGrupo)
    {
      GnuTecaDialog::GnuTecaAviso('N�o Possui V�nculo');
      return null;
    }

    if (!trim($Pessoa->Senha))
    {
      $x = new GnutecaLogin;
      $x->AlteraSenha();
      GnuTecaDialog::GnuTecaAviso('N�o Possui Senha');
      return;
    }

    $BusinessMulta    = $MIOLO->GetBusiness('gnuteca', 'Multa');
    $TotalMultas      = $BusinessMulta->TotalMultas($CodigoDaPessoa);

    if ($TotalMultas>0)
    {
      $BusinessOperacao = $MIOLO->GetBusiness('gnuteca', 'Operacao');
      $BusinessDireito  = $MIOLO->GetBusiness('gnuteca', 'Direito');
      $Operacao         = $BusinessOperacao->ObtemOperacaoPorMnemonico('RETCMULTA');
      $TemDireito       = $BusinessDireito->VerificaDireito($CodigoDoGrupo, $Operacao->CodigoDaOperacao, GENERO_SISTEMA);

      if ($TemDireito)
      {
        GnuTecaDialog::GnuTecaAviso("Multa Pendente: $TotalMultas");
      }
      else
      {
        GnuTecaDialog::GnuTecaAviso("Pessoa com Multa: $TotalMultas");
        return null;
      }
    }

    $this->LeSenha();
    $this->CarregaNovoStatusDaPessoa($CodigoDaPessoa, $CodigoDoGrupo);
  }

  function LeSenha()
  {
    $this->window->set_focus($this->senhaPessoa);

    //system('./expin >/tmp/out.txt');
    //$fd = fopen('/tmp/out.txt', 'r');
    //$buffer = fgets($fd, 500);
    //fclose($fd);

    //$this->senhaPessoa->set_text($buffer);
    //$this->VerificaSenha();
    return $buffer;
  }

  /*******************************************************************************/
  /* fun��o que faz verifica��es logo depois de ler o c�digo do livro
  /*******************************************************************************/
  function VerificaLivro()
  {
    global $MIOLO;
    //$GNUTECA = $MIOLO->GetBusiness('gnuteca');
    $BusinessMaterial = $MIOLO->GetBusiness('gnuteca','Material');
    $BusinessExemplar = $MIOLO->GetBusiness('gnuteca','Exemplar');

    $CodigoDoExemplar = trim($this->codigoLivro->get_text());
    $Exemplar = $BusinessExemplar->ObtemExemplar($CodigoDoExemplar);
    $NumeroDaObra = $Exemplar->NumeroDaObra;

    if (($CodigoDoExemplar) && ($NumeroDaObra))
    {
      $TituloDaObra   = $BusinessMaterial->ObtemConteudoEtiqueta($NumeroDaObra, TITULO_CAMPO, TITULO_SUBCAMPO);
      $AutorDaObra    = $BusinessMaterial->ObtemConteudoEtiqueta($NumeroDaObra, AUTOR_CAMPO,  AUTOR_SUBCAMPO);
      $CodigoDoGenero = $BusinessMaterial->ObtemConteudoEtiqueta($NumeroDaObra, GENERO_CAMPO, GENERO_SUBCAMPO);

      $texts[0] = $CodigoDoExemplar;
      $texts[1] = $TituloDaObra;
      $texts[2] = $AutorDaObra;

      if (($this->clistRows >= $this->Direitos[$CodigoDoGenero]) && ($this->Ambiente == '1'))
      {
        GnuTecaDialog::GnuTecaAviso("Limite para este material esgotado");
      }
      else
      {
        $this->clist->append($texts);

        $TituloDaObra = substr($TituloDaObra,0,60);
        $this->nomeLivro->set_text($TituloDaObra);
        $this->clistRows ++;
      }
    }
    else
    {
      $this->nomeLivro->set_text('** N�o Encontrado **');
    }

    $this->codigoLivro->set_text('');

  }

  /*******************************************************************************/
  /* Verifica Senha
  /*******************************************************************************/
  function VerificaSenha()
  {
    global $MIOLO;
    //$GNUTECA = $MIOLO->GetBusiness('gnuteca');
    $BusinessPessoa = $MIOLO->GetBusiness('gnuteca','Pessoa');

    $CodigoAluno = $this->CodigoDaPessoa->get_text();
    $SenhaPessoa = $this->senhaPessoa->get_text();
    $SenhaValida = $BusinessPessoa->ValidaUsuario($CodigoAluno, $SenhaPessoa);

    if ($SenhaValida)
      $this->window->set_focus($this->codigoLivro);
    else
    {
      //GnuTecaDialog::GnuTecaAviso('Senha Incompat�vel');

      $this->Dialogo = new Dialogo('   Senha Incompat�vel, digite novamente  ', 200, 80);

      $this->Dialogo->dialog->add_events(GDK_KEY_PRESS_MASK);
      $this->Dialogo->dialog->connect_object('key_press_event', array(&$this->Dialogo, 'Fecha'));
      $this->Dialogo->dialog->connect_object_after('key_press_event', array(&$this, 'LeSenha'));

      $button = &new GtkButton('Fecha');

      $button->connect_object('clicked', array(&$this->Dialogo, 'Fecha'));
      $button->connect_object_after('clicked', array(&$this, 'LeSenha'));

      $this->Dialogo->bottombox->pack_start($button);
      $button->show();
      $this->Dialogo->Exibe();
    }
  }

  function KeyTestDialogo($p1)
  {
    $this->LeSenha();
  }

  /*******************************************************************************/
  /* Chama tela de ajuda
  /*******************************************************************************/
  function Ajuda()
  {
    $this->HelpWindow = &new GtkWindow;
    $this->HelpWindow->connect_object('delete-event', array(&$this,'FechaAjuda'));

    $this->HelpWindow->add_events(GDK_KEY_PRESS_MASK);
    $this->HelpWindow->connect_object('key_press_event', array(&$this,'KeyTest'), 'Ajuda');

    $this->HelpWindow->set_title('Ajuda');
    $this->HelpWindow->set_border_width(0);
    $this->HelpWindow->set_default_size(306, 246);
    $this->HelpWindow->set_position(GTK_WIN_POS_CENTER);
    $this->HelpWindow->set_uposition(60, 60);

    $vbox = &new GtkVBox();
    $vbox->set_uposition(0,12);
    $this->HelpWindow->add($vbox);
    $vbox->show();

    $col1 = &new GdkColor(0, 0, 0);
    $col2 = &new GdkColor(0, 56000, 32000);
    $style = &new GtkStyle;
    $style->fg[GTK_STATE_NORMAL] = $col1;
    $style->base[GTK_STATE_NORMAL] = $col2;
    $style->font = gdk::font_load ("-*-courier-*-r-*-*-*-180-*-*-*-*-*-*");

    $label = &new GtkLabel("[F1]  Ajuda\n" .
                           "[F2]  Opera��o Empr�stimo\n" .
                           "[F3]  Opera��o Devolu��o\n" .
                           "[F4]  Finaliza Opera��o\n\n" .

                           "[F6]  Reserva Material\n" .
                           "[F7]  Verifica Material\n" .
                           "[F8]  Verifica Usu�rio\n\n" .

                           "[F10] Hist�rico\n" .
                           "[F11] Outros\n" .
                           "[F12] Logout\n");
    $vbox->pack_start($label, false);
    $label->set_style($style);
    $label->set_justify(GTK_JUSTIFY_LEFT);
    $label->show();

    $this->HelpWindow->show();
  }

  /*******************************************************************************/
  /* Fun��o que fecha tela de ajuda
  /*******************************************************************************/
  function FechaAjuda()
  {
    $this->HelpWindow->hide();

  }

  function StatusDaPessoa()
  {
    $frame = &new GtkFrame('Status da Pessoa');
    $bbox = &new GtkHButtonBox();

    $bbox->set_border_width(5);
    $bbox->set_layout(GTK_BUTTONBOX_SPREAD);
    $bbox->set_spacing(2);
    $bbox->set_usize(594,120);
    $bbox->set_child_size(15, 20);
    $frame->add($bbox);
    $bbox->show();

    $scrolled_win = &new GtkScrolledWindow();
    $scrolled_win->set_border_width(5);
    $scrolled_win->set_policy(GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);

    $titles = array("Material", "Dias", "Direito", "Retirado", "Atraso", "Reservado", "Dispon�vel");

    $this->slist = &new GtkCList(7, $titles);
    $this->slist->connect_object('click_column', array(&$this,'slist_click_column'));

    $scrolled_win->add($this->slist);
    $this->slist->show();

    $bbox->pack_start($scrolled_win);
    $scrolled_win->show();

    $this->slist->set_row_height(18);
    $this->slist->set_usize(552, 100);

    $clist_rows = 0;

    $this->slist->set_column_width(0, 90);
    $this->slist->set_column_width(1, 70);
    $this->slist->set_column_width(2, 70);
    $this->slist->set_column_width(3, 70);
    $this->slist->set_column_width(4, 70);
    $this->slist->set_column_width(5, 70);
    $this->slist->set_column_width(6, 70);

    $frame->show();
    return $frame;
  }

  function slist_click_column($column)
  {
    global $MIOLO;
    $BusinessPessoa   = $MIOLO->GetBusiness('gnuteca','Pessoa');

    $CodigoDaPessoa = trim($this->CodigoDaPessoa->get_text());
    $Pessoa = $BusinessPessoa->ObtemPessoa($CodigoDaPessoa);
    $NomeDaPessoa = substr($Pessoa->Nome,0,36);

    if (!$Pessoa)
      return;

    if ($column == 6)
    {
      $BusinessReserva  = $MIOLO->GetBusiness('gnuteca','Reserva');
      $BusinessExemplar = $MIOLO->GetBusiness('gnuteca','Exemplar');
      $BusinessMaterial = $MIOLO->GetBusiness('gnuteca','Material');

      $MIOLO->Uses('MDate.class');

      $Reservas = $BusinessReserva->ObtemReservasPorPessoa($CodigoDaPessoa, array('ATENDIDA'), true);

      if ($Reservas)
      {
        foreach ($Reservas as $Reserva)
        {
          $Exemplar = $BusinessExemplar->ObtemExemplarPorTombo($Reserva->NumeroDoTombo);
          $NumeroDaObra = $Exemplar->NumeroDaObra;
          $TituloDaObra = $BusinessMaterial->ObtemConteudoEtiqueta($NumeroDaObra,
                                            TITULO_CAMPO, TITULO_SUBCAMPO);

          $DataHoraDaReserva = MDate::DateOfDateTime($Reserva->DataHoraDaReserva);
          $DataHoraDaReserva = MDate::DateToData($DataHoraDaReserva);

          $DataHoraLimite = MDate::DateOfDateTime($Reserva->DataHoraLimite);
          $DataHoraLimite = MDate::DateToData($DataHoraLimite);


          $Status[] = array($Exemplar->NumeroDoTombo, $TituloDaObra, $DataHoraDaReserva, $DataHoraLimite, $Reserva->Situacao );
        }

        if (count($Status)>0)
        {
          $this->Grade = new GnutecaGrid("Reservas de $NomeDaPessoa", array('C�digo      ',
                            'T�tulo                                                              ',
                            'Data Reserva ', 'Data Limite   ', 'Situa��o'),
                            592, 222);

          $this->Grade->AdicionaLinhas($Status);
          $this->Grade->Exibe();
        }
      }
      else
      {
          GnuTecaDialog::GnuTecaAviso('N�o possui reservas dispon�veis');
      }
    }
    elseif ($column == 3)
    {
      $BusinessEmprestimo = $MIOLO->GetBusiness('gnuteca','Emprestimo');
      $BusinessMaterial = $MIOLO->GetBusiness('gnuteca','Material');
      $BusinessExemplar = $MIOLO->GetBusiness('gnuteca','Exemplar');

      $MIOLO->Uses('MDate.class');

      if ($Pessoa)
      {
        $Emprestimos = $BusinessEmprestimo->ObtemEmprestimosPorPessoa($CodigoDaPessoa);

        if ($Emprestimos)
        {
          foreach ($Emprestimos as $Emprestimo)
          {
            $Exemplar = $BusinessExemplar->ObtemExemplarPorTombo($Emprestimo->NumeroDoTombo);
            $NumeroDaObra = $Exemplar->NumeroDaObra;
            $TituloDaObra = $BusinessMaterial->ObtemConteudoEtiqueta($NumeroDaObra,
                                              TITULO_CAMPO, TITULO_SUBCAMPO);

            $texts[0] = $Emprestimo->NumeroDoTombo;
            $texts[1] = $TituloDaObra;
            $texts[2] = $Emprestimo->DataHoraDoEmprestimo;
            $texts[3] = $Emprestimo->DataHoraPrevisaoDevolucao;

            $texts[2] = MDate::DateOfDateTime($texts[2]);
            $texts[2] = MDate::DateToData($texts[2]);

            $texts[3] = MDate::DateOfDateTime($texts[3]);
            $texts[3] = MDate::DateToData($texts[3]);

            $Status[] = $texts;
          }
        }
        else
        {
            GnuTecaDialog::GnuTecaAviso('N�o possui empr�stimos');
        }

        if (count($Status)>0)
        {
          $Grade = new GnutecaGrid("Empr�stimos de $NomeDaPessoa", array('C�digo      ',
                            'T�tulo                                                              ',
                            'Emprestado  ', 'Devolu��o  '),
                            592, 222);

          $Grade->AdicionaLinhas($Status);
          $Grade->Exibe();
        }
      }
    }
  }


  function CarregaNovoStatusDaPessoa($CodigoDaPessoa, $CodigoDoGrupo)
  {
    global $MIOLO;
    $BusinessPolitica   = $MIOLO->GetBusiness('gnuteca','Politica');
    $BusinessGenero     = $MIOLO->GetBusiness('gnuteca','Genero');
    $BusinessEmprestimo = $MIOLO->GetBusiness('gnuteca','Emprestimo');
    $BusinessMaterial   = $MIOLO->GetBusiness('gnuteca','Material');
    $BusinessExemplar   = $MIOLO->GetBusiness('gnuteca','Exemplar');
    $BusinessReserva    = $MIOLO->GetBusiness('gnuteca','Reserva');

    $this->slist->clear();
    $QuantidadeEmprestimos = null;
    $QuantidadeReservas = null;
    $QuantidadeEmprestimosEmAtraso = null;
    $QuantidadeReservasDisponiveis = null;

    $Politicas = $BusinessPolitica->ObtemPoliticasPorGrupo($CodigoDoGrupo);
    $Emprestimos = $BusinessEmprestimo->ObtemEmprestimosPorPessoa($CodigoDaPessoa);

    $Reservas1 = $BusinessReserva->ObtemReservasPorPessoa($CodigoDaPessoa, array('ATENDIDA'), true);
    $Reservas2 = $BusinessReserva->ObtemReservasPorPessoa($CodigoDaPessoa, array('SOLICITADA', 'COMUNICADA'));
    $Reservas = array_merge($Reservas1,$Reservas2);

    if ($Emprestimos)
      foreach ($Emprestimos as $Emprestimo)
      {
        $Exemplar = $BusinessExemplar->ObtemExemplarPorTombo($Emprestimo->NumeroDoTombo);
        $NumeroDaObra = $Exemplar->NumeroDaObra;
        $CodigoDoGenero = $BusinessMaterial->ObtemConteudoEtiqueta($NumeroDaObra,
                                             GENERO_CAMPO, GENERO_SUBCAMPO);

        $QuantidadeEmprestimos[$CodigoDoGenero] ++;

        if ($Emprestimo->EstaAtrasado == 't')
        {  $QuantidadeEmprestimosEmAtraso[$CodigoDoGenero] ++; }
      }

    if ($Reservas)
      foreach ($Reservas as $Reserva)
      {
        $Exemplar = $BusinessExemplar->ObtemExemplarPorTombo($Reserva->NumeroDoTombo);
        $NumeroDaObra = $Exemplar->NumeroDaObra;
        $CodigoDoGenero = $BusinessMaterial->ObtemConteudoEtiqueta($NumeroDaObra,
                                             GENERO_CAMPO, GENERO_SUBCAMPO);

        $QuantidadeReservas[$CodigoDoGenero] ++;
        if ($Reserva->Mnemonico == 'ATENDIDA')
        {  $QuantidadeReservasDisponiveis[$CodigoDoGenero] ++; }
      }

    $this->Politica = null;
    $this->Direitos = null;
    foreach ($Politicas as $Politica)
    {
      $CodigoDoGenero = $Politica->CodigoDoGenero;
      if ($CodigoDoGenero)
      {
        $Genero = $BusinessGenero->ObtemGenero($CodigoDoGenero);

        $text[0] = $Genero->Descricao;
        //dias
        $text[1] = $Politica->DiasDeEmprestimo;

        $text[2] = $Politica->LimiteDeEmprestimo;                        // direito
        $text[3] = $QuantidadeEmprestimos[$CodigoDoGenero];              // retirado
        $text[4] = $QuantidadeEmprestimosEmAtraso[$CodigoDoGenero];      // atraso
        $text[5] = $QuantidadeReservas[$CodigoDoGenero];                 // reservado
        $text[6] = $QuantidadeReservasDisponiveis[$CodigoDoGenero];      // disponivel


        $this->Direitos[$CodigoDoGenero] = $Politica->LimiteDeEmprestimo -
                                           $QuantidadeEmprestimos[$CodigoDoGenero]; // possivel

        $this->slist->append($text);

        $text[7] = $Politica->LimiteDeEmprestimo - $QuantidadeEmprestimos[$CodigoDoGenero];
        $this->Politica[$Genero->CodigoDoGenero] = $text;
      }
    }
  }

  /*******************************************************************************/
  /* Remove item da lista com a tecla DEL
  /*******************************************************************************/
  function RemoveDaLista()
  {
    $this->clist->freeze();
    $selection = $this->clist->selection;

    while (($row = $this->clist->selection[0]) !== null) {
      $this->clist->remove($row);
      $this->clistRows --;
      if ($clist->selection_mode == GTK_SELECTION_BROWSE)
        break;
    }

    if ($this->clist->selection_mode == GTK_SELECTION_EXTENDED &&
      $this->clist->selection[0] === null && $this->clist->focus_row >= 0)
      $this->clist->select_row($this->clist->focus_row, -1);
    $this->clist->thaw();
  }

  /*******************************************************************************/
  /* Cria Caixa com bot�es para consulta
  /*******************************************************************************/
  function CreateEntryBox(&$field, $max_lenght, $title)
  {
    $frame = &new GtkFrame($title);
    $bbox = &new GtkHButtonBox();

    $bbox->set_border_width(5);
    $bbox->set_layout(GTK_BUTTONBOX_SPREAD);
    $bbox->set_spacing(2);
    $bbox->set_child_size(15, 20);
    $frame->add($bbox);
    $bbox->show();

    $field->set_text('');
    $field->add_events(GDK_KEY_PRESS_MASK);
    $field->set_max_length($max_lenght);
    $bbox->pack_start($field, false, true);
    $field->show();

    $frame->show();
    return $frame;
  }

  /*******************************************************************************/
  /* Cria Caixa com bot�es para consulta
  /*******************************************************************************/
  function CreateLabelBox(&$field, $usize1, $usize2, $title)
  {
    $frame = &new GtkFrame($title);
    $bbox = &new GtkHButtonBox();

    $bbox->set_border_width(5);
    $bbox->set_usize($usize1,$usize2);
    $bbox->set_layout(GTK_BUTTONBOX_SPREAD);
    $bbox->set_spacing(2);
    $bbox->set_child_size(15, 20);
    $frame->add($bbox);
    $bbox->show();

    $col1 = &new GdkColor(56000, 0, 0);
    $col2 = &new GdkColor(0, 56000, 32000);
    $style = &new GtkStyle;
    $style->fg[GTK_STATE_NORMAL] = $col1;
    $style->base[GTK_STATE_NORMAL] = $col2;
    $style->font = gdk::font_load ("-adobe-helvetica-bold-r-*-*-*-140-*-*-*-*-*-*");

    $bbox->pack_start($field, false, true);
    $field->set_justify(GTK_JUSTIFY_LEFT);
    $field->set_style($style);
    $field->show();

    $frame->show();
    return $frame;
  }

  /*******************************************************************************/
  /* Cria Caixa com bot�es para consulta
  /*******************************************************************************/
  function CreateHeaderBox($title)
  {
    $frame = &new GtkFrame($title);
    $bbox  = &new GtkHButtonBox();

    $bbox->set_border_width(5);
    $bbox->set_usize(594,20);
    $bbox->set_layout(GTK_BUTTONBOX_SPREAD);
    $bbox->set_spacing(2);
    $bbox->set_child_size(15, 20);
    $frame->add($bbox);
    $bbox->show();

    $col1 = &new GdkColor(0, 0, 56000);
    $col2 = &new GdkColor(0, 56000, 32000);
    $style = &new GtkStyle;
    $style->fg[GTK_STATE_NORMAL] = $col1;
    $style->base[GTK_STATE_NORMAL] = $col2;
    $style->font = gdk::font_load ("-adobe-helvetica-bold-r-*-*-*-128-*-*-*-*-*-*");

    /*$Functions = &new GtkLabel('[F1] Ajuda     [F2] Empr�stimo      [F3] Devolu��o      [F4] Finaliza      [F12] Logout');
    $bbox->pack_start($Functions, false, true);
    $Functions->set_justify(GTK_JUSTIFY_LEFT);
    $Functions->set_style($style);
    $Functions->show();*/

    $aFunctions[0] = '[F1] Ajuda';
    $aFunctions[1] = '[F2] Empr�stimo';
    $aFunctions[2] = '[F3] Devolu��o';
    $aFunctions[3] = '[F4] Finaliza';
    $aFunctions[4] = '[F12] Logout';

    foreach ($aFunctions as $Key => $aFunction)
    {
      $this->Functions[$Key] = &new GtkLabel($aFunction);
      $bbox->pack_start($this->Functions[$Key], true, true);
      $this->Functions[$Key]->set_justify(GTK_JUSTIFY_LEFT);
      $this->Functions[$Key]->set_style($style);
      $this->Functions[$Key]->show();
    }

    $this->LoadHeader();

    $frame->show();
    return $frame;
  }

  function LoadHeader()
  {
    $col1 = &new GdkColor(0, 0, 56000);
    $col2 = &new GdkColor(0, 56000, 32000);
    $style = &new GtkStyle;
    $style->fg[GTK_STATE_NORMAL] = $col1;
    $style->base[GTK_STATE_NORMAL] = $col2;
    $style->font = gdk::font_load ("-adobe-helvetica-bold-r-*-*-*-128-*-*-*-*-*-*");

    $col1_ = &new GdkColor(56000, 0, 0);
    $col2_ = &new GdkColor(0, 56000, 32000);
    $style_ = &new GtkStyle;
    $style_->fg[GTK_STATE_NORMAL] = $col1_;
    $style_->base[GTK_STATE_NORMAL] = $col2_;
    $style_->font = gdk::font_load ("-adobe-helvetica-bold-r-*-*-*-128-*-*-*-*-*-*");

    if ($this->Ambiente=='1')
    {
      $this->Functions[1]->set_style($style_);
      $this->Functions[2]->set_style($style);
    }
    else
    {
      $this->Functions[1]->set_style($style);
      $this->Functions[2]->set_style($style_);
    }
  }
}
?>
