<?php

$thename = "Slashdot";
$bgcolor1 = "#CCCCCC";
$bgcolor2 = "#006666";
$bgcolor3 = "#5272a4";
$textcolor1 = "#FFFFFF";
$textcolor2 = "#000000";
$hr = 0; # 1 to have horizonal rule in comments instead of table bgcolor


function themeindex($aid, $informant, $datetime, $title, $counter, $topic, $thetext, $notes, $morelink, $topicname, $topicimage, $topictext) {
	global $tipath, $anonymous;
	if ("$aid" == "$informant") { ?>
		<p><table width="99%" cellpadding=0 cellspacing=0 border=0><tr><td valign=top bgcolor="#006666"><img src="themes/Slashdot/slc.gif" width=13 height=16 alt="" align=top><font size=4 color="#FFFFFF"><b><?php echo"$title"; ?></b></td></tr></table><b><?php echo translate ("Posted by "); ?> <?php formatAidHeader($aid) ?> <?php echo translate("on"); ?> <?php echo"$datetime $timezone</b>"; ?><br>(<?php echo $counter; ?> <?php echo translate("reads"); ?>)
		<a href="search.php?query=&topic=<?php echo"$topic"; ?>&author="><img src=<?php echo"$tipath$topicimage"; ?> border=0 Alt=<?php echo"\"$topictext\""; ?> align=right hspace=10 vspace=10 border=0></a>
		<br><?php echo"$thetext<br><br>$morelink"; ?>
<?php	} else {
		if($informant != "") $boxstuff = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
		else $boxstuff = "$anonymous ";
		$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes"; ?>
		<p><table width="99%" cellpadding=0 cellspacing=0 border=0><tr><td valign=top bgcolor="#006666"><img src="themes/Slashdot/slc.gif" width=13 height=16 alt="" align=top><font size=4 color="#FFFFFF"><b><?php echo"$title"; ?></b></td></tr></table><b><?php echo translate ("Posted by "); ?> <?php formatAidHeader($aid); ?> <?php echo translate("on"); ?> <?php echo"$datetime $timezone</b>"; ?><br>(<?php echo $counter; ?> <?php echo translate("reads"); ?>)
		<a href="search.php?query=&topic=<?php echo"$topic"; ?>&author="><img src=<?php echo"$tipath$topicimage"; ?> border=0 Alt=<?php echo"\"$topictext\""; ?> align=right hspace=10 vspace=10 border=0></a>
		<br><?php echo"$boxstuff<br><br>$morelink"; ?>
<?php	}
}

function themearticle ($aid, $informant, $datetime, $title, $thetext) {
	global $admin, $sid, $tipath;
	if ("$aid" == "$informant") { ?>
		<p><table width="99%" cellpadding=0 cellspacing=0 border=0><tr><td valign=top bgcolor="#006666"><img src="themes/Slashdot/slc.gif" width=13 height=16 alt="" align=top><font size=4 color="#FFFFFF"><b><?php echo"$title"; ?></b></td></tr></table><b><?php echo translate("Posted by "); ?> <?php formatAidHeader($aid) ?> <?php echo translate("on"); ?> <?php echo"$datetime $timezone"; ?></b><br><?php echo"$thetext"; ?>
<?php	} else {
		if($informant != "") $boxstuff = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
		else $boxstuff = "$anonymous ";
		$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes";
?>		<p><table width="99%" cellpadding=0 cellspacing=0 border=0><tr><td valign=top bgcolor="#006666"><img src="themes/Slashdot/slc.gif" width=13 height=16 alt="" align=top><font size=4 color="#FFFFFF"><b><?php echo"$title"; ?></b></td></tr></table><b><?php echo translate("Posted by "); ?> <?php formatAidHeader($aid); ?> <?php echo translate("on"); ?> <?php echo"$datetime $timezone"; ?></b><br><?php echo"$boxstuff"; ?>
<?php	}
}

function themesidebox($title, $content) { ?>
	<table cellpadding=1 cellspacing=0 border=0 width="160" align=center>
	<tr bgcolor="#006666">
	<td valign=top><font size=4 color="#FFFFFF"><B><?php echo"$title"; ?></B></font></td>
	</tr><tr><td bgcolor="#CCCCCC">	<?php echo"$content"; ?>
	</td>
	</tr>
	</table><P>
<?php
}

?>
