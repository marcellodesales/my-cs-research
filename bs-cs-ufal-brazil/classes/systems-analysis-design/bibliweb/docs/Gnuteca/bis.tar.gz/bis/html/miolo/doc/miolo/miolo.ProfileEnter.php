<html>
<head>
 <title> MIOLO - miolo:ProfileEnter</title>
 <link rel="stylesheet" href="/miolo/doc/doc.css">
</head>
<body>
<? include '/usr/local/bis/html//miolo/doc/header.inc' ?>
<h3 align="right">Classe: <a href="/miolo/doc/miolo/miolo.class.php">MIOLO</a></h3>
<h2>ProfileEnter($name)</h2>
<p>a fun��o ProfileEnter est� utilizada para rastrear o tempo de execu��o de
determinados setores de c�digo. A fun��o deve ser utilizado em conjunto com a
fun��o <a href="miolo.ProfileExit.php"><tt>ProfileExit</tt></a>.</p>
<h3>Par�metros:</h3>
<dl>
 <dt>$name</dt>
 <dd>Nome utilizado como identificador para o contador do tempo percorrido.</dd>
</dl>
<p>&nbsp;</p>
<pre>
<?php
highlight_string(
'<?php
    function foo()
    { global $MIOLO;
      $miolo->ProfileEnter("foo"); 
      ...
      // processamento de outras instru��es
      ...
      $miolo->ProfileExit("foo");       
    }
?>');
?>
</pre>
<? include '/usr/local/bis/html//miolo/doc/footer.inc' ?>
</body>
</html>
