<?php

$thename = "Default";
$bgcolor1 = "#e0e0e0";
$bgcolor2 = "#999999";
$bgcolor3 = "#000000";
$textcolor1 = "#000000";
$textcolor2 = "#000000";
$hr = 0; # 1 to have horizonal rule in comments instead of table bgcolor


function themeindex ($aid, $informant, $time, $title, $counter, $topic, $thetext, $notes, $morelink, $topicname, $topicimage, $topictext) {
	global $tipath, $anonymous;
	if ("$aid" == "$informant") { ?>

&nbsp;

<table border=0 cellpadding=0 cellspacing=0 width=100%>
<tr>
        
    <td width=100%><font face=Arial,Helvetica,sans-serif size=5><b><?php echo"$title"; ?></b><br></font>
    <font face=Arial,Helvetica,sans-serif size=1><?php echo translate("Posted by "); ?> <?php formatAidHeader($aid) ?> <?php echo translate("on"); ?> <?php echo"$time $timezone"; ?><!-- (<?php echo translate("read:"); ?> <?php echo $counter; ?> <?php echo translate("times"); ?>) --><br></font>
    <div align=justify><font face=Arial,Helvetica,sans-serif size=2><? echo "$thetext"; ?><br>
    <? echo "$morelink"; ?> | <a href="search.php?query=&topic=<?php echo"$topic"; ?>&author="><?php echo"$topictext"; ?></a><br></font>
    &nbsp;</div></td>
		
		<td width=10><img src=images/spot.gif width=10 height=1></td>
                
</tr>
</table>
<table border=0 cellpadding=0 cellspacing=0 width=100%>
<tr>
        
    <td bgcolor=#e0e0e0><img src=images/nada.gif width=1 height=1 border=0></td>
            
</tr>
</table>

<?php	} else {
		if($informant != "") $boxstuff = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
		else $boxstuff = "$anonymous ";
		$boxstuff .= "".translate("writes")." \"$thetext\" $notes";
?>

<table border=0 cellpadding=0 cellspacing=4 width=100%><tr><td>
<table border=0 cellpadding=0 cellspacing=0 width=100%>

<tr><td><font face=Arial,Helvetica,sans-serif size=4><b><?php echo"$title"; ?></b></font></td></tr>
<!--  --><tr><td><font face=Arial,Helvetica,sans-serif size=1><?php echo translate("Posted by "); ?> <?php formatAidHeader($aid) ?> <?php echo translate("on"); ?> <?php echo"$time $timezone"; ?></b> (<?php echo translate("read:"); ?> <?php echo $counter; ?> <?php echo translate("times"); ?>)</td> -->
</tr>
<tr><td bgcolor="#e0e0e0"><img src="images/nada.gif" width="1" height="1" border="0"></td></tr>
<tr>
<td>
<table border=0 cellspacing=0 cellpadding=4 width=100%>
<tr>
<td bgcolor="#FFFFFF">
<font face=Arial,Helvetica,sans-serif size=2><?php echo"$topictext"; ?>: <? echo "$boxstuff"; ?></font></td>
</tr><tr>
<td bgcolor=#FFFFFF>
<font face=Arial,Helvetica,sans-serif size=2><? echo "$morelink"; ?> | <a href="search.php?query=&topic=<?php echo"$topic"; ?>&author="><?php echo"$topictext"; ?></a></font></td></tr>
</table></td></tr>
<tr><td bgcolor="#e0e0e0"><img src="images/nada.gif" width="1" height="1" border="0" alt=""></td></tr>
</table>
</td></tr></table>

<?php	}
}

function themearticle ($aid, $informant, $datetime, $title, $thetext, $topic, $topicname, $topicimage, $topictext) {
	global $admin, $sid, $tipath;
	if ("$aid" == "$informant") {
echo"

<table border=0 cellpadding=0 cellspacing=0 align=center width=100%><tr><td>
<table border=0 cellpadding=0 cellspacing=0 align=center width=100%>
<tr><td><font face=Arial,Helvetica,sans-serif size=5><b>$title</b></font><td></tr>
<tr><td><font face=Arial,Helvetica,sans-serif size=1>".translate("Posted on ")." $datetime av $aid";
if ($admin) {
    echo "&nbsp;&nbsp; [ <a href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]";
}

echo "
</font></td>
</tr>
<tr><td bgcolor=#999999><img src='images/nada.gif' width='1' height='1' border='0' alt=''></td></tr>
<tr>
<td>
<table border=0 cellspacing=0 cellpadding=0 width=100%>
<tr>
<td bgcolor=ffffff><font face='Times New Roman,Times,serif' size='3'><div style='font-size: 12pt' align='justify'>&nbsp;<br><!-- <a href=search.php?query=&topic=$topic&author=><img src=$tipath$topicimage border=0 Alt=\"$topictext\" align=right></a> -->$thetext<br>&nbsp;</div></font></td>
</tr></table>
</td>
</tr>
<tr><td bgcolor=#999999><img src=images/nada.gif width=1 height=1 border=0></td></tr>
</table>
</td></tr></table>
";

	} else {
		if($informant != "") $informant = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
		else $boxstuff = "$anonymous ";
		$boxstuff .= "".translate("writes")." \"$thetext\" $notes";
echo "

<table border=0 cellpadding=0 cellspacing=0 align=center width=100%><tr><td>
<table border=0 cellpadding=0 cellspacing=0 align=center width=100%>

<tr><td><font face=Arial,Helvetica,sans-serif size=5><b>$title</b></font><td></tr>
<tr><td><font face=Arial,Helvetica,sans-serif size=1>".translate("Contributed by ")." $datetime";
if ($admin) {
    echo "&nbsp;&nbsp; [ <a href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]";
}
echo "
</font></td>
</tr>
<tr><td bgcolor=#999999><img src=images/nada.gif width=1 height=1 border=0></td></tr>
<tr>
<td><table border=0 cellspacing=0 cellpadding=0 width=100%>
<tr>
<td><font face='Times New Roman,Times,serif' size='3'><div style='font-size: 12pt' align='justify'><!-- <a href=search.php?query=&topic=$topic&author=><img src=$tipath$topicimage border=0 Alt=\"$topictext\" align=right hspace=10 vspace=10></a> -->$thetext<br>&nbsp;</div></font></td>
</tr></table>
</td>
</tr>
<tr><td bgcolor=#999999><img src=images/nada.gif width=1 height=1 border=0></td></tr>
</table>
</td></tr></table>



";

	}
}


function themesidebox($title, $content) {
    echo "
    <table width=100% border=0 cellspacing=0 cellpadding=0>
		<tr>
		
					 			<td width=100% bgcolor=#868686 valign=top><font color=ffffff><b>$title</b></font></td>
				
    </tr>
		<tr>
		
								<td width=100% valign=top>$content<br>&nbsp;</td>
				
    </tr></table>";
}

?>