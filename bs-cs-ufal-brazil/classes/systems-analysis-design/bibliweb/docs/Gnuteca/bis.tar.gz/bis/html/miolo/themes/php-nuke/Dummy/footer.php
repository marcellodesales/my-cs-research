<?php

  include("themes/Dummy/vars.php");
  if ($index == 1) {
	echo "<td>&nbsp;</td><td valign=\"top\">";
    category();
  if($show_poll)
    pollNewest();
  
  loginbox();
  userblock();
  oldNews($storynum);
  bigstory();
  rightblocks();
  echo "</td>";
}
echo "</tr></table></td></tr></table>";
footmsg();
?>
