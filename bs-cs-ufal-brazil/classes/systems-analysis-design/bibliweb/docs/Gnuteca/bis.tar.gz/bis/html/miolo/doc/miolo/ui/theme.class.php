<html>
<head>
 <title> MIOLO - Classe theme</title>
 <link rel="stylesheet" href="/miolo/doc/doc.css">
</head>
<body>
<? include '/usr/local/bis/html//miolo/doc/header.inc' ?>
<h2>Classe: Theme</h2>
<blockquote>
extends <a href="#.class.php">SuperClasse</a>
</blockquote>
<p>TODO: Escrever documenta��o da classe Theme.</p>
<h3>M�todos:</h3>
<dl>
 <dt><a href="/miolo/doc/miolo/ui/theme.Theme.php">Theme($name)</a></dt>
 <dd>Descri��o do m�todo Theme. </dd>
 <dt><a href="/miolo/doc/miolo/ui/theme.AddStyle.php">AddStyle($url)</a></dt>
 <dd>Descri��o do m�todo AddStyle. </dd>
 <dt><a href="/miolo/doc/miolo/ui/theme.AddScript.php">AddScript($url)</a></dt>
 <dd>Descri��o do m�todo AddScript. </dd>
 <dt><a href="/miolo/doc/miolo/ui/theme.Generate.php">Generate()</a></dt>
 <dd>Descri��o do m�todo Generate. </dd>
 <dt><a href="/miolo/doc/miolo/ui/theme.GenerateElements.php">GenerateElements($elements)</a></dt>
 <dd>Descri��o do m�todo GenerateElements. </dd>
</dl>
<p>&nbsp;</p>
<? include '/usr/local/bis/html//miolo/doc/footer.inc' ?>
</body>
</html>
