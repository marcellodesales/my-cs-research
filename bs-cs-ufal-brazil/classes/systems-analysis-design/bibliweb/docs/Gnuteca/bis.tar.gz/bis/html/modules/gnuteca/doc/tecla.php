<?
/***********************************************************/
/* Classe que cria Di�logos                                */
/* Linguagem PHP-GTK                                       */
/* Autor: Pablo Dall'Oglio                                 */
/* �ltima atera��o em 04 setembro 2001 por Pablo           */
/***********************************************************/

function KeyTest($p1)
{
    echo $p1->keyval . "\n";
}

if (strtoupper(substr(PHP_OS, 0, 3)) == 'WIN')
  dl('php_gtk.dll');
else
  dl('php_gtk.so');

$window = &new GtkWindow;
$window->set_title('Capturador de Teclas Tabajara');
$window->set_border_width(0);
//$window->set_default_size(400, 50);
$window->set_uposition(80, 80);

$window->add_events(GDK_KEY_PRESS_MASK);
$window->connect_object('key_press_event', 'KeyTest');

$window->realize();

$box = &new GtkVBox();
$window->add($box);
$box->show();

list($pixmap, $mask) = Gdk::pixmap_create_from_xpm($window->window, null, "tecla.xpm");
$pixmapwid = &new GtkPixmap($pixmap, $mask);
$box->pack_start($pixmapwid);
$pixmapwid->show();
$window->show();

$window->show();

Gtk::main();
?>
