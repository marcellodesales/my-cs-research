<?php

$thename = "Akki";
$bgcolor1 = "#CCCCCC";
$bgcolor2 = "#787878";
$bgcolor3 = "#CCCCCC";
$bgcolor4 = "#787878";
$textcolor1 = "#FFFFFF";
$textcolor2 = "#000000";
$hr = 1; # 1 to have horizonal rule in comments instead of table bgcolor

function themeindex ($aid, $informant, $time, $title, $counter, $topic, $thetext, $notes, $morelink, $topicname, $topicimage, $topictext) {
	if ("$aid" == "$informant") { ?>


<table border=0 cellpadding=0 cellspacing=0 align=center width=100%>
<tr><td>

<table border=0 cellpadding=0 cellspacing=0 width=100%>


<TR>
<TD bgcolor=#99ccff>
<font face="verdana" size=2 class=default>..\Home\Top
    news - <b><?php echo"$title"; ?></b> -</font></TD><td align=right bgcolor=#99ccff><img src=themes/Akki/images/bluefadebg.gif border=0 width=36 height="17"></td></TR><TR><TD bgcolor=#ffffff colspan=2><font face=verdana size=2 class=default>
<!--share--></font><font face=verdana size=2 class=default><img src="themes/Akki/images/downsq.gif" border=0 align=bottom hspace=2 width=9 height=9></font><font face=verdana size=2 class=default><?php echo translate("Posted by "); ?><b><?php formatAidHeader($aid) ?></b> <?php echo translate("on"); ?> <?php echo"$time $timezone"; ?> (<?php echo $counter; ?> <?php echo translate("reads"); ?>)</font>
<font class=defaultsmall face=verdana color="#000000">
<table border=0 cellpadding=0 cellspacing=0 width=100%><tr><td bgcolor=#d9d9ff><img src="themes/Akki/images/webtools_1x1.gif" width=1 height=1 border=0></td></tr></table>
</font>


<a href="search.php?query=&topic=<?php echo"$topic"; ?>&author=">
<img src=<?php echo"$tipath$topicimage"; ?> border=0 Alt=<?php echo"\"$topictext\""; ?> align=right hspace=10 vspace=10></a>
<?php echo"$thetext<br><br>
</td></tr><tr>
<tr>
<td border=0 bgcolor=cccccc width=100% align=right>
<font size=2>$morelink"; ?>

</TD><td border=0 align=right bgcolor=#cccccc></td></TR>


</tr>
</table>
</td>
</tr>
</table>













<?php	} else {
		if($informant != "") $boxstuff = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
		else $boxstuff = "$anonymous ";
		$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes";
?>
<table border=0 cellpadding=0 cellspacing=0 align=center bgcolor=000000 width=100%>
<tr><td>

<table border=0 cellpadding=3 cellspacing=1 width=100%>
<tr><td bgcolor=CCCCCC>
<b><?php echo"$title"; ?></b><br>
<font size=1>
<?php echo translate("Posted by "); ?><?php formatAidHeader($aid); ?> <?php echo translate("on"); ?> <?php echo"$time $timezone"; ?> (<?php echo $counter; ?> <?php echo translate("reads"); ?>)<br>
</td>
</tr>
<tr>
<td bgcolor=ffffff>
<a href="search.php?query=&topic=<?php echo"$topic"; ?>&author="><img src=<?php echo"$tipath$topicimage"; ?> border=0 Alt=<?php echo"\"$topictext\""; ?> align=right hspace=10 vspace=10></a>
<?php echo"$boxstuff<br><br>
</td></tr><tr><td bgcolor=CCCCCC align=right>
<font size=2>$morelink"; ?>
</td>
</tr>
</table>
</td>
</tr>
</table><br>

<?php	}
}

function themearticle ($aid, $informant, $datetime, $title, $thetext, $topic, $topicname, $topicimage, $topictext) {
	if (!$config_called) {if (!isset($config)) {if (!isset($config)) { include("config.php"); }}}
	if ("$aid" == "$informant") {

echo"

<table border=0 cellpadding=0 cellspacing=0 align=center width=100%>
<tr><td>

<table border=0 cellpadding=0 cellspacing=0 width=100%>


<TR>
<TD bgcolor=#99ccff>
<font face=verdana size=2 class=default><b>$title</b></font>
</TD><td align=right bgcolor=#99ccff><img src=themes/Akki/images/bluefadebg.gif border=0 width=36 height=17></td></TR><TR><TD bgcolor=#ffffff colspan=2>

<font face=verdana size=2 class=default>
<!--share--></font><font face=verdana size=2 class=default><img src=themes/Akki/images/downsq.gif border=0 align=bottom hspace=2 width=9 height=9></font>

<font face=verdana size=2 class=default><font size=1>".translate("Posted on ")." $datetime
";

global $admin, $sid;
if ($admin) {
    echo "&nbsp;&nbsp; $font2 [ <a href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]";
}

echo "
</font>


<font class=defaultsmall face=verdana color=#000000>
<table border=0 cellpadding=0 cellspacing=0 width=100%><tr><td bgcolor=#d9d9ff><img src=themes/Akki/images/webtools_1x1.gif width=1 height=1 border=0></td></tr></table>
</font>


<a href=search.php?query=&topic=$topic&author=><img src=$tipath$topicimage border=0 Alt=$topictext align=right hspace=10 vspace=10></a>
$thetext

</td></tr>
</tr>
</table>
</td>
</tr>
</table>

";




	} else {
		if($informant != "") $informant = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
		else $boxstuff = "$anonymous ";
		$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes";
echo "

<table border=0 cellpadding=0 cellspacing=0 align=center bgcolor=000000 width=100%>
<tr><td>
<table border=0 cellpadding=3 cellspacing=1 width=100%>
<tr><td bgcolor=CCCCCC>
<b>$title</b><br><font size=2>".translate("Contributed by ")." $informant ".translate("on")." $datetime</font>
";
global $admin, $sid;
if ($admin) {
    echo "&nbsp;&nbsp; $font2 [ <a href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]";
}
echo "
</td>
</tr>
<tr>
<td bgcolor=ffffff>
<a href=search.php?query=&topic=$topic&author=><img src=$tipath$topicimage
border=0 Alt=\"$topictext\" align=right hspace=10 vspace=10></a>
$thetext
</td>
</tr>
</table>
</td>
</tr>
</table><br>
";

	}
}

function themesidebox($title, $content) {
    echo "
    <table border=0 cellspacing=0 cellpadding=0 width=100% bgcolor=000000><tr><td>
    <table width=100% border=0 cellspacing=1 cellpadding=3><tr><td colspan=1 background=themes/Akki/images/blockhead.gif>
    <font size=2><center>$title</center>
    </td></tr><tr><td bgcolor=FFFFFF><font size=2>
    $content
    </td></tr></table></td></tr></table><br>";
}
?>
