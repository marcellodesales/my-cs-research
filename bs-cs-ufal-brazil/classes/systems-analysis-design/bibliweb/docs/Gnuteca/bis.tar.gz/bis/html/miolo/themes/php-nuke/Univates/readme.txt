        ###################################################################
        #            TTTTTTT HHH HHH EEEEEEE MM   MM EEEEEEE              #
        #               T     H   H  E       M M M M E                    #
        #               T     HHHHH  EEEE    M  M  M EEEE                 #
        #               T     H   H  E       M     M E                    #
        #               T    HHH HHH EEEEEEE M     M EEEEEEE              #
        #                                                                 #
        # PPPPPP  HHH HHH PPPPPP          IIIIIII NN    N FFFFFFF  OOOOO  #
        # P     P  H   H  P     P            I    N N   N F       O     O #
        # PPPPPP   HHHHH  PPPPPP  -------    I    N  N  N FFFF    O     O #
        # P        H   H  P                  I    N   N N F       O     O #
        # P       HHH HHH P               IIIIIII N    NN F        OOOOO  #
        ###################################################################
        (Oui, c'est moche, et alors ? C'est moi qui l'a fait tout seul ...
                        Pis en plus, c'est � la mode...)

Bon, alors c'est le th�me PhpInfo.... J'ai tout fait pour que la page d'accueil et article.php ressemblent au max � phpinfo.net, mais j'ai donc un peu n�glig� les autres pages (J'ai pas regard� ce que ca donnait). Le seul truc diff�rent de phpinfo.net est l'image du haut de rubrique parceuque le titre est variable et je ne sais pas (encore) g�n�rer des images � la vol�e...Voila, c'est un th�me marrant et je le trouve sympa. Pour l'installer, il suffit de tout placer dans le r�pertoire themes de votre nunuke. Sinon, j'ai cod� ca en trois heures donc ne vous �tonnez pas si le code g�n�r� est affreusement redondant et ne marche pas sous Netscape (en tout cas, ca m'�tonnerait ;). Si vous �tes suffisamment nombreux � me demander de le recoder, je le ferais ptet ...

Merci � Jean-Pierre D�z�lus pour son super site et pour m'avoir donn� l'autorisation de faire ce th�me.
Merci � Davduf (Pourquoi ? Pour tout ...)
Merci � Edazine (J'avais pas de Template de th�me alors je me suis servi de Duke (Je sais c'est pas une aide ph�nom�nale que de filer un template de th�me mais, merci quand m�me (tiens des parenth�se imbriqu�es... (Y en a 4 d'ailleurs (Non, 5 ! (Ou bien 6 ? (Bon d'accord c'est pas drole, j'arrete, mais �a en fait quand-m�me 7...)))))))

Moumou inconnu0215@noos.fr http://www.ti-world.net ICQ : 42150494

PS : Au fait, y a des tas d'images qui servent � rien la dedans, c'est parce qu'elles viennent du th�me que j'ai pris comme template, et je les ai pas enlev�es...