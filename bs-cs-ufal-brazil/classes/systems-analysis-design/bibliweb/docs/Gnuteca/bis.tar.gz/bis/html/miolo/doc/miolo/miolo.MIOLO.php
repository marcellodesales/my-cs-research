<html>
<head>
 <title> MIOLO - miolo:MIOLO</title>
 <link rel="stylesheet" href="/miolo/doc/doc.css">
</head>
<body>
<? include '/usr/local/bis/html//miolo/doc/header.inc' ?>
<h3 align="right">Classe: <a href="/miolo/doc/miolo/miolo.class.php">MIOLO</a></h3>
<h2>MIOLO($home=null,$db='sagu')</h2>
<p>Construtor da classe MIOLO.</p>
<h3>Par�metros:</h3>
<dl>
 <dt>$home (String)</dt>
 <dd>O diret�rio inicial da classe (/usr/local/bis).</dd>
 <dt>$db (String)</dt>
 <dd>A configura��o de banco de dados padr�o (sagu).</dd>
</dl>
<p>&nbsp;</p>
<pre>
<?php
highlight_string(
'<?php
    ...
    $miolo->MIOLO($home,$db); 
    ...
?>');
?>
</pre>
<? include '/usr/local/bis/html//miolo/doc/footer.inc' ?>
</body>
</html>
