<?
/***********************************************************/
/* Verifica se livro esta emprestado - saida               */
/* Linguagem PHP                                           */
/* Autor: Pablo Dall'Oglio e Joao Fritsch                  */
/* �ltima atera��o em 28 Janeiro por Pablo                 */
/***********************************************************/

include_once '../gtk/util/GnutecaDialog.class';
include_once 'EntryBox.php';
include_once '../../../miolo/miolo.conf';
include_once '../../../miolo/miolo.class';
include_once '../db/GnutecaMIOLO.class';

function FechaJanela()
{
  Gtk::main_quit();
}

function KeyTest($p1, $p2)
{
  if ($p2->keyval == 65293)
    CheckPoint();
}

function CheckPoint()
{
  global $MIOLO, $window, $campo, $BusinessEstado, $BusinessExemplar;
  if (!$BusinessEstado)
    $BusinessEstado   = $MIOLO->GetBusiness('gnuteca','Estado');

  if (!$BusinessExemplar)
    $BusinessExemplar = $MIOLO->GetBusiness('gnuteca', 'Exemplar');

  $CodigoDoExemplar = $campo->get_text();

  $Estado   = $BusinessEstado->ObtemEstadoPorMnemonico('EMPRESTADO');
  $EstadoEmprestado = $Estado->CodigoDoEstado;
  $Exemplar = $BusinessExemplar->ObtemExemplar($CodigoDoExemplar);

  if ($Exemplar->CodigoDoEstado == $EstadoEmprestado)
  {
    //GnuTecaDialog::GnuTecaAviso("Emprestado.");
    system("echo -e \"\007\"");
  }
  else
  {
    GnuTecaDialog::GnuTecaAviso("Nao Emprestado !!");
  }

  $campo->set_text('');
  $window->set_focus($campo);

}

if (strtoupper(substr(PHP_OS, 0, 3)) == 'WIN')
  dl('php_gtk.dll');
else
  dl('php_gtk.so');

$MIOLO  = new GnutecaMIOLO('/usr/local/bis');
$MIOLO->Authenticate('postgres', 'postgres');

$window = &new GtkWindow;
$window->connect('delete-event', 'FechaJanela');
$window->set_title('CheckPoint');
$window->set_border_width(0);
$window->set_default_size(200, 50);
$window->set_uposition(80, 80);

$window->add_events(GDK_KEY_PRESS_MASK);
$window->connect('key_press_event', 'KeyTest');

$vbox = &new GtkVBox();
$window->add($vbox);
$vbox->show();

    $hbox = &new GtkHBox();
    $vbox->add($hbox);
    $hbox->show();
    $window->realize();

      $campo  = &new GtkEntry();
      $hbox->pack_start(CreateEntryBox($campo, 20, true, 'Exemplar', 2, 15, 20, GTK_BUTTONBOX_SPREAD), true, false, 10);
      $window->set_focus($campo);

      $button = &new GtkButton('Verifica');
      $button->connect('clicked', 'CheckPoint');
      $vbox->pack_start($button);
      $button->show();

$window->show();

Gtk::main();
?>
