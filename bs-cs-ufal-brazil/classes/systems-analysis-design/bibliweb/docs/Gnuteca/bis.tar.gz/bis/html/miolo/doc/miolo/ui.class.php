<html>
<head>
 <title> MIOLO - Classe ui</title>
 <link rel="stylesheet" href="/miolo/doc/doc.css">
</head>
<body>
<? include '/usr/local/bis/html//miolo/doc/header.inc' ?>
<h2>Classe: UI</h2>
<blockquote>
extends <a href="#.class.php">SuperClasse</a>
</blockquote>
<p>TODO: Escrever documenta��o da classe UI.</p>
<h3>M�todos:</h3>
<dl>
 <dt><a href="/miolo/doc/miolo/ui.UI.php">UI()</a></dt>
 <dd>Descri��o do m�todo UI. </dd>
 <dt><a href="/miolo/doc/miolo/ui.Alert.php">Alert($msg,$info,$href='')</a></dt>
 <dd>Descri��o do m�todo Alert. </dd>
 <dt><a href="/miolo/doc/miolo/ui.CreateForm.php">CreateForm($title='')</a></dt>
 <dd>Descri��o do m�todo CreateForm. </dd>
 <dt><a href="/miolo/doc/miolo/ui.GetForm.php">GetForm($module,$name,$data=null)</a></dt>
 <dd>Descri��o do m�todo GetForm. </dd>
 <dt><a href="/miolo/doc/miolo/ui.GetMenu.php">GetMenu($module='main',$name='UIMainMenu')</a></dt>
 <dd>Descri��o do m�todo GetMenu. </dd>
 <dt><a href="/miolo/doc/miolo/ui.GetImage.php">GetImage($module,$nome)</a></dt>
 <dd>Descri��o do m�todo GetImage. </dd>
</dl>
<p>&nbsp;</p>
<? include '/usr/local/bis/html//miolo/doc/footer.inc' ?>
</body>
</html>
