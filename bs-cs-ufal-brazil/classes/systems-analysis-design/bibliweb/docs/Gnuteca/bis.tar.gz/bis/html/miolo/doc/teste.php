<html>
<head>
 <link rel="stylesheet" href="doc.css">
</head>
<body>
<h3 align="right">Classe: ???? - ????.class</h3>
<h2>Nome_Function($param1,$param2,$param3)</h2>
<p>� utilizado para ....</p>
<h3>Par�metros:</h3>
<dl>
 <dt>$param1</dt>
 <dd>Descri��o par�metro 1. </dd>
 <dt>$param2</dt>
 <dd>Par�metro 2</dd>
 <dt>$param3</dt>
 <dd>Par�metro 3</dd>
</dl>
<p>
<pre>
<?php
highlight_string(
'<?php
   ...
   $var=... 
   ...
?>');
?>
</pre>
</body>
</html>
