<?
/***********************************************************/
/* Arquivo Principal do M�dulo Empr�stimo do GnuTeca
/***********************************************************/

include_once 'Local.php';

include_once 'util/VerificaSituacao.class';
include_once 'util/VerificaMaterial.class';
include_once 'util/ReservaMaterial.class';
include_once 'util/Historico.class';
include_once 'util/GnutecaDialog.class';
include_once 'util/GnutecaGrid.class';
include_once 'util/GnutecaMenu.class';
include_once 'util/GnutecaConfirm.class';

include_once '../../../miolo/miolo.conf';
include_once '../../../miolo/miolo.class';
include_once '../db/Etiquetas.inc';
include_once '../db/GnutecaMIOLO.class';
include_once '../db/login.class';

if (strtoupper(substr(PHP_OS, 0, 3)) == 'WIN')
  dl('php_gtk.dll');
else
  dl('php_gtk.so');


function ActivateGnuTecaLocalMainModule()
{
  $localMainModule = new GnuTecaLocalMainModule();
}

$MIOLO = new GnutecaMIOLO('/usr/local/bis');

$index = $MIOLO->RegisterErrorHandler($MIOLO, "FatalExit('Base Dados Off-Line: SAGU')");
$SaguOnLine = $MIOLO->CheckDataBase('sagu_cmn');
$MIOLO->RemoveErrorHandler();

$index = $MIOLO->RegisterErrorHandler($MIOLO, "FatalExit('Base Dados Off-Line: GNUTECA')");
$GnutecaOnLine = $MIOLO->CheckDataBase('gnuteca');
$MIOLO->RemoveErrorHandler();

if ($SaguOnLine && $GnutecaOnLine)
{
  $testLogin = new GnuTecaLogin();
  $testLogin->ExibeLogin();
  $testLogin->BtConn->connect('clicked', 'ActivateGnuTecaLocalMainModule');
}

Gtk::main();
?>
