<?php

echo "<body onload=init() topmargin=0 leftmargin=0 MARGINWIDTH=0 MARGINLEFT=0 MARGINRIGHT=0 MARGINHEIGHT=0 MARGINTOP=0 bgcolor=#FFFFFF text=#000000 link=#808000 vlink=#C0C0C0 alink=#800000 background=themes/RedDress/logobottom4.gif>
<br>";
if ($banners) {
    include("banners.php");
}
echo "<br>
<table border=0 width=100% cellspacing=0 cellpadding=0 height=100 background=themes/RedDress/redpixel.gif>
  <tr>  
    <td valign=bottom width=100% height=100>
      <a href=index.php><img src=themes/RedDress/logotop.gif border=0></a>
    </td>
    <td valign=bottom width=100% height=100>";
      
      echo "<form action=\"search.php3\" method=post><font face=Arial,Helvetica size=2\">";
      echo "".translate("Search")."";
      echo "<br><input type=text name=query size=\"17\">&nbsp;&nbsp;</form><br>";
      
  echo "    
  </tr>    
</table>

<table border=0 cellpadding=0 cellspacing=0 width=100% align=center>
<tr><td valign=top>

<table border=0 cellpadding=0 cellspacing=0 width=100% align=center>
<tr><td> 
</td></tr><tr><td valign=top width=100%>
<table border=0 cellspacing=0 cellpadding=2 width=100%>
<tr><td valign=top width=150>";

mainblock();
global $admin;
adminblock();
leftblocks();
ephemblock();
headlines();
online();

echo "<img src=images/pix.gif border=0 width=150 height=1></td><td width=100% valign=top>";
?>