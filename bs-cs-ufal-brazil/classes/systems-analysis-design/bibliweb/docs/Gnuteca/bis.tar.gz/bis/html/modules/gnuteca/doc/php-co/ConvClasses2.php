<?
require("xml_parser.php");
require("co2.php");

Function DumpStructure(&$structure,&$positions,$path, $antPath)
{
 //echo "[".$positions[$path]["Line"].",".$positions[$path]["Column"].",".$positions[$path]["Byte"]."]";
 if(GetType($structure[$path])=="array")
 {
  echo "\n" . $positions[$path]["Column"];
  echo "<".$structure[$path]["Tag"].">";
  for($element=0;$element<$structure[$path]["Elements"];$element++)
   DumpStructure(&$structure,&$positions,$path.",$element", $path);
  //echo "\n<".$structure[$path]["Tag"].">";
 }
 else
 {
  $buffer2 = $positions[$antPath]["Column"];

  $buffer = $structure[$path];
  $buffer = ereg_replace("\n", '', $buffer);
  $buffer = ereg_replace(chr(13), '', $buffer);
  $buffer = trim($buffer);
  if ($buffer)
    echo "$buffer";
 }
}

  if (strtoupper(substr(PHP_OS, 0, 3)) == 'WIN')
    dl('php_gtk.dll');
  else
    dl('php_gtk.so');


  //$MyClassOrganizer = new ClassOrganizer();

  $handle=opendir('xml');
  while (($filename = readdir($handle))!==false)
  {
    if ($filename!='.' && $filename!='..' && $filename!='cache')
    {
      $cachefile = $filename;
      $filename = "xml/$filename";
      $error=XMLParseFile(&$parser,$filename,1,"/tmp/$cachefile.cache");
      if(strcmp($error,""))
        echo "Parser error: $error\n";
      else
      {
        DumpStructure(&$parser->structure,&$parser->positions,"0","0", &$fd);
        echo "\n";
      }
    }
  }
  closedir($handle);

/*

  function CarregaClasses()
  {
    $this->ctree->freeze();
    $this->ctree->clear();

    $arquivo = $this->nomeArquivo->get_text();
    $text = array('Raiz', '');
    $parent = $this->ctree->insert_node(null, null, $text, 5,
                    $this->ctree_data['pixmap1'],
                    $this->ctree_data['mask1'],
                    $this->ctree_data['pixmap2'],
                    $this->ctree_data['mask2'], false, true);


    $fd = @fopen($arquivo, 'r');

    if ($fd)
    {
      while (!feof($fd))
      {
        $conteudo = fgets($fd, 100);

        if (strtoupper(substr(PHP_OS, 0, 3)) == 'WIN')
          $conteudo = substr($conteudo,0,strlen($conteudo)-2);

        if ($conteudo)
        {
          $text = explode('>', $conteudo, 3);

          if ($text[0]=='class')
          {
            $sibling = $this->ctree->insert_node($parent, null, $text, 5,
                            $this->ctree_data['pixmap1'],
                            $this->ctree_data['mask1'],
                            $this->ctree_data['pixmap2'],
                            $this->ctree_data['mask2'],
                            false, false);

          }
          else
          {
            $this->InsereFilho($sibling, $text);
          }
        }
      }
      fclose($fd);

      $text = array('Raiz', '');
      $this->ctree->thaw();
    }
  }

  function InsereFilho($parent, $text)
  {
    $sibling = $this->ctree->insert_node($parent, null , $text, 5,
               $this->ctree_data['pixmap3'],
               $this->ctree_data['mask3'], null, null,
               true, false);
    $style = &new GtkStyle();
    if ($text[0]=='method')
      $style->fg[GTK_STATE_NORMAL] = new GdkColor(0, 10000, 60000);
    else if ($text[0]=='property')
       $style->fg[GTK_STATE_NORMAL] = new GdkColor(45000, 0, 0);
    else if ($text[0]=='event')
       $style->fg[GTK_STATE_NORMAL] = new GdkColor(10000, 45000, 0);
    else
       $style->fg[GTK_STATE_NORMAL] = new GdkColor(45000, 45000, 0);

    $this->ctree->node_set_row_style($sibling, $style);


  }
*/

Gtk::main();


?>