<html>
<head>
 <title> MIOLO - MIOLO:CheckAccess</title>
 <link rel="stylesheet" href="doc.css">
</head>
<body>
<? include 'header.inc' ?>
<h3 align="right">Classe: <a href="MIOLO.class.php">MIOLO</a></h3>
<h2>CheckAccess($module, $access, $deny=false)
</h2>
<p>TODO: Escrever documenta��o da fun��o CheckAccess.</p>
<h3>Par�metros:</h3>
<dl>
 <dt>$module</dt>
 <dd>Descri��o par�metro $module.</dd>
 <dt> $access</dt>
 <dd>Descri��o par�metro  $access.</dd>
 <dt> $deny</dt>
 <dd>Descri��o par�metro  $deny.</dd>
</dl>
<p>&nbsp;</p>
<pre>
<?php
highlight_string(
'<?php
    ...
    $MIOLO->CheckAccess($module, $access, $deny); 
    ...
?>');
?>
</pre>
<? include 'footer.inc' ?>
</body>
</html>
