<html>
<head>
 <title> MIOLO - Classe form</title>
 <link rel="stylesheet" href="/miolo/doc/doc.css">
</head>
<body>
<? include '/usr/local/bis/html//miolo/doc/header.inc' ?>
<h2>Classe: Form</h2>
<blockquote>
extends <a href="#.class.php">SuperClasse</a>
</blockquote>
<p>TODO: Escrever documenta��o da classe Form.</p>
<h3>M�todos:</h3>
<dl>
 <dt><a href="/miolo/doc/miolo/ui/form.Form.php">Form($title='',$action='')</a></dt>
 <dd>Descri��o do m�todo Form. </dd>
 <dt><a href="/miolo/doc/miolo/ui/form.SetAction.php">SetAction($action)</a></dt>
 <dd>Descri��o do m�todo SetAction. </dd>
 <dt><a href="/miolo/doc/miolo/ui/form.SetHelp.php">SetHelp($href)</a></dt>
 <dd>Descri��o do m�todo SetHelp. </dd>
 <dt><a href="/miolo/doc/miolo/ui/form.SetFilter.php">SetFilter($filter)</a></dt>
 <dd>Descri��o do m�todo SetFilter. </dd>
 <dt><a href="/miolo/doc/miolo/ui/form.GetFields.php">GetFields()</a></dt>
 <dd>Descri��o do m�todo GetFields. </dd>
 <dt><a href="/miolo/doc/miolo/ui/form.SetFields.php">SetFields($fields)</a></dt>
 <dd>Descri��o do m�todo SetFields. </dd>
 <dt><a href="/miolo/doc/miolo/ui/form.AddButton.php">AddButton($label,$name,$action='SUBMIT')</a></dt>
 <dd>Descri��o do m�todo AddButton. </dd>
 <dt><a href="/miolo/doc/miolo/ui/form.ShowReturn.php">ShowReturn($state)</a></dt>
 <dd>Descri��o do m�todo ShowReturn. </dd>
 <dt><a href="/miolo/doc/miolo/ui/form.ShowReset.php">ShowReset($state)</a></dt>
 <dd>Descri��o do m�todo ShowReset. </dd>
 <dt><a href="/miolo/doc/miolo/ui/form.Validate.php">Validate($required)</a></dt>
 <dd>Descri��o do m�todo Validate. </dd>
 <dt><a href="/miolo/doc/miolo/ui/form.CollectInput.php">CollectInput($data)</a></dt>
 <dd>Descri��o do m�todo CollectInput. </dd>
 <dt><a href="/miolo/doc/miolo/ui/form.SetData.php">SetData($data)</a></dt>
 <dd>Descri��o do m�todo SetData. </dd>
 <dt><a href="/miolo/doc/miolo/ui/form._SetData.php">_SetData($data)</a></dt>
 <dd>Descri��o do m�todo _SetData. </dd>
 <dt><a href="/miolo/doc/miolo/ui/form.SetFieldValue.php">SetFieldValue($name,$value)</a></dt>
 <dd>Descri��o do m�todo SetFieldValue. </dd>
 <dt><a href="/miolo/doc/miolo/ui/form.GenerateTitle.php">GenerateTitle()</a></dt>
 <dd>Descri��o do m�todo GenerateTitle. </dd>
 <dt><a href="/miolo/doc/miolo/ui/form.GenerateFilter.php">GenerateFilter()</a></dt>
 <dd>Descri��o do m�todo GenerateFilter. </dd>
 <dt><a href="/miolo/doc/miolo/ui/form.GenerateBody.php">GenerateBody()</a></dt>
 <dd>Descri��o do m�todo GenerateBody. </dd>
 <dt><a href="/miolo/doc/miolo/ui/form.GenerateFooter.php">GenerateFooter($info=null)</a></dt>
 <dd>Descri��o do m�todo GenerateFooter. </dd>
 <dt><a href="/miolo/doc/miolo/ui/form.Generate.php">Generate()</a></dt>
 <dd>Descri��o do m�todo Generate. </dd>
</dl>
<p>&nbsp;</p>
<? include '/usr/local/bis/html//miolo/doc/footer.inc' ?>
</body>
</html>
