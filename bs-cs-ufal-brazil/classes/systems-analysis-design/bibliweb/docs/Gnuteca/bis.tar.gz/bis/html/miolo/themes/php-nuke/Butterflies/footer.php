<?PHP
if ($index == 1) {
    echo "</td><td valign=\"top\" width=\"153\" align=\"right\"><table BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=\"100%\" ><tr></td>";
    category();
    pollNewest();
    loginbox();
    userblock();
    oldNews($storynum);
    rightblocks();
    echo "</td></tr></table>";


?>

<td VALIGN=TOP HEIGHT="3" BGCOLOR="#336699"><img src="themes/Butterflies/spacer.gif" height=3 width=1></td>
<td VALIGN=TOP HEIGHT="3" BGCOLOR="#336699"><img src="themes/Butterflies/spacer.gif" height=3 width=1></td>
<td VALIGN=TOP HEIGHT="3" BGCOLOR="#336699"><img src="themes/Butterflies/spacer.gif" height=3 width=1></td>
</tr>

<tr>
<td COLSPAN="3" BGCOLOR="#CCE6FF">&nbsp;</td>
</tr>
</table>

<? }
?>

</td>
<td VALIGN=TOP HEIGHT="3" BGCOLOR="#336699"><img src="themes/Butterflies/spacer.gif" height=3 width=1></td>
</tr>

<tr>
<td COLSPAN="3" BGCOLOR="#CCE6FF">&nbsp;</td>
</tr>
</table>

<?php
footmsg();
?>
