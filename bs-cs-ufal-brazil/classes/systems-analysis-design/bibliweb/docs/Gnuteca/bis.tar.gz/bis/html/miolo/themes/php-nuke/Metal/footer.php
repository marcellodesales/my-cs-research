<?php

if ($index == 1) {
    echo "<td>&nbsp;</td><td valign=\"top\" bgcolor=\"white\">";
    category();
    pollNewest();
    bigstory();
    loginbox();
    userblock();
    oldNews($storynum);
    rightblocks();
    echo "</td>";
}
echo "
</td></tr></table></td></tr></table>
<form action=search.php method=post>
<table border=0 cellpadding=0 cellspacing=0 width=100% background=themes/Metal/steel3.jpg>
<tr>
<td background=themes/Metal/tbar1.gif height=17><img src=themes/Metal/tleft1.gif width=17 height=17></td>
<td background=themes/Metal/tbar1.gif align=center width=99%><font size=-2>&nbsp;</font></td>
<td><img src=themes/Metal/tright1.gif width=17 height=17 alt= ></td>
</tr>
<tr bgcolor=#ffffff>
	<td background=themes/Metal/leftbar1.gif align=left>&nbsp;</td>
	<td width=100% valign=top background=themes/Metal/steel3.jpg><center><font size=2><form action=search.php method=post>".translate("Search:")." <input type=text name=query></form></font></center></td>
<td background=themes/Metal/rightbar1.gif>&nbsp;</td>
</tr>
<tr>
<TD background=themes/Metal/bbar1.gif valign=top><IMG src=themes/Metal/bleft1.gif width=17 height=17></TD>
<TD background=themes/Metal/bbar1.gif valign=top align=center>&nbsp;</TD>
<TD background=themes/Metal/bbar1.gif valign=top><IMG src=themes/Metal/bright1.gif width=17 height=17></TD>
</TR></table></form>";
footmsg();
?>