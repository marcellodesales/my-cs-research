<?php
include('config.php')
?>

<body onload=init() bgcolor="#000000" text="#000000" link="#006666" vlink="#006666">
<br>
<?php
if ($banners) {
    include("banners.php");
}
?>
<br>
<center>
<table bgcolor="#FFFFFF" cellpadding=0 cellspacing=0 border=0 width="99%" align=center>
 <tr>
  <td valign=top align=left valign=top>
   <a href="<?php echo $nuke_url; ?>"><img src="themes/Slashdot/logo.gif" width=275 height=72 border=0 alt="<?php echo "".translate("Welcome to").""; ?> <?php echo $sitename; ?>"></a>
  </td>

<td width=100%>
<?php
mysql_pconnect($dbhost, $dbuname, $dbpass);
$result = mysql_query("select topic from stories order by sid DESC limit 3,5");
echo "<center>";
while(list($topic) = mysql_fetch_row($result)) {
    $result2 = mysql_query("select topicid, topicimage, topictext from topics where topicid='$topic'");
    list($topicid, $topicimage, $topictext) = mysql_fetch_row($result2);
    echo "<a href=search.php?query=&topic=$topicid><img src=$tipath$topicimage hspace=3 Alt=\"$topictext\" border=0></a>";
}
echo "</center><br>";
?>

</td></tr></table>

<table bgcolor="#FFFFFF" cellpadding=0 cellspacing=0 border=0 width="99%" align=center><tr><td>

<?php
mysql_pconnect($dbhost, $dbuname, $dbpass);
$MainBlock=mysql_query("select content from mainblock");
list($content) = mysql_fetch_row($MainBlock);
?>
<table width="99%" align=center cellpadding=0 cellspacing=5 border=0 bgcolor="#FFFFFF"><tr>
<td valign=top rowspan=5 width=12%><NOBR><font size=2><B>
<?php echo "$content"; ?>
</B></font></NOBR>
</td>
<?php mysql_free_result($MainBlock); ?>

<td valign=top align=left>