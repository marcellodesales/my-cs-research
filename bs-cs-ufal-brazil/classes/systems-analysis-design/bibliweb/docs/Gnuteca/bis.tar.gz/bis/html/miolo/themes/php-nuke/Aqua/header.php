<?php
echo " 
<body onload=init() background=themes/Aqua/images/background.gif text=000000 link=000000 vlink=000000 topmargin=5 leftmargin=0 rightmargin=0 marginheight=5>
<br>";
if ($banners) {
    include("banners.php");
}
echo "<br>
<center><br>
<a href=$nuke_url><img src=themes/Aqua/images/logo.gif Alt=\"".translate("Welcome to")." $sitename\" border=0></a>
<br><br></center>

<table border=0 cellspacing=0 cellpadding=2 width=100%><tr><td valign=top width=180>";

mainblock();
adminblock();
searchbox();
leftblocks();
ephemblock();
headlines();
online();

echo "<img src=images/pix.gif border=0 width=180 height=1></td><td width=100% valign=top>";
?>