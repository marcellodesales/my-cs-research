<?php
echo "<body onload=init() bgcolor=FFFFFF text=222222 link=006699 vlink=006699>
<br>";
if ($banners) {
    include("banners.php");
}
echo "<br>
<center>
<table cellpadding=0 cellspacing=0 border=0 width=99% align=center><tr><td align=left>
<a href=$nuke_url><img src=themes/Barrapunto/logo.gif Alt=\"".translate("Welcome to")." $sitename\" border=0></a>
</td><td align=right width=100%>
    <form action=search.php method=post><font size=2 color=222222>
    <input type=text name=query>
    <input type=submit value=Buscar>
    </form>";

    echo "</td></tr></table><br>";

echo "
<table cellpadding=0 cellspacing=0 border=0 width=99% bgcolor=FF6600><tr><td>
<table cellpadding=5 cellspacing=2 border=0 width=100% bgcolor=FFFFFF><tr><td valign=left>
<font size=2>$slogan</td></tr></table></td></tr></table><P>
<table width=99% align=center cellpadding=0 cellspacing=0 border=0><tr><td valign=top rowspan=15>";

mainblock();
adminblock();
leftblocks();
ephemblock();
headlines();

echo "</td><td>&nbsp;&nbsp;</td><td valign=top width=100%>";

?>