<?php

echo "<body onload=init() bgcolor=000000 text=FFFFFF link=FFFFFF vlink=FFFFFF topmargin=2 leftmargin=5 marginwidth=0 marginheight=0>
<br>";
if ($banners) {
    include("banners.php");
}
echo "<br>
<table border=0 cellpadding=0 cellspacing=0 width=98% align=center bgcolor=000000>
  <tr>
    <td align=left rowspan=3 width=130>
      <a href=$nuke_url><img src=themes/NiH/logo.gif border=0 Alt=\"".translate("Welcome to")." $sitename\"></a>
    </td>
    <td>
      <img src=images/pix.gif border=0 width=1 height=50>
    </td>
     <td rowspan=2>
      &nbsp;
    </td>
  </tr>
  <tr>
    <td align=left>
      $slogan
    </td>
  </tr>
  <tr>
    <td align=left>
      <font size=3 color=FFFFFF>$slogan</font>
    </td>
    <td align=right>
      <form action=search.php method=post><font size=2 color=ffffff>
      ".translate("Search")."
      <input type=text name=query>
      </form>
    </td>
  </tr>
</table>

<table border=0 cellspacing=0 cellpadding=2 width=100% bgcolor=000000>
<tr><td valign=top width=150>";

mainblock();
adminblock();
leftblocks();
ephemblock();
headlines();
online();

echo "<img src=images/pix.gif border=0 width=150 height=1></td><td width=100% valign=top>";
?>