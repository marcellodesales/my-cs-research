<html>
<head>
 <title> MIOLO - theme:Generate</title>
 <link rel="stylesheet" href="/miolo/doc/doc.css">
</head>
<body>
<? include '/usr/local/bis/html//miolo/doc/header.inc' ?>
<h3 align="right">Classe: <a href="/miolo/doc/miolo/ui/theme.class.php">Theme</a></h3>
<h2>Generate()</h2>
<p>TODO: Escrever documenta��o da fun��o Generate.</p>
<p>&nbsp;</p>
<pre>
<?php
highlight_string(
'<?php
    ...
    $theme->Generate(); 
    ...
?>');
?>
</pre>
<? include '/usr/local/bis/html//miolo/doc/footer.inc' ?>
</body>
</html>
