<?php

$bgcolor1 = "FFFFFF";
$textcolor1 = "FFFFFF";


function themesidebox($title, $content) {
    echo "<table width=170 cellpadding=0>";
    echo "<tr><td bgcolor=000000><center><font size=-1 color=FEFEFE><b>$title</b></font>";
    echo "<table width=100% cellpadding=5>";
    echo "<tr><td bgcolor=FEFEFE>";
    echo "<font size=-1><b>";
    echo "$content";
    echo "<p>";
    echo "</b></font>";
    echo "</td></tr></table>";
    echo "</td></tr></table>";
}


function themeindex($aid, $informant, $time, $title, $counter, $topic, $thetext, $notes, $morelink, $topicname, $topicimage, $topictext) {
    global $tipath, $anonymous;
    echo "
    <TABLE BORDER=\"0\" WIDTH=\"100%\" CELLSPACING=\"0\" CELLPADDING=\"0\"><TR><TD COLSPAN=\"2\">
	<TABLE WIDTH=\"100%\" CELLPADDING=\"0\"><TR><TD BGCOLOR=\"#000000\">
	    <TABLE WIDTH=\"100%\" CELLPADDING=\"4\"><TR><TD BGCOLOR=\"#fefefe\">
    		&nbsp;<B>
		$title </b><font size=-2 color=666666> ".translate("Posted by ")."";
    		formatAidHeader($aid); 
    		echo " (".translate("read:")." $counter ".translate("times").")";
    		echo "</font><B>
	    </TD></TR></TABLE>
	</TD></TR></TABLE>
    </TD></TR><TR><TD VALIGN=\"top\">
	<TABLE WIDTH=\"100%\" CELLPADDING=\"0\"><TR><TD BGCOLOR=\"#000000\">
	    <TABLE WIDTH=\"100%\" CELLPADDING=\"14\"><TR><TD BGCOLOR=\"#fefefe\">";
	      if ("$aid" == "$informant") {
	        //formatAidHeader($aid); 
	        echo "$thetext<br><br>$morelink</TD></TR></TABLE>";
	      } else {
	        if ($informant != "") {
		    $boxstuff = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
		} else {
		    $boxstuff = "$anonymous ";
		}
		$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes";
		echo "$boxstuff<br><br>$morelink</TD></TR></TABLE>";
	      }
    echo "
	</TD></TR></TABLE>
	</TD><TD WIDTH=\"20%\" VALIGN=\"top\">
	    <TABLE WIDTH=\"100%\" CELLPADDING=\"0\"><TR><TD BGCOLOR=\"#000000\">
		<TABLE WIDTH=\"100%\" CELLPADDING=\"4\"><TR><TD BGCOLOR=\"#fefefe\">
		    <CENTER><FONT SIZE=\"-1\"><B>
		    $time</B></FONT></CENTER>
		</TD></TR></TABLE>
	    </td></tr></table>
	    <TABLE WIDTH=\"100%\" CELLPADDING=\"0\"><TR><TD BGCOLOR=\"#000000\">
		<table width=100% cellpadding=6><tr><td bgcolor=FEFEFE>
		    <ceter><b>
		    <font size=-1>
		    <center><a href=search.php?topic=$topic><img src=$tipath$topicimage Alt=\"$topictext\" border=0></a></center>
		    </b></center>
		</td></tr></table>
	    </TD></TR></TABLE>
	</TD></TR><TR><TD COLSPAN=\"2\"><BR>
    </TD></TR></TABLE>";
}


function themearticle ($aid, $informant, $datetime, $title, $thetext, $topic, $topicname, $topicimage, $topictext) {
    global $admin, $sid, $tipath;
    echo "
    <TABLE BORDER=\"0\" WIDTH=\"100%\" CELLSPACING=\"0\" CELLPADDING=\"0\"><TR><TD COLSPAN=\"2\">
	<TABLE WIDTH=\"100%\" CELLPADDING=\"0\"><TR><TD BGCOLOR=\"#000000\">
	    <TABLE WIDTH=\"100%\" CELLPADDING=\"4\"><TR><TD BGCOLOR=\"#fefefe\">
    		&nbsp;<B>
		$title</b>";
    		if ($admin) {
    		    echo "&nbsp;&nbsp; [ <a href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]";
    		}
    		echo "</font><B>
	    </TD></TR></TABLE>
	</TD></TR></TABLE>
    </TD></TR><TR><TD VALIGN=\"top\">
	<TABLE WIDTH=\"100%\" CELLPADDING=\"0\"><TR><TD BGCOLOR=\"#000000\">
	    <TABLE WIDTH=\"100%\" CELLPADDING=\"14\"><TR><TD BGCOLOR=\"#fefefe\">
	      <a href=search.php?topic=$topic><img src=$tipath$topicimage Alt=\"$topictext\" border=0 align=right></a>
	      <font size=-2 color=666666> ".translate("Posted by ")."";
	      formatAidHeader($aid); 
	      if ($informant != "") {
	        echo "<br>".translate("Contributed by ")." <a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ".translate("on")." $datetime</font>";
	      } else {
	        echo "<br>".translate("Contributed by ")." $anonymous ".translate("on")." $datetime</font>";
	      }
	      echo "<br><br>$thetext</TD></TR></TABLE>";
    echo "
    </TD></TR></TABLE>
    </TD></TR><TR><TD COLSPAN=\"2\"><BR>
    </TD></TR></TABLE>";
}

?>