<?php
global $admin;
if ($index == 1) {
    echo "<td>&nbsp;</td><td valign=\"top\" bgcolor=\"#FFFFFF\">";
    category();
    pollNewest();
    bigstory();
    loginbox();
    adminblock();
    userblock();
    oldNews($storynum);
    leftblocks();
    rightblocks();
    ephemblock();
    headlines();
    online();
}
echo "
</font></td></tr></table></td></tr></table>
<table cellpadding=0 cellspacing=0 border=0 width=99% align=center bgcolor=FFFFFF><tr>
<td colspan=4 align=center><img src=themes/Slashdot/greendot.gif width=80% height=1 hspace=10 vspace=30></td>
</tr><tr>
<td align=center><font size=2>
    <form method=post action=search.php>
    <input type=text name=query width=20 size=20 length=20>
    <input type=submit value=".translate("Search").">
    </form>
</font></td>
<td bgcolor=ffffff width=25>&nbsp;</td>
<td align=center><img src=/images/mynetscape.gif>
</td><td bgcolor=ffffff>&nbsp;</td></tr></table><br>
<font color=CCCCCC size=1>";
footmsg();
?>