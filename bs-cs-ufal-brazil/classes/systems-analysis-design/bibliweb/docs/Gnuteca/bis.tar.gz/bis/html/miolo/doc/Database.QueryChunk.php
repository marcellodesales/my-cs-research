<html>
<head>
 <title> MIOLO - Database:QueryChunk</title>
 <link rel="stylesheet" href="doc.css">
</head>
<body>
<? include 'header.inc' ?>
<h3 align="right">Classe: <a href="Database.class.php">Database</a></h3>
<h2>QueryChunk($sql, $maxrows, $offset, &$total)
</h2>
<p>TODO: Escrever documenta��o da fun��o QueryChunk.</p>
<h3>Par�metros:</h3>
<dl>
 <dt>$sql</dt>
 <dd>Descri��o par�metro $sql.</dd>
 <dt> $maxrows</dt>
 <dd>Descri��o par�metro  $maxrows.</dd>
 <dt> $offset</dt>
 <dd>Descri��o par�metro  $offset.</dd>
 <dt> &$total</dt>
 <dd>Descri��o par�metro  &$total.</dd>
</dl>
<p>&nbsp;</p>
<pre>
<?php
highlight_string(
'<?php
    ...
    $Database->QueryChunk($sql, $maxrows, $offset, &$total); 
    ...
?>');
?>
</pre>
<? include 'footer.inc' ?>
</body>
</html>
