<?
/***********************************************************/
/* Altera Conteudo de Etiquetas                            */
/* Linguagem PHP                                           */
/* Autor: Pablo Dall'Oglio e Jo�o Alex Fritsch             */
/* �ltima atera��o em 12 Setembro por Pablo e Joao         */
/***********************************************************/

include_once '../gtk/util/GnutecaDialog.class';
include_once 'EntryBox.php';
include_once '../../../miolo/miolo.conf';
include_once '../../../miolo/miolo.class';
include_once '../db/GnutecaMIOLO.class';

function FechaJanela()
{
  Gtk::main_quit();
}

function AlteraConteudo()
{
  global $MIOLO, $campo, $subCampo, $Conteudo, $NovoConteudo;

  $_campo        = trim($campo->get_text());
  $_subCampo     = trim($subCampo->get_text());
  $_Conteudo     = strtoupper(trim($Conteudo->get_text()));
  $_NovoConteudo = strtoupper(trim($NovoConteudo->get_text()));

  $BusinessMaterial = $MIOLO->GetBusiness('gnuteca', 'Material');
  $BusinessExemplar = $MIOLO->GetBusiness('gnuteca', 'Exemplar');

  $Exemplares = $BusinessMaterial->ExtraiEtiquetas($_campo, $_subCampo);

  foreach ( $Exemplares as $LinhaResultado)
  {
    $NumeroDaObra = $LinhaResultado[0];
    $ConteudoDoCampo = strtoupper(trim($LinhaResultado[1]));

    if ($ConteudoDoCampo==$_Conteudo)
    {
      echo "$NumeroDaObra - $ConteudoDoCampo";
      $BusinessMaterial->AtualizaConteudoEtiqueta($NumeroDaObra, $_campo, $_subCampo, $_NovoConteudo);
    }

  }
  FechaJanela();
}

if (strtoupper(substr(PHP_OS, 0, 3)) == 'WIN')
  dl('php_gtk.dll');
else
  dl('php_gtk.so');

$MIOLO  = new GnutecaMIOLO('/usr/local/bis');
$MIOLO->Authenticate('postgres', 'postgres');

$window = &new GtkWindow;
$window->connect('delete-event', 'FechaJanela');
$window->set_title('Prepara��o de Ambiente - Altera Conte�do');
$window->set_border_width(0);
$window->set_default_size(480, 50);
$window->set_uposition(80, 80);

$vbox = &new GtkVBox();
$window->add($vbox);
$vbox->show();

    $hbox = &new GtkHBox();
    $vbox->add($hbox);
    $hbox->show();
    $window->realize();

      $campo  = &new GtkEntry();
      $hbox->pack_start(CreateEntryBox($campo, 20, true, 'Campo', 2, 15, 20, GTK_BUTTONBOX_SPREAD), true, false, 10);

      $subCampo  = &new GtkEntry();
      $hbox->pack_start(CreateEntryBox($subCampo, 10, true, 'SubCampo', 2, 15, 20, GTK_BUTTONBOX_SPREAD), true, false, 10);


    $hbox = &new GtkHBox();
    $vbox->add($hbox);
    $hbox->show();
    $window->realize();

      $Conteudo  = &new GtkEntry();
      $hbox->pack_start(CreateEntryBox($Conteudo, 20, true, 'Conte�do', 2, 15, 20, GTK_BUTTONBOX_SPREAD), true, false, 10);

      $NovoConteudo  = &new GtkEntry();
      $hbox->pack_start(CreateEntryBox($NovoConteudo, 10, true, 'Novo Conte�do', 2, 15, 20, GTK_BUTTONBOX_SPREAD), true, false, 10);

      $button = &new GtkButton('Altera Conteudos');
      $button->connect('clicked', 'AlteraConteudo');
      $vbox->pack_start($button);
      $button->show();

$window->show();

Gtk::main();
?>