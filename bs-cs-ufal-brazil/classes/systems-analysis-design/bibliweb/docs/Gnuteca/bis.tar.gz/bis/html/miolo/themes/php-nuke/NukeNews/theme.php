<?php

$thename = "NukeNews";
$bgcolor1 = "#efefef";
$bgcolor2 = "#cfcfbb";
$bgcolor3 = "#efefef";
$bgcolor4 = "#cfcfbb";
$textcolor1 = "#000000";
$textcolor2 = "#000000";
$pollcolor = "#e9edf5";
$hr = 0; # 1 to have horizonal rule in comments instead of table bgcolor




function themeindex ($aid, $informant, $time, $title, $counter, $topic, $thetext, $notes, $morelink, $topicname, $topicimage, $topictext) {
    global $anonymous, $tipath;
    echo "
    <table border=0 cellpadding=0 cellspacing=0 bgcolor=ffffff width=100%><tr><td>
    <table border=0 cellpadding=1 cellspacing=0 bgcolor=000000 width=100%><tr><td>
    <table border=0 cellpadding=3 cellspacing=0 bgcolor=cfcfbb width=100%><tr><td align=left>
    <font size=3 color=\"#363636\"><b>$title</b></font>
    </td></tr></table></td></tr></table>
    <FONT color=\"#999999\"><B><a href=\"search.php?query=&topic=$topic\"><img src=$tipath$topicimage border=0 Alt=\"$topictext\" align=right hspace=10 vspace=10></a></B></FONT>
    ";
    if ("$aid" == "$informant") {
	echo "<FONT size=2 color=\"#505050\">$thetext</FONT>";
    } else {
	if($informant != "") {
	    $boxstuff = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
	} else {
	    $boxstuff = "$anonymous ";
	}
	$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes\n";
	echo "<font size=2 color=\"#505050\">$boxstuff</font>\n";
    }
    echo "
    </td></tr></table>
    <table border=0 cellpadding=1 cellspacing=0 bgcolor=000000 width=100%><tr><td>
    <table border=0 cellpadding=3 cellspacing=0 bgcolor=efefef width=100%><tr><td align=middle>
    <FONT color=\"#999999\" size=1>Posted by ";
    formatAidHeader($aid);
    echo "
    on $time $timezone ($counter ".translate("reads").")<br></FONT>
    <font size=2>$morelink</td>
    </td></tr></table></td></tr></table>
    <br><br><br>";
}

function themearticle ($aid, $informant, $datetime, $title, $thetext, $topic, $topicname, $topicimage, $topictext) {
    global $admin, $sid, $tipath;
    echo"
    <table border=0 cellpadding=0 cellspacing=0 bgcolor=ffffff width=100%><tr><td>
    <table border=0 cellpadding=1 cellspacing=1 bgcolor=000000 width=100%><tr><td>
    <table border=0 cellpadding=3 cellspacing=0 bgcolor=cfcfbb width=100%><tr><td align=left>
    <font size=3 color=\"#363636\"><b>$title</b></font><br>
    <font size=2>
    ".translate('Posted on')." $datetime by ";
    formatAidHeader($aid);
    if ($admin) {
	echo "&nbsp;&nbsp;[ <a href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]</font><br>";
    }
    if($informant != "") {
        echo "<font size=2>Contributed by: <a href=\"user.php?op=userinfo&uname=$informant\">$informant</a></font>";
    } else {
        echo "<font size=2>Contributed by: $anonymous</font>";
    }
    echo "</td></tr></table></td></tr></table><br>";
    echo "<a href=\"search.php?query=&topic=$topic\"><img src=$tipath$topicimage border=0 Alt=\"$topictext\" align=right hspace=10 vspace=10></a>";
    echo "$thetext";
    echo "</td></tr></table><br>";
}

function themesidebox($title, $content) {
    global $tbl;
    if (!isset($tbl)) {
	$tbl = 150;
    }
    echo "
	<table border=0 cellpadding=1 cellspacing=0 bgcolor=000000 width=$tbl><tr><td>\n
	<table border=0 cellpadding=3 cellspacing=0 bgcolor=dedebb width=100%><tr><td align=left>\n
	<font size=2 color=\"#363636\"><b>$title</b></font>\n
	</td></tr></table></td></tr></table>\n
	<table border=0 cellpadding=0 cellspacing=0 bgcolor=ffffff width=$tbl>\n
	<tr valign=top><td bgcolor=ffffff>\n
	<font size=2>$content</font>\n
	</td></tr></table>\n
	<br>\n\n\n";
}

?>
