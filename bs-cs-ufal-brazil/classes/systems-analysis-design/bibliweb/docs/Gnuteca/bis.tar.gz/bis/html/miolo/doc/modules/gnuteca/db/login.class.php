<html>
<head>
 <title> MIOLO - Classe login</title>
 <link rel="stylesheet" href="/miolo/doc/doc.css">
</head>
<body>
<? include '/usr/local/bis/html//miolo/doc/header.inc' ?>
<h2>Classe: GnuTecaLogin</h2>
<blockquote>
extends <a href="#.class.php">SuperClasse</a>
</blockquote>
<p>TODO: Escrever documenta��o da classe GnuTecaLogin.</p>
<h3>M�todos:</h3>
<dl>
 <dt><a href="/miolo/doc/modules/gnuteca/db/login.FechaLogin.php">FechaLogin()</a></dt>
 <dd>Descri��o do m�todo FechaLogin. </dd>
 <dt><a href="/miolo/doc/modules/gnuteca/db/login.CheckLogin.php">CheckLogin()</a></dt>
 <dd>Descri��o do m�todo CheckLogin. </dd>
 <dt><a href="/miolo/doc/modules/gnuteca/db/login.GnuTecaLogin.php">GnuTecaLogin()</a></dt>
 <dd>Descri��o do m�todo GnuTecaLogin. </dd>
 <dt><a href="/miolo/doc/modules/gnuteca/db/login.KeyTest.php">KeyTest($p1, $p2)</a></dt>
 <dd>Descri��o do m�todo KeyTest. </dd>
 <dt><a href="/miolo/doc/modules/gnuteca/db/login.create_codigoOperadorBox.php">create_codigoOperadorBox($horizontal, $title, $spacing, $child_w, $child_h, $layout)</a></dt>
 <dd>Descri��o do m�todo create_codigoOperadorBox. </dd>
 <dt><a href="/miolo/doc/modules/gnuteca/db/login.create_senhaOperadorBox.php">create_senhaOperadorBox($horizontal, $title, $spacing, $child_w, $child_h, $layout)</a></dt>
 <dd>Descri��o do m�todo create_senhaOperadorBox. </dd>
</dl>
<p>&nbsp;</p>
<? include '/usr/local/bis/html//miolo/doc/footer.inc' ?>
</body>
</html>
