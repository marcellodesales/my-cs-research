<?

$thename = "butterflies";
$bgcolor1 = "#6699CC";
$bgcolor2 = "#336699";
$bgcolor3 = "#FFFFFF";
$bgcolor4 = "#77AADD";
$textcolor1 = "#6699CC";
$textcolor2 = "#336699";
$hr = 0; # 1 to have horizonal rule in comments instead of table bgcolor


function themefeature($title, $contents) {
echo "<table BORDER=\"0\" CELLSPACING=\"0\" CELLPADDING=\"5\" WIDTH=\"100%\" >
<tr><td background=\"themes/Butterflies/navtop.gif\"><font size=\"+2\" color=\"White\"><b>$title</b></font></td></tr>
<tr><td>
$contents
</td></tr>
<tr><td background=\"themes/Butterflies/navtop.gif\">&nbsp;</td></tr>
</table>
<!-- first side box style -->
";
}

function themeindex ($aid, $informant, $time, $title, $counter, $topic, $thetext, $notes, $morelink, $topicname, $topicimage, $topictext) {
        if (!$config_called) {if (!isset($config)) {if (!isset($config)) { include("config.php"); }}}
        if ("$aid" == "$informant") { ?>

<!-- article box -->
<table BORDER="0" CELLSPACING="15" CELLPADDING="0" WIDTH="100%" BGCOLOR="#FFFFFF" class="border" >
<tr><td background="themes/Butterflies/navtop.gif"><font size="+2" color="White"><b><?php echo"$title"; ?></b></font> <?php echo translate("Posted by "); ?><?php formatAidHeader($aid) ?></td></tr>
<tr BGCOLOR="#FFFFFF">
<td class="text"><font size="-2">
      <a href="search.php?query=&topic=<?php echo"$topic"; ?>&author="><img src=<?php echo"$tipath$topicimage"; ?> border=0 Alt=<?php echo"\"$topictext\""; ?> align=right hspace=10 vspace=10></a>
          <font size="-1">
        <?php echo"$thetext"; ?>
      </font>
          </td>
</tr>
<tr><td> <font size="-1"><b>&nbsp;
<!-- end story_link block -->

      <?php echo"$morelink"; ?>

<!-- begin story_trailer block -->
      </b></font></td></tr>
</table>
<!--  end of article box -->

<?php        } else {
                if($informant != "") $boxstuff = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
                else $boxstuff = "$anonymous ";
                $boxstuff .= "".translate("writes")." <i>\"$thetext\"</i><br> $notes";
?>

<!-- article box -->
<table BORDER="0" CELLSPACING="15" CELLPADDING="0" WIDTH="100%" BGCOLOR="#FFFFFF" class="border" >
<tr><td background="themes/Butterflies/navtop.gif"><font size="+2" color="White"><b><?php echo"$title"; ?></b></font> <?php echo translate("Posted by "); ?><?php formatAidHeader($aid) ?></td></tr>
<tr>
<td class="text"><font size="-2">
      <?php echo"$time $timezone"; ?>&nbsp;&nbsp;&nbsp; [ <a href="search.php?query=&topic=<?php echo"$topic"; ?>&author="><b><?php echo"$topictext"; ?></b></a> ] </font><br>
      <font size="-1">
        <?php echo"$boxstuff"; ?>
      </font>
          </td>
</tr>
<tr><td> <font size="-1"><b>&nbsp;
<!-- end story_link block -->

      <?php echo"$morelink"; ?>

<!-- begin story_trailer block -->
      </b></font></td></tr>
</table>
<!--  end of article box -->

<?php        }
}

function themearticle ($aid, $informant, $datetime, $title, $thetext, $topic, $topicname, $topicimage, $topictext) {
        if (!$config_called) {if (!isset($config)) {if (!isset($config)) { include("config.php"); }}}
        if ("$aid" == "$informant") {
echo "
<!-- article box -->
<table BORDER=\"0\" CELLSPACING=\"15\" CELLPADDING=\"0\" WIDTH=\"100%\" BGCOLOR=\"#FFFFFF\" class=\"border\">
<tr><td background=themes/Butterflies/navtop.gif><font size=\"+2\" color=\"White\"><b>$title</b></font> ".translate("Posted on ")." $datetime ";
global $admin, $sid;
if ($admin) {
    echo "&nbsp;&nbsp; $font2 [ <a href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]";
}
echo "</td></tr>";
echo "<tr>";
echo "<td class=\"text\"><font size=\"-2\">";
echo "<a href=\"search.php?query=&topic=$topic&author=\"><img src=\"$tipath$topicimage\" border=\"0\" Alt=\"$topictext\" align=\"right\" hspace=\"10\" vspace=\"10\"></a>";
echo "$thetext";
echo "</td>";
echo "</tr>";
echo "<tr>";
echo "<td>";
echo "<font size=\"-1\">";
echo "<b>&nbsp</b>";
echo "</font>";
echo "</td>";
echo "</tr>";
echo "</table>";

        } else {
                if($informant != "") $informant = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
                else $boxstuff = "$anonymous ";
                $boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes";
echo "

<!-- article box -->
<table BORDER=0 CELLSPACING=15 CELLPADDING=0 WIDTH=100% BGCOLOR=#FFFFFF class=border >
<tr><td background=themes/Butterflies/navtop.gif><b>$title</b> ".translate("Contributed by ")." $informant ".translate("on")." $datetime</font>";
global $admin, $sid;
if ($admin) {
    echo "&nbsp;&nbsp; $font2 [ <a href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]";
}
echo "</td></tr>
<tr>
<td class=\"text\"><font size=\"-2\">
<a href=search.php?query=&topic=$topic&author=><img src=$tipath$topicimage border=0 Alt=\"$topictext\" align=right hspace=10 vspace=10></a>
$thetext
          </td>
</tr>
<tr><td> <font size=\"-1\"><b>&nbsp
      </b></font></td></tr>
</table>";
}
}
function themesidebox($title, $contents) {
echo "
<!-- first side box style -->
<table BORDER=\"0\" CELLSPACING=\"0\" CELLPADDING=\"5\" WIDTH=\"100%\" >
<tr><td background=\"themes/Butterflies/navtop2.gif\"><font size=\"+2\" color=\"White\"><b>$title</b></font></td></tr>
<tr><td>
$contents
</td></tr>
<tr><td background=\"themes/Butterflies/navtop.gif\">&nbsp;</td></tr>
</table>
<!-- first side box style -->
";
}


?>
