<html>
<head>
 <title> MIOLO - miolo:CheckLogin</title>
 <link rel="stylesheet" href="/miolo/doc/doc.css">
</head>
<body>
<? include '/usr/local/bis/html//miolo/doc/header.inc' ?>
<h3 align="right">Classe: <a href="/miolo/doc/miolo/miolo.class.php">MIOLO</a></h3>
<h2>CheckLogin()</h2>
<p>TODO: Escrever documenta��o da fun��o CheckLogin.</p>
<p>&nbsp;</p>
<pre>
<?php
highlight_string(
'<?php
    ...
    $miolo->CheckLogin(); 
    ...
?>');
?>
</pre>
<? include '/usr/local/bis/html//miolo/doc/footer.inc' ?>
</body>
</html>
