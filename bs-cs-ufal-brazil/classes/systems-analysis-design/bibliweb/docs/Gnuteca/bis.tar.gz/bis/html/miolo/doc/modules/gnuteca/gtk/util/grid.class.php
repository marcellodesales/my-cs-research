<html>
<head>
 <title> MIOLO - Classe grid</title>
 <link rel="stylesheet" href="/miolo/doc/doc.css">
</head>
<body>
<? include '/usr/local/bis/html//miolo/doc/header.inc' ?>
<h2>Classe: Grid</h2>
<blockquote>
extends <a href="#.class.php">SuperClasse</a>
</blockquote>
<p>TODO: Escrever documenta��o da classe Grid.</p>
<h3>M�todos:</h3>
<dl>
 <dt><a href="/miolo/doc/modules/gnuteca/gtk/util/grid.FechaGrid.php">FechaGrid()</a></dt>
 <dd>Descri��o do m�todo FechaGrid. </dd>
 <dt><a href="/miolo/doc/modules/gnuteca/gtk/util/grid.Grid.php">Grid($Title, $Titles, $width, $height, $label='ok')</a></dt>
 <dd>Descri��o do m�todo Grid. </dd>
 <dt><a href="/miolo/doc/modules/gnuteca/gtk/util/grid.Exibe.php">Exibe()</a></dt>
 <dd>Descri��o do m�todo Exibe. </dd>
 <dt><a href="/miolo/doc/modules/gnuteca/gtk/util/grid.AdicionaLinhas.php">AdicionaLinhas($Contents)</a></dt>
 <dd>Descri��o do m�todo AdicionaLinhas. </dd>
</dl>
<p>&nbsp;</p>
<? include '/usr/local/bis/html//miolo/doc/footer.inc' ?>
</body>
</html>
