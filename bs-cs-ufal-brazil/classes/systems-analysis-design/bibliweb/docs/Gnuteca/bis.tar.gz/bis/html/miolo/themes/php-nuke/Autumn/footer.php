<?PHP
if ($index == 1) {
    echo "</td><td><table BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=\"100%\" >";
    category();
    pollNewest();
    loginbox();
    userblock();
    oldNews($storynum);
    rightblocks();
    echo "</td>";
}
echo "</td></tr></table></td></tr></table>";
footmsg();
?>