<?php

$thename = "Barrapunto";
$bgcolor1 = "#FFFFFF";
$bgcolor2 = "#6383b5";
$bgcolor3 = "#FFFFFF";
$bgcolor4 = "#6383b5";
$textcolor1 = "#FFFFFF";
$textcolor2 = "#000000";
$hr = 0; # 1 to have horizonal rule in comments instead of table bgcolor

function themeindex($aid, $informant, $datetime, $title, $counter, $topic, $thetext, $notes, $morelink, $topicname, $topicimage, $topictext) {
	global $tipath, $anonymous;
	if ("$aid" == "$informant") { ?>
		<p>
		<table width="99%" cellpadding=0 cellspacing=0 border=0 bgcolor=ff6600>
		<tbody>
		<tr>
		<td valign=top>
		 <table width="100%" cellpadding=5 cellspacing=2 border=0 bgcolor=ff6600>
		  <tbody>
		  <tr>
		   <td bgcolor=ffFFff><font size=4 color="#FF6600"><b>
		    <?php echo"$title"; ?></b></font>
		   </td>
		  </tr>
		  </tbody>
		 </table>
		</td>
		</tr>
		</tbody>
		</table>

		<font color=ff6600>
		<?php echo translate ("Posted by "); ?> <?php formatAidHeader($aid) ?> <?php echo translate("on"); ?> 
		<?php echo"$datetime $timezone"; ?> - (<?php echo $counter; ?> <?php echo translate("reads"); ?>)</font><p>
		<a href="search.php?query=&topic=<?php echo"$topic"; ?>&author="><img src=<?php echo"$tipath$topicimage"; ?> border=0 Alt=<?php echo"\"$topictext\""; ?> align=right hspace=10 vspace=10 border=0></a>
		<br><?php echo"$thetext<br><br>$morelink"; ?><p>
<?php	} else {
		if($informant != "") $boxstuff = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
		else $boxstuff = "$anonymous ";
		$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes"; ?>
		<p>
		<table width="99%" cellpadding=0 cellspacing=0 border=0 bgcolor=ff6600>
		<tbody>
		<tr>
		<td valign=top>
		 <table width="100%" cellpadding=5 cellspacing=2 border=0 bgcolor=ff6600>
		  <tbody>
		  <tr>
		   <td bgcolor=ffFFff><font size=4 color="#FF6600"><b>
		    <?php echo"$title"; ?></b></font>
		   </td>
		  </tr>
		  </tbody>
		 </table>
		</td>
		</tr>
		</tbody>
		</table>

		<font color=ff6600>
		<?php echo translate ("Posted by "); ?> <?php formatAidHeader($aid) ?> <?php echo translate("on"); ?> 
		<?php echo"$datetime $timezone"; ?> - (<?php echo $counter; ?> <?php echo translate("reads"); ?>)</font><p>
		<a href="search.php?query=&topic=<?php echo"$topic"; ?>&author="><img src=<?php echo"$tipath$topicimage"; ?> border=0 Alt=<?php echo"\"$topictext\""; ?> align=right hspace=10 vspace=10 border=0></a>
		<br><?php echo"$thetext<br><br>$morelink"; ?><p>
<?php	}
}

function themearticle ($aid, $informant, $datetime, $title, $thetext) {
	global $admin, $sid, $tipath;
	if ("$aid" == "$informant") { ?>
		<p>
		<table width="99%" cellpadding=0 cellspacing=0 border=0 bgcolor=ff6600>
		<tbody>
		<tr>
		<td valign=top>
		 <table width="100%" cellpadding=5 cellspacing=2 border=0 bgcolor=ff6600>
		  <tbody>
		  <tr>
		   <td bgcolor=ffFFff><font size=4 color="#FF6600"><b>
		    <?php echo"$title"; ?></b></font>
		   </td>
		  </tr>
		  </tbody>
		 </table>
		</td>
		</tr>
		</tbody>
		</table>

		<font color=ff6600>
		<?php echo translate ("Posted by "); ?> <?php formatAidHeader($aid) ?> <?php echo translate("on"); ?> 
		<?php echo"$datetime $timezone"; ?><br>
                <?php echo"$thetext"; ?>

<?php	} else {
		if($informant != "") $boxstuff = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
		else $boxstuff = "$anonymous ";
		$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes";
?>		
		<p>
		<table width="99%" cellpadding=0 cellspacing=0 border=0 bgcolor=ff6600>
		<tbody>
		<tr>
		<td valign=top>
		 <table width="100%" cellpadding=5 cellspacing=2 border=0 bgcolor=ff6600>
		  <tbody>
		  <tr>
		   <td bgcolor=ffFFff><font size=4 color="#FF6600"><b>
		    <?php echo"$title"; ?></b></font>
		   </td>
		  </tr>
		  </tbody>
		 </table>
		</td>
		</tr>
		</tbody>
		</table>

		<font color=ff6600>
		
 	        <?PHP echo translate ("Posted by ") ?>
		<?PHP formatAidHeader($aid)  ?>
		<?PHP echo translate("on"); ?>
		<?PHP echo"$datetime $timezone"; ?>
		<?PHP
		if ($admin) {
                echo "&nbsp;&nbsp; $font2 [ <a href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]";
                } ; ?> 
		<br><br></font>
                <?php echo"$boxstuff"; ?>

<?php	}
}

function themesidebox($title, $content) {
    echo "
    <table border=0 cellspacing=0 cellpadding=0 width=100% bgcolor=FF6600><tr><td>
    <table width=100% border=0 cellspacing=2 cellpadding=5><tr><td colspan=1 bgcolor=FFFFFF>
    <font size=2 color=FF6600>$title</td></tr><tr><td bgcolor=FFFFFF>
    <font size=2>$content</td></tr></table></td></tr></table><br>";


}


