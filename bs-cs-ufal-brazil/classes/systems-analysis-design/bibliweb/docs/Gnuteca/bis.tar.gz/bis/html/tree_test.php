<?php

include 'miolo/tree.class';

$tree = new Tree();
$tree->AddItem(1,null,'Item 1');

?>
<pre>
<?var_dump($tree);?>
</pre>
