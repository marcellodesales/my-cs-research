<?php

$thename = "AQUA";
$lnkcolor = "FFFFFF";
$bgcolor1 = "#EEEEEE";
$bgcolor2 = "#BCBCBC";
$bgcolor3 = "#EEEEEE";
$bgcolor4 = "#DEDEDE";
$textcolor1 = "#FFFFFF";
$textcolor2 = "#000000";
$hr = 1; # 1 to have horizonal rule in comments instead of table bgcolor

function themeindex ($aid, $informant, $time, $title, $counter, $topic, $thetext, $notes, $morelink, $topicname, $topicimage, $topictext) {
	global $tipath, $anonymous;
	
	
	
		if ("$aid" == "$informant") { ?>

<table width="100%" border="0" cellspacing="0" cellpadding="0" >
  <tr> 
    <td width="15" height="15" background="themes/Aqua/images/cadre/coinsupg.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" colspan="3" background="themes/Aqua/images/cadre/sup.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td width="15" height="15" background="themes/Aqua/images/cadre/coinsupd.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
  </tr>
  <tr> 
    <td width="15" rowspan="4" background="themes/Aqua/images/cadre/g.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" width="15" background="themes/Aqua/images/cadre/carresupg.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" background="themes/Aqua/images/cadre/carresup.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" width="15" background="themes/Aqua/images/cadre/carresupd.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td width="15" rowspan="4" background="themes/Aqua/images/cadre/d.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
  </tr>
  <tr> 
    <td background="themes/Aqua/images/cadre/carreg.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
      <td background="themes/Aqua/images/cadre/carrefond.gif" align="left" width="100%" ><B><?php echo"$title"; ?></B><BR><FONT SIZE=2><?php echo translate("Posted by "); ?><b><?php formatAidHeader($aid) ?></b> <?php echo translate("on"); ?> <?php echo"$time $timezone"; ?><br>(<?php echo $counter; ?> <?php echo translate("reads"); ?>)<br></FONT></td>
    <td width="15" background="themes/Aqua/images/cadre/carred.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
  </tr>
  <tr> 
    <td height="15" width="15" background="themes/Aqua/images/cadre/carreinfg.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" background="themes/Aqua/images/cadre/carreinf.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" width="15" background="themes/Aqua/images/cadre/carreinfd.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
  </tr>
  <tr> 
      <td colspan="3" background="themes/Aqua/images/cadre/fond.gif"><FONT size=2>
    <a href="search.php?query=&topic=<?php echo"$topic"; ?>&author="><img src=<?php echo"$tipath$topicimage"; ?> border=1 Alt=<?php echo"\"$topictext\""; ?> align=left hspace=10 vspace=10></a>
    <?php echo"$thetext<br><br>$morelink"; ?></td>
  </tr>
  <tr> 
    <td width="15" height="15" background="themes/Aqua/images/cadre/coininfg.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" colspan="3" background="themes/Aqua/images/cadre/inf.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td width="15" height="15" background="themes/Aqua/images/cadre/coininfd.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
  </tr>
</table>


<?php	} 




else {
		if($informant != "") $boxstuff = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
		else $boxstuff = "$anonymous ";
		$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes";
?>


<table width="100%" border="0" cellspacing="0" cellpadding="0" >
  <tr> 
    <td width="15" height="15" background="themes/Aqua/images/cadre/coinsupg.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" colspan="3" background="themes/Aqua/images/cadre/sup.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td width="15" height="15" background="themes/Aqua/images/cadre/coinsupd.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
  </tr>
  <tr> 
    <td width="15" rowspan="4" background="themes/Aqua/images/cadre/g.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" width="15" background="themes/Aqua/images/cadre/carresupg.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" background="themes/Aqua/images/cadre/carresup.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" width="15" background="themes/Aqua/images/cadre/carresupd.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td width="15" rowspan="4" background="themes/Aqua/images/cadre/d.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
  </tr>
  <tr> 
    <td background="themes/Aqua/images/cadre/carreg.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
      <td background="themes/Aqua/images/cadre/carrefond.gif" align="left" width="100%" ><B><?php echo"$title"; ?></B><BR><FONT SIZE=2>
    <?php echo translate("Posted by "); ?><?php formatAidHeader($aid); ?> <?php echo translate("on"); ?> <?php echo"$time $timezone"; ?><br>(<?php echo $counter; ?> <?php echo translate("reads"); ?>)<br></FONT></td>
    <td width="15" background="themes/Aqua/images/cadre/carred.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
  </tr>
  <tr> 
    <td height="15" width="15" background="themes/Aqua/images/cadre/carreinfg.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" background="themes/Aqua/images/cadre/carreinf.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" width="15" background="themes/Aqua/images/cadre/carreinfd.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
  </tr>
  <tr> 
      <td colspan="3" background="themes/Aqua/images/cadre/fond.gif"><FONT size=2>
    <a href="search.php?query=&topic=<?php echo"$topic"; ?>&author="><img src=<?php echo"$tipath$topicimage"; ?> border=1 Alt=<?php echo"\"$topictext\""; ?> align=left hspace=10 vspace=10></a>
    <?php echo"$boxstuff<br><br>$morelink"; ?></td>
  </tr>
  <tr> 
    <td width="15" height="15" background="themes/Aqua/images/cadre/coininfg.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" colspan="3" background="themes/Aqua/images/cadre/inf.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td width="15" height="15" background="themes/Aqua/images/cadre/coininfd.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
  </tr>
</table>



<?php	}
}




function themearticle ($aid, $informant, $datetime, $title, $thetext, $topic, $topicname, $topicimage, $topictext) {
	global $admin, $sid, $tipath;
	
	
	if ("$aid" == "$informant") {

?>
<table width="100%" border="0" cellspacing="0" cellpadding="0" >
  <tr> 
    <td width="15" height="15" background="themes/Aqua/images/cadre/coinsupg.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" colspan="3" background="themes/Aqua/images/cadre/sup.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td width="15" height="15" background="themes/Aqua/images/cadre/coinsupd.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
  </tr>
  <tr> 
    <td width="15" rowspan="4" background="themes/Aqua/images/cadre/g.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" width="15" background="themes/Aqua/images/cadre/carresupg.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" background="themes/Aqua/images/cadre/carresup.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" width="15" background="themes/Aqua/images/cadre/carresupd.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td width="15" rowspan="4" background="themes/Aqua/images/cadre/d.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
  </tr>
  <tr> 
    <td background="themes/Aqua/images/cadre/carreg.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
      <td background="themes/Aqua/images/cadre/carrefond.gif" align="left" width="100%" >
      	<?
      	echo "<FONT size=3 color=blue><b>$title</b><br><font size=1>".translate("Posted on ")." $datetime";
		if ($admin)
			{
			echo "&nbsp;&nbsp; $font2 [ <a href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]";
    		}
      	?>
      </td>
    <td width="15" background="themes/Aqua/images/cadre/carred.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
  </tr>
  <tr> 
    <td height="15" width="15" background="themes/Aqua/images/cadre/carreinfg.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" background="themes/Aqua/images/cadre/carreinf.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" width="15" background="themes/Aqua/images/cadre/carreinfd.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
  </tr>
  <tr> 
      <td colspan="3" background="themes/Aqua/images/cadre/fond.gif">
      <?
      echo "<FONT size=2><a href=search.php?query=&topic=$topic&author=><img src=$tipath$topicimage border=1 Alt=\"$topictext\" align=left hspace=10 vspace=10></a>$thetext";

      ?>
      </td>
  </tr>
  <tr> 
    <td width="15" height="15" background="themes/Aqua/images/cadre/coininfg.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" colspan="3" background="themes/Aqua/images/cadre/inf.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td width="15" height="15" background="themes/Aqua/images/cadre/coininfd.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
  </tr>
</table>
<?





	} 
	
	
	
	else {
		if($informant != "") $informant = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
		else $boxstuff = "$anonymous ";
		$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes";


?>
<table width="100%" border="0" cellspacing="0" cellpadding="0" >
  <tr> 
    <td width="15" height="15" background="themes/Aqua/images/cadre/coinsupg.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" colspan="3" background="themes/Aqua/images/cadre/sup.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td width="15" height="15" background="themes/Aqua/images/cadre/coinsupd.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
  </tr>
  <tr> 
    <td width="15" rowspan="4" background="themes/Aqua/images/cadre/g.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" width="15" background="themes/Aqua/images/cadre/carresupg.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" background="themes/Aqua/images/cadre/carresup.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" width="15" background="themes/Aqua/images/cadre/carresupd.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td width="15" rowspan="4" background="themes/Aqua/images/cadre/d.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
  </tr>
  <tr> 
    <td background="themes/Aqua/images/cadre/carreg.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
      <td background="themes/Aqua/images/cadre/carrefond.gif" align="left" width="100%" >
      	<?
      	echo "<FONT size=3 color=blue><b>$title</b><br><font size=2>".translate("Contributed by ")." $informant ".translate("on")." $datetime</font>";
		if ($admin)
			{
			echo "&nbsp;&nbsp; $font2 [ <a href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]";
    		}
      	?>
      </td>
    <td width="15" background="themes/Aqua/images/cadre/carred.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
  </tr>
  <tr> 
    <td height="15" width="15" background="themes/Aqua/images/cadre/carreinfg.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" background="themes/Aqua/images/cadre/carreinf.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" width="15" background="themes/Aqua/images/cadre/carreinfd.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
  </tr>
  <tr> 
      <td colspan="3" background="themes/Aqua/images/cadre/fond.gif">
      <?
      echo "<FONT size=2><a href=search.php?query=&topic=$topic&author=><img src=$tipath$topicimage border=1 Alt=\"$topictext\" align=left hspace=10 vspace=10></a>$thetext";

      ?>
      </td>
  </tr>
  <tr> 
    <td width="15" height="15" background="themes/Aqua/images/cadre/coininfg.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" colspan="3" background="themes/Aqua/images/cadre/inf.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td width="15" height="15" background="themes/Aqua/images/cadre/coininfd.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
  </tr>
</table>
<?


    }
}




function themesidebox($title, $content) {


?>
<table width="180" border="0" cellspacing="0" cellpadding="0" >
  <tr> 
    <td width="15" height="15" background="themes/Aqua/images/cadre/coinsupg.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" colspan="3" background="themes/Aqua/images/cadre/sup.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td width="15" height="15" background="themes/Aqua/images/cadre/coinsupd.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
  </tr>
  <tr> 
    <td width="15" rowspan="4" background="themes/Aqua/images/cadre/g.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" width="15" background="themes/Aqua/images/cadre/carrebsupg.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" background="themes/Aqua/images/cadre/carrebsup.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" width="15" background="themes/Aqua/images/cadre/carrebsupd.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td width="15" rowspan="4" background="themes/Aqua/images/cadre/d.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
  </tr>
  <tr> 
    <td background="themes/Aqua/images/cadre/carrebg.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
      <td background="themes/Aqua/images/cadre/carrebfond.gif" align="center" width="180" >
      	<B><FONT size=2 color=black><? echo "$title"; ?></B></FONT>
      </td>
    <td width="15" background="themes/Aqua/images/cadre/carrebd.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
  </tr>
  <tr> 
    <td height="15" width="15" background="themes/Aqua/images/cadre/carrebinfg.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" background="themes/Aqua/images/cadre/carrebinf.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" width="15" background="themes/Aqua/images/cadre/carrebinfd.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
  </tr>
  <tr> 
      <td colspan="3" background="themes/Aqua/images/cadre/fond.gif"  align="left"  width="180" >
      <BR><B><FONT size=2 color=black><? echo "$content"; ?><BR></B></FONT>
      </td>
  </tr>
  <tr> 
    <td width="15" height="15" background="themes/Aqua/images/cadre/coininfg.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td height="15" colspan="3" background="themes/Aqua/images/cadre/inf.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
    <td width="15" height="15" background="themes/Aqua/images/cadre/coininfd.gif"><img src="themes/Aqua/images/space15_15.gif" width="15" height="15"></td>
  </tr>
</table>
<?

}

?>