<html>
<head>
 <title> MIOLO - Database:Close</title>
 <link rel="stylesheet" href="doc.css">
</head>
<body>
<? include 'header.inc' ?>
<h3 align="right">Classe: <a href="Database.class.php">Database</a></h3>
<h2>Close()
</h2>
<p>Fecha a conex�o com o BD.</p>
<p>&nbsp;</p>
<pre>
<?php
highlight_string(
'<?php
    ...
    $Database->Close(); 
    ...
?>');
?>
</pre>
<? include 'footer.inc' ?>
</body>
</html>
