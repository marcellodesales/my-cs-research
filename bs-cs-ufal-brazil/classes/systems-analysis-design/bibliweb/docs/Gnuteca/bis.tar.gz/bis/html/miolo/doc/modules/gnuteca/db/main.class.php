<html>
<head>
 <title> MIOLO - Classe main</title>
 <link rel="stylesheet" href="/miolo/doc/doc.css">
</head>
<body>
<? include '/usr/local/bis/html//miolo/doc/header.inc' ?>
<h2>Classe: BusinessGNUTecaMain</h2>
<blockquote>
extends <a href="#.class.php">SuperClasse</a>
</blockquote>
<p>TODO: Escrever documenta��o da classe BusinessGNUTecaMain.</p>
<h3>M�todos:</h3>
<dl>
 <dt><a href="/miolo/doc/modules/gnuteca/db/main.BusinessGNUTecaMain.php">BusinessGNUTecaMain()</a></dt>
 <dd>Descri��o do m�todo BusinessGNUTecaMain. </dd>
 <dt><a href="/miolo/doc/modules/gnuteca/db/main.GetDireito.php">GetDireito()</a></dt>
 <dd>Descri��o do m�todo GetDireito. </dd>
 <dt><a href="/miolo/doc/modules/gnuteca/db/main.GetGrupo.php">GetGrupo()</a></dt>
 <dd>Descri��o do m�todo GetGrupo. </dd>
 <dt><a href="/miolo/doc/modules/gnuteca/db/main.GetOperacao.php">GetOperacao()</a></dt>
 <dd>Descri��o do m�todo GetOperacao. </dd>
 <dt><a href="/miolo/doc/modules/gnuteca/db/main.GetMaterial.php">GetMaterial()</a></dt>
 <dd>Descri��o do m�todo GetMaterial. </dd>
 <dt><a href="/miolo/doc/modules/gnuteca/db/main.GetExemplar.php">GetExemplar()</a></dt>
 <dd>Descri��o do m�todo GetExemplar. </dd>
 <dt><a href="/miolo/doc/modules/gnuteca/db/main.GetPessoa.php">GetPessoa()</a></dt>
 <dd>Descri��o do m�todo GetPessoa. </dd>
 <dt><a href="/miolo/doc/modules/gnuteca/db/main.GetMulta.php">GetMulta()</a></dt>
 <dd>Descri��o do m�todo GetMulta. </dd>
 <dt><a href="/miolo/doc/modules/gnuteca/db/main.GetEmprestimo.php">GetEmprestimo()</a></dt>
 <dd>Descri��o do m�todo GetEmprestimo. </dd>
 <dt><a href="/miolo/doc/modules/gnuteca/db/main.GetReserva.php">GetReserva()</a></dt>
 <dd>Descri��o do m�todo GetReserva. </dd>
 <dt><a href="/miolo/doc/modules/gnuteca/db/main.GetSituacao.php">GetSituacao()</a></dt>
 <dd>Descri��o do m�todo GetSituacao. </dd>
 <dt><a href="/miolo/doc/modules/gnuteca/db/main.GetEstado.php">GetEstado()</a></dt>
 <dd>Descri��o do m�todo GetEstado. </dd>
 <dt><a href="/miolo/doc/modules/gnuteca/db/main.GetTransicao.php">GetTransicao()</a></dt>
 <dd>Descri��o do m�todo GetTransicao. </dd>
</dl>
<p>&nbsp;</p>
<? include '/usr/local/bis/html//miolo/doc/footer.inc' ?>
</body>
</html>
