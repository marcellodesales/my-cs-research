<?php


function themeindex ($aid, $informant, $datetime, $title, $counter, $topic, $thetext, $notes, $morelink, $topicname, $topicimage, $topictext) {
  include("config.php");
  include("themes/Dummy/vars.php");
  if("$aid" == "$informant") { ?>
	<!-- Regular Story HTML posted by ADMIN-->
    <table border=0 cellpadding=0 cellspacing=0 width=100% background="<? echo $background2; ?>">
      <tr>
        <td width=<? echo $c_width; ?> height=<? echo $c_height; ?> background="<? echo $corner_top_left; ?>" nowrap align="center"><img src=<? echo $corner_top_left; ?>></td>
        <td background="<? echo $bar_top; ?>"><img src=<? echo $bar_top; ?>></td>
        <td width=<? echo $c_width; ?> height=<? echo $c_height; ?> background="<? echo $corner_top_right; ?>" nowrap align="center"><img src=<? echo $corner_top_right; ?>></td>
      </tr>
      <tr>
        <td background="<? echo $bar_left; ?>" align="left"></td>
        <td  align="left" valign="top" background="<? echo $background2; ?>">

          <!-- The content -->		  
		  <table cellpadding="5" cellspacing="5" width="100%" align="center">
		    <tr>
			  <td <? if($ie_style) { echo "style='border-style: $style_type' valign=top height=$style_height align=left"; } ?>>
  		        <font size=<? echo $fontsize1; ?>><B><!--blabla--><?php echo"$title"; ?></B></font><p>
		        <font size=<? echo $fontsize3; ?>><?php echo translate("Posted by "); ?><b><?php formatAidHeader($aid) ?></b> <?php echo translate("on"); ?> <?php echo"$datetime $timezone"; ?> (<?php echo $counter; ?> <?php echo translate("reads"); ?>)</font><br></td>
              </td>
		    </tr>
		  </table>
          <!-- end of content -->		  
		  
		  <td background="<? echo $bar_right; ?>"></td>
        </tr>
        <tr>
          <td background="<? echo $bar_left; ?>" align="left"></td>
	      <td valign="top" background="<? echo $background2; ?>">
		  
            <!-- The content -->		  
		    <table cellpadding="5" cellspacing="5" width="100%" align="center">
			  <tr>
			    <td <? if($ie_style) { echo "style='border-style: $style_type' valign=top height=$style_height align=left"; } ?>>
                  <font size=<? echo $fontsize2; ?>>
                  <a href="search.php?query=&topic=<?php echo"$topic"; ?>&author="><img src=<?php echo"$tipath$topicimage"; ?> border=1 Alt=<?php echo"\"$topictext\""; ?> align=right hspace=10 vspace=10></a>
                  <?php echo"<font size=<? echo $fontsize2; ?>$thetext<br>"; ?></font>
                </td>
		      </tr>
		    </table>
            <!-- end of content -->		  

          </td>
          <td background="<? echo $bar_right; ?>"></td>
        </tr>
        <tr>
          <td background="<? echo $bar_left; ?>"></td>
          <td width="100%" align="left" background="<? echo $background2; ?>">
		  
            <!-- The content -->		  
		    <table cellpadding="5" cellspacing="5" width="99%" align="center">
			  <tr>
			    <td <? if($ie_style) { echo "style='border-style: $style_type' valign=top height=$style_height align=left"; } ?>>
                  <font size=<? echo $fontsize3; ?>><b><?php echo "$morelink"; ?></b></font>
			    </td>
			  </tr>
			</table>
            <!-- end of content -->		  

		  </td>
          <td background="<? echo $bar_right; ?>"></td>
        </tr>
        <tr>
          <td width=<? echo $c_width; ?> height=<? echo $c_height; ?> background="<? echo $corner_bottom_left; ?>" nowrap align="center"><img src=<? echo $corner_bottom_left; ?>></td>
          <td align="center" valign="top" background="<? echo $bar_bottom; ?>"><img src=<? echo $bar_bottom; ?>></td>
          <td width=<? echo $c_width; ?> height=<? echo $c_height; ?> background="<? echo $corner_bottom_right; ?>" nowrap align="center"><img src=<? echo $corner_bottom_right; ?>></td>
        </tr>
      </table>
	  <br>
<?php	
      } else {
		if($informant != "") $boxstuff = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
		else $boxstuff = "$anonymous ";
		$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes";
?>
      <table border=0 cellpadding=0 cellspacing=0 align=center width=100%>
        <tr>
		  <td>
            <!-- Story HTML posted by USER-->
            <table border=0 cellpadding=0 cellspacing=0 width=100% background="<? echo $background2; ?>">
            <tr>
              <td width=<? echo $c_width; ?> height=<? echo $c_height; ?> background="<? echo $corner_top_left; ?>" nowrap align="center"><img src=<? echo $corner_top_left; ?>></td>
              <td background="<? echo $bar_top; ?>"><img src=<? echo $bar_top;?>></td>
              <td width=<? echo $c_width; ?> height=<? echo $c_height; ?> background="<? echo $corner_top_right; ?>" nowrap align="center"><img src=<? echo $corner_top_right; ?>></td>
            </tr>
            <tr>
              <td background="<? echo $bar_left; ?>" align="left"></td>
              <td width="100%" align="left" valign="top" background="<? echo $background2; ?>">
			  
                <!-- The content -->		  
		        <table cellpadding="5" cellspacing="5" width="99%" align="center">
				  <tr>
				    <td <? if($ie_style) { echo "style='border-style: $style_type' valign=top height=$style_height align=left"; } ?>>
			          <font size=<? echo $fontsize1; ?>><b><?php echo"$title"; ?></b></font><p><font size=<? echo $fontsize3; ?>><?php echo translate("Posted by "); ?><b><?php formatAidHeader($aid); ?></b> <?php echo translate("on"); ?> <?php echo"$datetime $timezone"; ?> (<?php echo $counter; ?> <?php echo translate("reads"); ?>)<br></font>
                    </td>
				  </tr>
				</table>
                <!-- end of content -->		  
			  
			  </td>
              <td background="<? echo $bar_right; ?>"></td>
            </tr>
            <tr>
              <td background="<? echo $bar_left; ?>" align="left"></td>
              <td width=100% valign="top" background="<? echo $background2; ?>">
			  
                <!-- The content -->		  
		        <table cellpadding="5" cellspacing="5" width="99%" align="center">
				  <tr>
				    <td <? if($ie_style) { echo "style='border-style: $style_type' valign=top height=$style_height align=left"; } ?>>
			          <font size=<? echo $fontsize2; ?>>
			          <a href="search.php?query=&topic=<?php echo"$topic"; ?>&author="><img src=<?php echo"$tipath$topicimage"; ?> border=1 Alt=<?php echo"\"$topictext\""; ?> align=right hspace=10 vspace=10></a>
                      <?php echo"$boxstuff<br><br>"; ?>
			          </font>
                    </td>
				  </tr>
				</table>
                <!-- end of content -->		  

              </td>
              <td background="<? echo $bar_right; ?>"></td>
            </tr>
            <tr>
              <td background="<? echo $bar_left; ?>"></td>
              <td width="99%" align="left" background="<? echo $background2; ?>">

                <!-- The content -->		  
		        <table cellpadding="5" cellspacing="5" width="99%" align="center">
				  <tr>
				    <td <? if($ie_style) { echo "style='border-style: $style_type' valign=top height=$style_height align=left"; } ?>>
                      <font size=<? echo $fontsize3; ?>><b><?php echo "$morelink"; ?></b></font>
                    </td>
				  </tr>
				</table>
                <!-- end of content -->		  

			  </td>
              <td background="<? echo $bar_right; ?>"></td>
            </tr>
            <tr>
              <td width=<? echo $c_width; ?> height=<? echo $c_height; ?> background="<? echo $corner_bottom_left; ?>" nowrap align="center"><img src=<? echo $corner_bottom_left; ?>></td>
              <td align="center" valign="top" background="<? echo $bar_bottom; ?>"><img src=<? echo $bar_bottom; ?>></td>
              <td width=<? echo $c_width; ?> height=<? echo $c_height; ?> background="<? echo $corner_bottom_right; ?>" nowrap align="center"><img src=<? echo $corner_bottom_right; ?>></td>
            </tr>
            </table>
		  </td>
		</tr>
	  </table>
      <br>
<?php	}
}

function themearticle ($aid, $informant, $datetime, $title, $thetext, $topic, $topicname, $topicimage, $topictext) {
  include("config.php");
  include("themes/Dummy/vars.php");
  if ("$aid" == "$informant") { ?>
	  <table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr valign="top">
		  <td width=<? echo $c_width; ?> height=<? echo $c_height; ?>><img src="<? echo $corner_top_left; ?>"></td>
			<td width="100%">
			  <table width="100%" border="0" cellpadding="0" cellspacing="0">
			    <tr>
				  <td background="<? echo $bar_top; ?>"><img src="<? echo $bar_top; ?>" border="0"></td>
				</tr>
			  </table>
			</td>
			<td width=<? echo $c_width; ?> height=<? echo $c_height; ?>><img src="<? echo $corner_top_right; ?>"></td>
          </tr>
		</table>

		<!-- Surrounding table to create border -->
        <table border=0 cellpadding="0" cellspacing="0">
		  <tr>
		    <td width=<? echo $l_width; ?> background="<? echo $bar_left; ?>"><img src="<? echo $bar_left; ?>" border="0"></td>
			<td>
              <table border="0" cellpadding="0" cellspacing="0">
			    <tr bgcolor="#e6e6e6">
                  <td width="100%">
				    <table width="100%" border="0" cellpadding="5" cellspacing="0">
				      <tr>
				        <td><font size=<? echo $fontsize2; ?> color="#000000"><B><?php echo"$title"; ?></B></font></td>
				      </tr>
				      <tr>
                        <td>
						  <font size=<? echo $fontsize3; ?>><?php echo translate("Posted by "); ?> <?php formatAidHeader($aid) ?> <?php echo translate("on"); ?> <?php echo"$datetime $timezone"; ?>
                          <?php
                            global $admin, $sid;
                              if ($admin) {
                                echo "&nbsp;&nbsp; $font2 [ <a href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]";
                              }
                          ?>
                          <br><?php echo "$font1"; ?>
						  <?php echo "".translate("Contributed by ").""; ?> <?php echo "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a>"; ?></font>
		                </td>
				      </tr>
					</table>
			      </td>
		        </tr>
		        <tr>
			      <td width="100%">
				    <table background="<? echo $background2; ?>" width="100%" border="0" cellpadding="5" cellspacing="0">
				      <tr>
					    <td>
                          <?php echo "<a href=search.php?query=&topic=$topic&author=><img src=$tipath$topicimage border=0 Alt=\"$topictext\" align=right hspace=10 vspace=10></a>"; ?>
                          <?php echo "$thetext"; ?>
                        </td>
					  </tr>
					</table>
				  </td>
                </tr>
		      </table>
		    </td>
			<td background="<? echo $bar_right; ?>"><img src="<? echo $bar_right; ?>" border="0"></td>
		  </tr>
		  <tr>
		    <td background="<? echo $corner_bottom_left; ?>"><img src="<? echo $corner_bottom_left; ?>"></td><td background="<? echo $bar_bottom; ?>"><img src="<? echo $bar_bottom; ?>"></td><td background="<? echo $corner_bottom_right; ?>"><img src="<? echo $corner_bottom_right; ?>"></td>
		  </tr>
        </table>
		<!-- Surrounding table ends here -->
<? 
  } else {
	  if($informant != "") $boxstuff = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
	  else $boxstuff = "$anonymous ";
	  $boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes";
?>	  <table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr valign="top">
		  <td width=<? echo $c_width; ?> height=<? echo $c_height; ?>><img src="<? echo $corner_top_left; ?>"></td>
			<td width="100%">
			  <table width="100%" border="0" cellpadding="0" cellspacing="0">
			    <tr>
				  <td background="<? echo $bar_top; ?>"><img src="<? echo $bar_top; ?>" border="0"></td>
				</tr>
			  </table>
			</td>
			<td width=<? echo $c_width; ?> height=<? echo $c_height; ?>><img src="<? echo $corner_top_right; ?>"></td>
          </tr>
		</table>

		<!-- Surrounding table to create border -->
        <table border=0 cellpadding="0" cellspacing="0">
		  <tr>
		    <td width=<? echo $l_width; ?> background="<? echo $bar_left; ?>"><img src="<? echo $bar_left; ?>" border="0"></td>
			<td>
              <table border="0" cellpadding="0" cellspacing="0">
			    <tr bgcolor="#e6e6e6">
                  <td width="100%">
				    <table width="100%" border="0" cellpadding="5" cellspacing="0">
				      <tr>
				        <td><font size=<? echo $fontsize2; ?> color="#000000"><B><?php echo"$title"; ?></B></font></td>
				      </tr>
				      <tr>
                        <td>
						  <font size=<? echo $fontsize3; ?>><?php echo translate("Posted by "); ?> <?php formatAidHeader($aid) ?> <?php echo translate("on"); ?> <?php echo"$datetime $timezone"; ?>
                          <?php
                            global $admin, $sid;
                              if ($admin) {
                                echo "&nbsp;&nbsp; $font2 [ <a href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]";
                              }
                          ?>
                          <br><?php echo "$font1"; ?>
                          <?php echo "".translate("Contributed by ").""; ?> <?php echo "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a>"; ?></font>
		                </td>
				      </tr>
					</table>
			      </td>
		        </tr>
		        <tr>
			      <td width="100%">
				    <table background="<? echo $background2; ?>" width="100%" border="0" cellpadding="5" cellspacing="0">
				      <tr>
					    <td>
                          <?php echo "<a href=search.php?query=&topic=$topic&author=><img src=$tipath$topicimage border=0 Alt=\"$topictext\" align=right hspace=10 vspace=10></a>"; ?>
                          <?php echo "$thetext"; ?>
                        </td>
					  </tr>
					</table>
				  </td>
                </tr>
		      </table>
		    </td>
			<td background="<? echo $bar_right; ?>"><img src="<? echo $bar_right; ?>" border="0"></td>
		  </tr>
		  <tr>
		    <td background="<? echo $corner_bottom_left; ?>"><img src="<? echo $corner_bottom_left; ?>"></td><td background="<? echo $bar_bottom; ?>"><img src="<? echo $bar_bottom; ?>"></td><td background="<? echo $corner_bottom_right; ?>"><img src="<? echo $corner_bottom_right; ?>"></td>
		  </tr>
        </table>
		<!-- Surrounding table ends here -->
<?php
  }
}

function themesidebox($title, $content) { 
	include("config.php"); 
    include("themes/Dummy/vars.php");
	?>
    <table border="0" cellpadding="0" cellspacing="0" width="100%">
      <tr><!--msnavigation-->
        <td valign="top"> 
          <div align="center">

          <table border="0" cellpadding="0" cellspacing="0" background="<? echo $background2; ?>" height="100%" width="<? echo $themesidebox_width; ?>">
          <tr>
            <td width=<? echo $c_width; ?> height=<? echo $c_height; ?> background="<? echo $corner_top_left; ?>" nowrap align="center"> <img src=<? echo $corner_top_left; ?>></td>
            <td height=<? echo $t_height; ?> background="<? echo $bar_top; ?>" align="center"><img src=<? echo $bar_top; ?>></td>
            <td width=<? echo $c_width; ?> height=<? echo $c_height; ?> background="<? echo $corner_top_right; ?>" nowrap align="center"><img src=<? echo $corner_top_right; ?>></td>
          </tr>
          <tr>
            <td width=<? echo $l_width; ?> background="<? echo $bar_left; ?>" align="center" nowrap valign="middle"><img src=<? echo $bar_left; ?>></td>
            <td>
              <table border="0" cellpadding="6" cellspacing="6" width="100%">
                <tr> 
                  <td <? if($ie_style) { echo "style='border-style: $style_type' valign=top height=$style_height align=left"; } ?>><b><?php echo"$title"; ?></b></td>
                </tr>
                <tr> 
                  <td <? if($ie_style) { echo "style='border-style: $style_type' valign=top height=$style_height align=left"; } ?>><?php echo"$font2"; ?><font face="Arial" size=<? echo $fontsize2; ?>><?php echo"$content"; ?></font></td>
                </tr>
              </table>
            </td>
            <td width=<? echo $r_width; ?> background="<? echo $bar_right; ?>" align="center" nowrap valign="middle"><img src=<? echo $bar_right; ?>></td>
          </tr>
          <tr>
            <td width=<? echo $c_width; ?> height=<? echo $c_height; ?> background="<? echo $corner_bottom_left; ?>" nowrap align="center"><img src=<? echo $corner_bottom_left; ?>></td>
            <td background="<? echo $bar_bottom; ?>" height=<? echo $b_height; ?> align="center"><img src=<? echo $bar_bottom; ?>></td>
            <td width=<? echo $c_width; ?> height=<? echo $c_height; ?> background="<? echo $corner_bottom_right; ?>" nowrap align="center"><img src=<? echo $corner_bottom_right; ?>></td>
          </tr>
        </table><? if($display_shadow) { ?><img src=<? echo $shadow; ?> <? } ?>

          </div>
        </td>
      </tr>
	  <!--msnavigation-->
    </table>
  <br>
<?php
}
?>
