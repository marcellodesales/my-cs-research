<?php
echo "<body onload=init() background=themes/Patagonia/grid.gif text=000000 link=000000 vlink=000000 alink=000000>
<br>";
if ($banners) {
    include("banners.php");
}
echo "<br>
<a href=$nuke_url><img src=themes/Patagonia/logo.gif Alt=\"".translate("Welcome to")." $sitename\" border=0></a><br>
&nbsp;&nbsp;&nbsp;<font size=-1 color=FFFFFF>$slogan</font><br>

<table border=0 cellspacing=0 cellpadding=2 width=100%><tr><td valign=top width=150 bgcolor=006666>";

mainblock();
adminblock();
leftblocks();
online();

echo "<img src=images/pix.gif border=0 width=150 height=1></td><td>&nbsp;&nbsp;</td><td width=100% valign=top>";
?>