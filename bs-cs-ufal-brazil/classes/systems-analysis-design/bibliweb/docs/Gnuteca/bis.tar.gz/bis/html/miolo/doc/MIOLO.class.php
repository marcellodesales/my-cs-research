<html>
<head>
 <title> MIOLO - Classe MIOLO</title>
 <link rel="stylesheet" href="doc.css">
</head>
<body>
<? include 'header.inc' ?>
<h2>Classe MIOLO</h2>
<blockquote>
extends <a href="#.class.php">SuperClasse</a>
</blockquote>
<p>TODO: Escrever documenta��o da classe MIOLO.</p>
<h3>M�todos:</h3>
<dl>
 <dt><a href="MIOLO.MIOLO.php">MIOLO($home=null,$db='sagu')
</a></dt>
 <dd>Descri��o do m�todo MIOLO. </dd>
 <dt><a href="MIOLO.SetDatabase.php">SetDatabase($db)
</a></dt>
 <dd>Descri��o do m�todo SetDatabase. </dd>
 <dt><a href="MIOLO.Assert.php">Assert($cond,$msg='',$goto='')
</a></dt>
 <dd>Descri��o do m�todo Assert. </dd>
 <dt><a href="MIOLO.SetTheme.php">SetTheme($theme)
</a></dt>
 <dd>Descri��o do m�todo SetTheme. </dd>
 <dt><a href="MIOLO.GetActionURL.php">GetActionURL($module='',$action='NONE',$item='')
</a></dt>
 <dd>Descri��o do m�todo GetActionURL. </dd>
 <dt><a href="MIOLO.CheckLogin.php">CheckLogin()
</a></dt>
 <dd>Descri��o do m�todo CheckLogin. </dd>
 <dt><a href="MIOLO.CheckAccess.php">CheckAccess($module, $access, $deny=false)
</a></dt>
 <dd>Descri��o do m�todo CheckAccess. </dd>
 <dt><a href="MIOLO.GetRights.php">GetRights($module, $login)
</a></dt>
 <dd>Descri��o do m�todo GetRights. </dd>
 <dt><a href="MIOLO.GetUsersAllowed.php">GetUsersAllowed($module, $action)
</a></dt>
 <dd>Descri��o do m�todo GetUsersAllowed. </dd>
 <dt><a href="MIOLO.GetLogin.php">GetLogin()
</a></dt>
 <dd>Descri��o do m�todo GetLogin. </dd>
 <dt><a href="MIOLO.SetLogin.php">SetLogin($login)
</a></dt>
 <dd>Descri��o do m�todo SetLogin. </dd>
 <dt><a href="MIOLO.Uses.php">Uses($name,$module=null)
</a></dt>
 <dd>Descri��o do m�todo Uses. </dd>
 <dt><a href="MIOLO.GetDatabase.php">GetDatabase($other=null)
</a></dt>
 <dd>Descri��o do m�todo GetDatabase. </dd>
 <dt><a href="MIOLO.GetBusiness.php">GetBusiness($module,$name='main')
</a></dt>
 <dd>Descri��o do m�todo GetBusiness. </dd>
 <dt><a href="MIOLO.GetLookup.php">GetLookup($module)
</a></dt>
 <dd>Descri��o do m�todo GetLookup. </dd>
 <dt><a href="MIOLO.GetAutoComplete.php">GetAutoComplete($module,$item,$hint)
</a></dt>
 <dd>Descri��o do m�todo GetAutoComplete. </dd>
 <dt><a href="MIOLO.GetUI.php">GetUI()
</a></dt>
 <dd>Descri��o do m�todo GetUI. </dd>
 <dt><a href="MIOLO.GetAbsolutePath.php">GetAbsolutePath($rel=null)
</a></dt>
 <dd>Descri��o do m�todo GetAbsolutePath. </dd>
 <dt><a href="MIOLO.GetAbsoluteURL.php">GetAbsoluteURL($rel,$module=null)
</a></dt>
 <dd>Descri��o do m�todo GetAbsoluteURL. </dd>
 <dt><a href="MIOLO.GetModulePath.php">GetModulePath($module,$file)
</a></dt>
 <dd>Descri��o do m�todo GetModulePath. </dd>
 <dt><a href="MIOLO.Error.php">Error($msg='',$goto='')
</a></dt>
 <dd>Descri��o do m�todo Error. </dd>
 <dt><a href="MIOLO.Information.php">Information($msg,$goto='')
</a></dt>
 <dd>Descri��o do m�todo Information. </dd>
 <dt><a href="MIOLO.Confirmation.php">Confirmation($msg,$gotoOK='',$gotoCancel='')
</a></dt>
 <dd>Descri��o do m�todo Confirmation. </dd>
 <dt><a href="MIOLO.Question.php">Question($msg,$gotoYes='',$gotoNo='')
</a></dt>
 <dd>Descri��o do m�todo Question. </dd>
 <dt><a href="MIOLO.Prompt.php">Prompt($prompt)
</a></dt>
 <dd>Descri��o do m�todo Prompt. </dd>
 <dt><a href="MIOLO.LogSQL.php">LogSQL($sql,$force=false)
</a></dt>
 <dd>Descri��o do m�todo LogSQL. </dd>
 <dt><a href="MIOLO.LogError.php">LogError($error)
</a></dt>
 <dd>Descri��o do m�todo LogError. </dd>
 <dt><a href="MIOLO.ProfileTime.php">ProfileTime()
</a></dt>
 <dd>Descri��o do m�todo ProfileTime. </dd>
 <dt><a href="MIOLO.ProfileEnter.php">ProfileEnter($name)
</a></dt>
 <dd>Descri��o do m�todo ProfileEnter. </dd>
 <dt><a href="MIOLO.ProfileExit.php">ProfileExit($name)
</a></dt>
 <dd>Descri��o do m�todo ProfileExit. </dd>
 <dt><a href="MIOLO.ProfileDump.php">ProfileDump()
</a></dt>
 <dd>Descri��o do m�todo ProfileDump. </dd>
 <dt><a href="MIOLO.Uses.php">UsesDump()
</a></dt>
 <dd>Descri��o do m�todo Uses. </dd>
 <dt><a href="MIOLO.UsesDump.php">UsesDump()
</a></dt>
 <dd>Descri��o do m�todo UsesDump. </dd>
 <dt><a href="MIOLO.Dump.php">Dump($var,$info=null)
</a></dt>
 <dd>Descri��o do m�todo Dump. </dd>
 <dt><a href="MIOLO.Trace.php">Trace($msg)
</a></dt>
 <dd>Descri��o do m�todo Trace. </dd>
 <dt><a href="MIOLO.Trace.php">TraceDump()
</a></dt>
 <dd>Descri��o do m�todo Trace. </dd>
 <dt><a href="MIOLO.TraceDump.php">TraceDump()
</a></dt>
 <dd>Descri��o do m�todo TraceDump. </dd>
 <dt><a href="MIOLO.InvokeHandler.php">InvokeHandler($module,$name)
</a></dt>
 <dd>Descri��o do m�todo InvokeHandler. </dd>
 <dt><a href="MIOLO._InvokeHandler.php">_InvokeHandler($module,$name)
</a></dt>
 <dd>Descri��o do m�todo _InvokeHandler. </dd>
</dl>
<p>&nbsp;</p>
<? include 'footer.inc' ?>
</body>
</html>
