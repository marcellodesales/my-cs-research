<?php
echo "
<body onload=init() marginwidth=0 marginheight=0 topmargin=0 leftmargin=0 bgcolor=FFFFFF text=454A53 link=3E6EB6 vlink=3E6EB6 alink=3E6EB6 background=themes/AnalogX/images/back.gif>
<br>";
if ($banners) {
    include("banners.php");
}
echo "<br>
<table border=0 cellpadding=0 cellspacing=0 width=800>
<tr><td width=10>&nbsp; </td>
<td align=right width=150 valign=top>

<table border=0 cellpadding=0 cellspacing=0 width=100%>
<tr><td>
<br><br><br><br><br>
</td></tr><tr>
<td align=left valign=top>
<table border=0 cellspacing=0 cellpadding=0>";

mainblock();
if (isset($cookie[3])) $storynum = $cookie[3]; else $storynum = $storyhome;
adminblock();
loginbox();
userblock();
category();
pollNewest();
bigstory();
oldNews($storynum);
leftblocks();
rightblocks();
ephemblock();
headlines();
searchbox();
online();

echo "
</table></td></tr></table></td>
<td width=10>&nbsp; </td>
<td align=left width=640 valign=top>

<table border=0 cellpadding= 0 cellspacing=0 width=100%>
<tr><td align=center valign=top>

<a href=$nuke_url><img src=themes/AnalogX/images/logo.gif Alt=\"".translate("Welcome to")." $sitename\" border=0></a>
<font size=1 color=373B42><div align=left><br>&nbsp;&nbsp;&nbsp;$slogan<br></div></font></td></tr>
<tr>
<td valign=top align=left>
<font color=373B42 size=-1><center><br>
&nbsp;<br><br></center></font>
";
?>