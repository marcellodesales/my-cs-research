<?
/***********************************************************/
/* Importa Arquivo ISO para interc�mbio de acervos         */
/* Linguagem PHP                                           */
/* Autor: Pablo Dall'Oglio e Jo�o Alex Fritsch             */
/* �ltima atera��o em 17 Agosto 2001 por Pablo             */
/***********************************************************/

include_once '../gtk/util/GnutecaDialog.class';
include_once '../gtk/util/GnutecaGrid.class';
include_once 'EntryBox.php';
include_once '../../../miolo/miolo.conf';
include_once '../../../miolo/miolo.class';
include_once '../db/GnutecaMIOLO.class';

function LogError($mensagem, $ArquivoISOaImportar, $registro)
{
  $logFileError = fopen("$ArquivoISOaImportar.log", "a"); // arquivo para controle de erros
  echo("$mensagem \n");
  fwrite($logFileError, "$mensagem \n $registro \n");
  fclose($logFileError);
}

function CheckDelimitador($aprocurar, $delimiter)
{
  $fl_possui=false;
  for ($n=0; $n<strlen($aprocurar); $n++)
    if (substr($aprocurar,$n, 1) == $delimiter)
      $fl_possui=true;

  return $fl_possui;
}

function TrataRegistro($registro, $delimitadorDeCampo, $delimitadorDeSubCampo, $ArquivoISOaImportar)
{
  global $BusinessMaterial;

  $tamanhoFisicoDoRegistro  = strlen($registro);
  $tamanhoLogicoDoRegistro  = substr($registro,0,5);
  $numeroDeIndicadores      = substr($registro,10,1);
  $tamanhoDoTamanho         = substr($registro,20,1);
  $tamanhoDaPosicaoInicial  = substr($registro,21,1);

  $lider = substr($registro,0,24);
  $n = 24;
  $i = 1;

  while (substr($registro,$n,1) != $delimitadorDeCampo)
  {
     $codigoDaEtiqueta  = substr($registro,$n, 3); $n +=3;
     $tamanhoDaEtiqueta = substr($registro,$n, $tamanhoDoTamanho); $n += $tamanhoDoTamanho;
     $posicaoDaEtiqueta = substr($registro,$n, $tamanhoDaPosicaoInicial); $n += $tamanhoDaPosicaoInicial;

     $etiqueta["$codigoDaEtiqueta-$i"][1] = $posicaoDaEtiqueta; // Posicao Relativa
     $etiqueta["$codigoDaEtiqueta-$i"][2] = $tamanhoDaEtiqueta; // Tamanho do Campo
     if ($codigoDaEtiqueta == '010')
       $GuardarEtiqueta = $i;

     $i ++;
  }

  $i = $GuardarEtiqueta;
  echo "aqui \n";
  if (($etiqueta["010-$i"]==null))  // N�o possui n�meroDaObra
  { LogError("Registro inconsistente: lider= $lider (Sem Obra)", $ArquivoISOaImportar, $registro ); }

  else if ($tamanhoFisicoDoRegistro != $tamanhoLogicoDoRegistro)
  { LogError("Registro inconsistente: lider= $lider (Tamanhos incompat�veis)", $ArquivoISOaImportar, $registro); }

  else
  {
    $numeroDaObra = substr($registro, $etiqueta["010-$i"][1] + $n +1, $etiqueta["010-$i"][2] -1);
    echo "010-$i\n";

    echo("Importando N� Obra: " . $numeroDaObra . " ... \n");
    $n++;

    $NovoMaterial = new GnutecaMaterial();
    $NovoMaterial->NumeroDaObra = $numeroDaObra;
    $NovoMaterial->Etiqueta     = '000';
    $NovoMaterial->Indicador1   = ' ';
    $NovoMaterial->Indicador2   = ' ';
    $NovoMaterial->Subcampo     = 'a';
    $NovoMaterial->Conteudo     = $lider;

    $BusinessMaterial->NovoMaterial($NovoMaterial);

    foreach ($etiqueta as $PreCodigoDaEtiqueta=>$CadaEtiqueta)
    {
      $codigoDaEtiqueta = substr($PreCodigoDaEtiqueta,0,3);
      $sufixoDaEtiqueta = substr($PreCodigoDaEtiqueta,4);

      $conteudo = substr($registro, $CadaEtiqueta[1] + $n, $CadaEtiqueta[2] -1);
      TrataCampo($numeroDaObra, $codigoDaEtiqueta, $conteudo, $delimitadorDeSubCampo, $numeroDeIndicadores, $sufixoDaEtiqueta);
    }
  }
}

function TrataCampo($numeroDaObra, $codigoDaEtiqueta, $conteudo, $delimitadorDeSubCampo, $numeroDeIndicadores, $sufixoDaEtiqueta)
{
  global $BusinessMaterial;
  $i = 0;

  $indicador1 = ($numeroDeIndicadores==2) ? substr($conteudo,0,1) : ' ';
  $indicador2 = ($numeroDeIndicadores==2) ? substr($conteudo,1,1) : ' ';
  $conteudo = substr($conteudo, $numeroDeIndicadores);

  if (substr($conteudo,0,1)!=$delimitadorDeSubCampo)
    $conteudo = $delimitadorDeSubCampo . 'a' . $conteudo; // Corrigidos Registros Sem in�cio SubCampo

  for($n=0; $n<=strlen($conteudo); $n++)
  {
    $letrinha = substr($conteudo,$n,1);

    if ($letrinha==$delimitadorDeSubCampo)
    {  $i ++; $subcampo[$i] =""; }
    else
    {  $subcampos[$i] .= $letrinha; }
  }

  foreach($subcampos as $subcampo)
  {

    $codigoDoSubCampo   = substr($subcampo,0,1);
    $conteudoDoSubCampo = substr($subcampo,1);

    $NovoMaterial = new GnutecaMaterial();
    $NovoMaterial->NumeroDaObra = $numeroDaObra;
    $NovoMaterial->Linha        = $sufixoDaEtiqueta;
    $NovoMaterial->Etiqueta     = $codigoDaEtiqueta;
    $NovoMaterial->Indicador1   = $indicador1;
    $NovoMaterial->Indicador2   = $indicador2;
    $NovoMaterial->Subcampo     = $codigoDoSubCampo;
    $NovoMaterial->Conteudo     = $conteudoDoSubCampo;
    $BusinessMaterial->NovoMaterial($NovoMaterial);
  }
}

function Importa()
{
  global $ArquivoISOaImportar, $DelimitadorDeRegistro,
         $DelimitadorDeCampo, $DelimitadorDeSubCampo;

  $delimitadorDeRegistro = chr(trim($DelimitadorDeRegistro->get_text()));
  $delimitadorDeCampo = chr(trim($DelimitadorDeCampo->get_text()));
  $delimitadorDeSubCampo = chr(trim($DelimitadorDeSubCampo->get_text()));

  $filename = $ArquivoISOaImportar->get_text();

  $fd = @fopen ("$filename", "r");
  if ($fd)
  {
    while (!feof ($fd))
    {
      $buffer='';
      $buffer = fgets($fd, 80);

      $buffer = ereg_replace("\n", '', $buffer);
      $buffer = ereg_replace(chr(13), '', $buffer);
      $registro .= $buffer;

      if (CheckDelimitador($buffer, $delimitadorDeRegistro))
      {
        TrataRegistro($registro, $delimitadorDeCampo, $delimitadorDeSubCampo, $filename);
        $registro = '';
      }
    }
    fclose ($fd);
  }

  Gtk::main_quit();
}


function FechaJanela()
{
  Gtk::main_quit();
}

if (strtoupper(substr(PHP_OS, 0, 3)) == 'WIN')
  dl('php_gtk.dll');
else
  dl('php_gtk.so');

$MIOLO  = new GnutecaMIOLO('/usr/local/bis');
$MIOLO->Authenticate('postgres', 'postgres');

$BusinessMaterial = $MIOLO->GetBusiness('gnuteca', 'Material');

$window = &new GtkWindow;
$window->connect('delete-event', 'FechaJanela');
$window->set_title('Prepara��o de Ambiente - Importa��o');
$window->set_border_width(0);
$window->set_default_size(480, 100);
$window->set_uposition(80, 80);

$vbox = &new GtkVBox();
$window->add($vbox);
$vbox->show();

    $hbox = &new GtkHBox();
    $vbox->add($hbox);
    $hbox->show();
    $window->realize();

      $ArquivoISOaImportar  = &new GtkEntry();
      $hbox->pack_start(CreateEntryBox($ArquivoISOaImportar, 20, true, 'Arquivo', 2, 15, 20, GTK_BUTTONBOX_SPREAD), true, false, 10);

      $DelimitadorDeRegistro  = &new GtkEntry();
      $hbox->pack_start(CreateEntryBox($DelimitadorDeRegistro, 10, true, 'Delimitador Registro', 2, 15, 20, GTK_BUTTONBOX_SPREAD), true, false, 10);

    $hbox = &new GtkHBox();
    $vbox->add($hbox);
    $hbox->show();
    $window->realize();

      $DelimitadorDeCampo  = &new GtkEntry();
      $hbox->pack_start(CreateEntryBox($DelimitadorDeCampo, 10, true, 'Delimitador Campo', 2, 15, 20, GTK_BUTTONBOX_SPREAD), true, false, 10);

      $DelimitadorDeSubCampo  = &new GtkEntry();
      $hbox->pack_start(CreateEntryBox($DelimitadorDeSubCampo, 10, true, 'Delimitador SubCampo', 2, 15, 20, GTK_BUTTONBOX_SPREAD), true, false, 10);

    $hbox = &new GtkHBox();
    $vbox->add($hbox);
    $hbox->show();
    $window->realize();

      $button = &new GtkButton('Importa');
      $button->connect('clicked', 'Importa', $ctree);
      $hbox->pack_start($button);
      $button->show();


$window->show();

Gtk::main();
?>
