# Metal-Theme-Fixed
# 2000-10-25
#
# This version fixed the displaying of contributed news
# The only change is in the theme.php where it is noted
