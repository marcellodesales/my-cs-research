<?php

if ($index == 1) {
    echo "</td><td>&nbsp;&nbsp;</td><td valign=\"top\" bgcolor=000000>";
    category();
    pollNewest();
    bigstory();
    loginbox();
    userblock();
    oldNews($storynum);
    rightblocks();
    echo "</td>";
}
echo "</td></tr></table></td></tr></table>";
footmsg();
?>
