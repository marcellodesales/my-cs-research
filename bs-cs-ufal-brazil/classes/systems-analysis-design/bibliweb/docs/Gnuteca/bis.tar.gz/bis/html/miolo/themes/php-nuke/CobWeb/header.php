<?php

echo "<body onload=init() bgcolor=\"576F87\" text=\"#295A8A\" link=\"#295A8A\" vlink=\"#295A8A\">\n";
echo "<br>";
if ($banners) {
    include("banners.php");
}
echo "<br><center>\n";
echo "<table border=0 width=100% cellpadding=3 cellspacing=0><tr><td>\n";
echo "<a href=$nuke_url><img src=themes/CobWeb/logo.gif Alt=\"".translate("Welcome to")." $sitename\" border=0></a>\n";
echo "</td></tr></table>\n";
echo "<br><br>\n";
echo "<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tr><td valign=top width=140>\n";

mainblock();
adminblock();
leftblocks();
ephemblock();
headlines();
online();

echo "</td><td>&nbsp;</td><td valign=top width=100%>";

?>