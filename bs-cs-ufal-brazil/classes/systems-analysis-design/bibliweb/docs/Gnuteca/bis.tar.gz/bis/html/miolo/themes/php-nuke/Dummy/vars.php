<?
  // Toggles
  $show_poll = 0;  	          // toggles the poll on/off
  $show_slogan_bar = 0;       // toggles the slogan-bar

  // some paths
  $theme_path = "themes/Dummy/";
  $image_path = $theme_path . "images/";

  // the window corners
  $corner_top_left     = $image_path . "corner_top_left.jpg";
  $corner_top_right    = $image_path . "corner_top_right.jpg";
  $corner_bottom_left  = $image_path . "corner_bottom_left.jpg";
  $corner_bottom_right = $image_path . "corner_bottom_right.jpg";

  // the window edges
  $bar_left    = $image_path . "bar_left.jpg";
  $bar_right   = $image_path . "bar_right.jpg";
  $bar_top     = $image_path . "bar_top.jpg";
  $bar_bottom  =$image_path . "bar_bottom.jpg";
  
  // some background images
  $background1 = $image_path . "background1.jpg";
  $background2 = $image_path . "background2.jpg";
  $background3 = $image_path . "background3.jpg";

  // images
  $logo = $image_path . "howard-logo.jpg";
  $logo2= $image_path . "howard_face.jpg";
  $display_shadow = 0;     // 1 for yes, 0 for no
  $shadow = $image_path . "shadow.jpg";
  
  // Use IE style for nice borders
  $ie_style = 0;
  $style_type = 'groove';
  $style_height = 11;
  
  // font sizes
  $fontsize1 = 3;
  $fontsize2 = 2;
  $fontsize3 = 1;
  
  // change textcolor for lighter or darker backgrounds
  $textcolor1 = "000000";  
  $textcolor2 = "000000";  
  
  // the width of the menu and left boxes
  $themesidebox_width = "180";
  
  // other physical measurements
  $c_width  = 15;  // window corner width
  $c_height = 15;  // window corner height
  $l_width  = 15;  // left edge width
  $r_width  = 15;  // right edge width
  $t_height = 15;  // top bar height
  $b_height = 15;  // bottom bar height
?>