<html>
<head>
 <title> MIOLO - theme:GenerateElements</title>
 <link rel="stylesheet" href="/miolo/doc/doc.css">
</head>
<body>
<? include '/usr/local/bis/html//miolo/doc/header.inc' ?>
<h3 align="right">Classe: <a href="/miolo/doc/miolo/ui/theme.class.php">Theme</a></h3>
<h2>GenerateElements($elements)</h2>
<p>TODO: Escrever documenta��o da fun��o GenerateElements.</p>
<h3>Par�metros:</h3>
<dl>
 <dt>$elements</dt>
 <dd>Descri��o par�metro $elements.</dd>
</dl>
<p>&nbsp;</p>
<pre>
<?php
highlight_string(
'<?php
    ...
    $theme->GenerateElements($elements); 
    ...
?>');
?>
</pre>
<? include '/usr/local/bis/html//miolo/doc/footer.inc' ?>
</body>
</html>
