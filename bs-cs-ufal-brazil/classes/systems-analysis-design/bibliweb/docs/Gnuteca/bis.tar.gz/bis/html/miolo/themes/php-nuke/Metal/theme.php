<?php
$thename = "Metal";
$bgcolor1 = "silver";
$bgcolor2 = "white";
$bgcolor3 = "#FFFFFF"; //white
$textcolor1 = "#000000";  //black
$textcolor2 = "silver";
$hr = 1; # 1 to have horizonal rule in comments instead of table bgcolor

function themeindex ($aid, $informant, $time, $title, $counter, $topic, $thetext, $notes, $morelink, $topicname, $topicimage, $topictext) {
	global $tipath, $anonymous;
	if ("$aid" == "$informant")
	 {
 ?>
<!-- Regular Story HTML posted by ADMIN-->
<table border=0 cellpadding=0 cellspacing=0 width=100% background="themes/Metal/steel3.jpg">
<tr>
<td background="themes/Metal/tbar1.gif" height="17"><img src="themes/Metal/tleft1.gif" width="17" height="17" alt=" "></td>
<td background="themes/Metal/tbar1.gif" width="99%">
<FONT SIZE="2"><B><?php echo"$title"; ?></B></FONT></td>
<td><img src="themes/Metal/tright1.gif" width="17" height="17" alt=" "></td>
</tr>
<tr>
<td background="themes/Metal/leftbar1.gif" align="left">&nbsp;</td>
<td width="100%" align="left" valign="top" background="themes/Metal/steel3.jpg">
<font size=1><?php echo translate("Posted by "); ?><b><?php formatAidHeader($aid) ?></b> <?php echo translate("on"); ?> <?php echo"$time $timezone"; ?> (<?php echo $counter; ?> <?php echo translate("reads"); ?>)</font><br><br></td>
<td background="themes/Metal/rightbar1.gif">&nbsp;</td>
</tr>
<tr bgcolor="#ffffff">
	<td background="themes/Metal/leftbar1.gif" align="left">&nbsp;</td>
	<td width=100% valign="top" background="themes/Metal/steel3.jpg">

<FONT SIZE="1">
<a href="search.php?query=&topic=<?php echo"$topic"; ?>&author="><img src=<?php echo"$tipath$topicimage"; ?> border=1 Alt=<?php echo"\"$topictext\""; ?> align=right hspace=10 vspace=10></a>
<?php echo"<font size=2>$thetext<br>"; ?>
			</FONT>
</td>
<td background="themes/Metal/rightbar1.gif">&nbsp;</td>
</tr>
<tr>
<td background="themes/Metal/leftbar1.gif" height="17">&nbsp;</td>
<td width="99%" align="left" background="themes/Metal/steel3.jpg">
<FONT SIZE="2"><B><?php echo "$morelink"; ?></B></FONT></td>
<td background="themes/Metal/rightbar1.gif">&nbsp;</td>
</tr>
<TR>
<TD background="themes/Metal/bbar1.gif" valign="top" height="17"><IMG src="themes/Metal/bleft1.gif" width="17" height="17" alt=" "></TD>
<td align="center" valign="top" background="themes/Metal/bbar1.gif">&nbsp;</td>
<TD background="themes/Metal/bbar1.gif" valign="top"><IMG src="themes/Metal/bright1.gif" width="17" height="17" alt=" "></TD>
</TR>
</table><br>
<?php	} else {
		if($informant != "") $boxstuff = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
		else $boxstuff = "$anonymous ";
		$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes";
?>
<table border=0 cellpadding=0 cellspacing=0 align=center bgcolor=white width=100%>
<tr><td>

<!-- Story HTML posted by USER-->
<table border=0 cellpadding=0 cellspacing=0 width=100% background="themes/Metal/steel3.jpg">
<tr>
<td background="themes/Metal/tbar1.gif" height="17"><img src="themes/Metal/tleft1.gif" width="17" height="17" alt=" "></td>
<td background="themes/Metal/tbar1.gif" width="99%">
<FONT SIZE="2"><B><?php echo"$title"; ?></B></FONT></td>
<td><img src="themes/Metal/tright1.gif" width="17" height="17" alt=" "></td>
</tr>
<tr>
<td background="themes/Metal/leftbar1.gif" align="left">&nbsp;</td>
<td width="100%" align="left" valign="top" background="themes/Metal/steel3.jpg">
<font size=1><?php echo translate("Posted by "); ?><?php formatAidHeader($aid); ?> <?php echo translate("on"); ?> <?php echo"$time $timezone"; ?> (<?php echo $counter; ?> <?php echo translate("reads"); ?>)<br><br>
</font></td>
<td background="themes/Metal/rightbar1.gif">&nbsp;</td>
</tr>
<tr bgcolor="#ffffff">
	<td background="themes/Metal/leftbar1.gif" align="left">&nbsp;</td>
	<td width=100% valign="top" background="themes/Metal/steel3.jpg">
			<FONT SIZE=1>
			<a href="search.php?query=&topic=<?php echo"$topic"; ?>&author="><img src=<?php echo"$tipath$topicimage"; ?> border=1 Alt=<?php echo"\"$topictext\""; ?> align=right hspace=10 vspace=10></a>
<?php echo"$boxstuff<br><br>"; ?>
			</FONT>
</td>
<td background="themes/Metal/rightbar1.gif">&nbsp;</td>
</tr>
<tr>
<td background="themes/Metal/leftbar1.gif" height="17">&nbsp;</td>
<td width="99%" align="left" background="themes/Metal/steel3.jpg">
<FONT SIZE="2"><B><?php echo "$morelink"; ?></B></FONT></td>
<td background="themes/Metal/rightbar1.gif">&nbsp;</td>
</tr>
<TR>
<TD background="themes/Metal/bbar1.gif" valign="top"><IMG src="themes/Metal/bleft1.gif" width="17" height="17" alt=" "></TD>
<td align="center" valign="top" background="themes/Metal/bbar1.gif">&nbsp;</td>
<TD background="themes/Metal/bbar1.gif" valign="top"><IMG src="themes/Metal/bright1.gif" width="17" height="17" alt=" "></TD>
</TR>
</table></table><br>

<?php	}
}

function themearticle ($aid, $informant, $datetime, $title, $thetext, $topic, $topicname, $topicimage, $topictext) {
	global $admin, $sid, $tipath;
	if ("$aid" == "$informant") {
echo" 
<table border=0 cellpadding=0 cellspacing=0 width=100% background=themes/Metal/steel3.jpg>
	<tr>
		<td background=themes/Metal/tbar1.gif height=17><img src=themes/Metal/tleft1.gif width=17 height=17></td>
		<td background=themes/Metal/tbar1.gif width=99%>
<FONT SIZE=2><b>$title</b>
</FONT></td>
		<td><img src=themes/Metal/tright1.gif width=17 height=17></td>
	</tr>
	<tr>
		<td background=themes/Metal/leftbar1.gif align=left>&nbsp;</td>
		<td width=100% align=left valign=top background=themes/Metal/steel3.jpg>
<font size=1>".translate("Posted on ")."
$datetime";
if ($admin) {
    echo "&nbsp;&nbsp; $font2 [ <a href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]<br><br>";
}
echo "
	<a href=search.php?query=&topic=$topic&author=><img src=$tipath$topicimage border=1 Alt=\"$topictext\" align=right hspace=10 vspace=10></a>
$thetext		
</td>
<td background=themes/Metal/rightbar1.gif>&nbsp;</td>
</tr>
<TR>
<TD background=themes/Metal/bbar1.gif valign=top><IMG src=themes/Metal/bleft1.gif width=17 height=17></TD>
<td align=center valign=top background=themes/Metal/bbar1.gif>&nbsp;</td>
<TD background=themes/Metal/bbar1.gif valign=top><IMG src=themes/Metal/bright1.gif width=17 height=17></TD>
</TR>
</table></table>
";

	} else {
		if($informant != "") $informant = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
		else $boxstuff = "$anonymous ";
		$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes";
echo "

<table border=0 cellpadding=0 cellspacing=0 width=100% background=themes/Metal/steel3.jpg>
	<tr>
		<td background=themes/Metal/tbar1.gif height=17><img src=themes/Metal/tleft1.gif width=17 height=17></td>
		<td background=themes/Metal/tbar1.gif width=99%>
<FONT SIZE=2><b>$title</b>
</FONT></td>
		<td><img src=themes/Metal/tright1.gif width=17 height=17></td>
	</tr>
	<tr>
		<td background=themes/Metal/leftbar1.gif align=left>&nbsp;</td>
		<td width=100% align=left valign=top background=themes/Metal/steel3.jpg>
<font size=1>".translate("Contributed by ")." $informant ".translate("on")." $datetime</font>
";
if ($admin) {
    echo "&nbsp;&nbsp; $font2 [ <a href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]";
}
echo "
	<!-- THIS PORTION DOESN'T BELONG HERE --		
			</FONT>
		</td><td align=right valign=top><img src=themes/Summer/rtb.gif width=13 height=16></td>
	</tr>
	<tr bgcolor=white></tr><tr bgcolor=white>
		<td width=100% valign=top> 
	---- ---- ---- ---- ---- ---- ---- ---->

			<FONT SIZE=1>
			
	<a href=search.php?query=&topic=$topic&author=><img src=$tipath$topicimage
border=0 Alt=\"$topictext\" align=right hspace=10 vspace=10></a><hr>
$thetext
			
</td>
<td background=themes/Metal/rightbar1.gif>&nbsp;</td>
</tr>
<TR>
<TD background=themes/Metal/bbar1.gif valign=top><IMG src=themes/Metal/bleft1.gif width=17 height=17></TD>
<td align=center valign=top background=themes/Metal/bbar1.gif>&nbsp;</td>
<TD background=themes/Metal/bbar1.gif valign=top><IMG src=themes/Metal/bright1.gif width=17 height=17></TD>
</TR>
</table></table>
</td>
";


	}
}


function themesidebox($title, $content) {
    echo "
    <table border=0 cellpadding=0 cellspacing=0 width=100% background=themes/Metal/steel3.jpg>
    <tr>
    <td background=themes/Metal/tbar1.gif height=17><img src=themes/Metal/tleft1.gif width=17 height=17></td>
    <td background=themes/Metal/tbar1.gif align=center width=99%>
    <FONT SIZE=2 FACE=Verdana, Arial><B>$title</B></FONT></td>
    <td><img src=themes/Metal/tright1.gif width=17 height=17 alt= ></td>
    </tr>
    <tr bgcolor=#ffffff>
	<td background=themes/Metal/leftbar1.gif align=left>&nbsp;</td>
	<td width=100% valign=top background=themes/Metal/steel3.jpg>
	<FONT SIZE=1 face=Verdana, Arial>
	$content
	</FONT>
	</td>
    <td background=themes/Metal/rightbar1.gif>&nbsp;</td>
    </tr>
<TR>
    <TD background=themes/Metal/bbar1.gif valign=top><IMG src=themes/Metal/bleft1.gif width=17 height=17></TD>
    <TD background=themes/Metal/bbar1.gif valign=top align=center>&nbsp;</TD>
    <TD background=themes/Metal/bbar1.gif valign=top><IMG src=themes/Metal/bright1.gif width=17 height=17></TD>
    </TR>
    </table><br>";
}

?>
