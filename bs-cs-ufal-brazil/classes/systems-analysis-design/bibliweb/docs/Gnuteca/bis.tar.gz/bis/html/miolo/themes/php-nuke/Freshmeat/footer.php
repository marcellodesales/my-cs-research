<?php
global $admin;
if ($index == 1) {

    echo "<td>&nbsp;</td><td valign=\"top\" width=150>";
    category();
    pollNewest();
    adminblock();
    bigstory();
    loginbox();
    userblock();
    oldNews($storynum);
    leftblocks();
    rightblocks();
    ephemblock();
    headlines();
    online();
}
echo "</td></tr></table></td></tr></table>";
echo "
<TABLE border=0 cellPadding=0 cellSpacing=0 width=100%>
 <TBODY>
  <TR bgColor=#000000>
   <TD><IMG alt=\"\" height=2 src=themes/Freshmeat/1x1.gif width=1></TD>
  </TR>
 </TBODY>
</TABLE>";
footmsg();
?>