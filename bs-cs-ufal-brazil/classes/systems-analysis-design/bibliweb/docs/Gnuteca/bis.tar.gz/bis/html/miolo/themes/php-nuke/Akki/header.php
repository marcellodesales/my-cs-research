<?php

echo "<body onload=init() bgcolor=#000000 text=#000000 link=#000080 alink=#FF0000 vlink=#000080 topmargin=2 marginheight=2>
<link rel=stylesheet href=themes/Akki/style.css>
<br>";
if ($banners) {
    include("banners.php");
}
echo "<br>
<table border=0 cellpadding=0 cellspacing=0 width=100% align=center><tr><td bgcolor=787878>

<table border=0 cellspacing=0 cellpadding=0 width=100% bgcolor=ffffff><tr><td>

<table border=0 cellspacing=0 cellpadding=0 width=100% bgcolor=000000><tr><td>

<a href=$nuke_url><img src=themes/Akki/images/logo.gif Alt=\"".translate("Welcome to")." $sitename\" border=0></a>
</td><td align=right>
    <form action=search.php method=post><font size=2 color=ffffff>
    ".translate("Search")."
    <input type=text name=query>
    </form>
</tr><tr bgcolor=#787878><td colspan=2 bgcolor=#787878>
<font size=3 color=C0c0c0>$slogan</td>
</td></tr>

</table></td></tr>

</table>
</td></tr><tr><td valign=top width=100% bgcolor=#eeeeee>








<table border=0 cellspacing=0 cellpadding=2 width=100%><tr><td valign=top width=150 bgcolor=#eeeeee>";

mainblock();
adminblock();
leftblocks();
ephemblock();
headlines();
online();

echo "<img src=images/pix.gif border=0 width=150 height=1></td><td>&nbsp;&nbsp;</td><td width=100% valign=top>";
?>