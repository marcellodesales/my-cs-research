#!/bin/sh
php /gt/gtk/Main.php
