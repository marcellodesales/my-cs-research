// +-----------------------------------------------------------------+
// | MIOLO - Miolo Development Team - UNIVATES Centro Universit�rio  |
// +-----------------------------------------------------------------+
// | Copyleft (l) 2001 UNIVATES, Lajeado/RS - Brasil                 |
// +-----------------------------------------------------------------+
// | Licensed under GPL: see COPYING.TXT or FSF at www.fsf.org for   |
// |                     further details                             |
// |                                                                 |
// | Site: http://miolo.codigoaberto.org.br                          |
// | E-mail: vgartner@univates.br                                    |
// |         ts@interact2000.com.br                                  |
// +-----------------------------------------------------------------+
// | Abstract: This file contains the javascript functions           |
// |                                                                 |
// | Created: 2001/08/14 Vilson Cristiano G�rtner [vg]               |
// |                     Thomas Spriestersbach    [ts]               |
// |                                                                 |
// | History: Initial Revision                                       |
// |          2001/12/14 [ts] Added MultiTextField support functions |
// +-----------------------------------------------------------------+

var autoCompleteId;
var autoCompleteInfo;

/**
 *
 */
function ComboBox_onTextChange(label,textField,selectionList)
{
    var text = textField.value;
    
    for ( var i=0; i<selectionList.options.length; i++ )
    {
        if ( selectionList.options[i].value == text )
        {
            selectionList.selectedIndex = i;
            return;
        }
    }
    
    alert("!!! ATEN��O !!!\n\nN�o existe uma op��o correspondente ao valor '" + 
          text + "'\ndo campo '" + label + "'!");
    
    textField.focus();
}
 
/**
 *
 */
function ComboBox_onSelectionChange(label,selectionList,textField)
{
    var index = selectionList.selectedIndex;
    
    if ( index != -1 )
    {
      textField.value = String(selectionList.options[index].value);
    }
} 

/**
 *
 */
function GotoURL(url)
{
  var prefix = 'javascript:';
  
  // alert(url);
  
  if ( url.indexOf(prefix) == 0 )
  {
        eval(url.substring(11) + ';');
  }
  
  else
        window.location = url;
}

/**
 *
 */
function Lookup(url)
{
  window.open('lookup.php?' + url,'lookup',
                  'toolbar=no,width=550,height=350,scrollbars=yes,' +
                      'top=100,left=100,statusbar=yes,resizeable=yes');
}

/**
 *
 */
function AutoComplete(url,fieldId,fieldInfo)
{
  autoCompleteId   = fieldId;
  autoCompleteInfo = fieldInfo;
        
  url = 'autocomplete.php?' + url + '&hint=' + escape(fieldId.value);
  
  top.frames['util'].location = url;
}

/**
 *
 */
function SetResult(info)
{
  // alert(info);
  if ( autoCompleteInfo != null )
    autoCompleteInfo.value = info;
}

/**
 *
 */
function Deliver(id,text)
{
  var lookup_form  = null;
  var lookup_field = null;
  var lookup_text  = null;
  
  url = String(window.location);
  
  // alert(url);
 
  if ( text != null )
  { var pos;
          
        // alert(text);
        
    while ( (pos = text.indexOf('+')) != -1 )
      text = text.substring(0,pos) + ' ' + text.substring(pos+1);
        
        text = unescape(text);
        
        // alert(text);
  }
  
  // separar caminho da url dos par�metros
  var a = url.split('?');
  
  if ( a.length == 2 )
  {
        // separar os par�metros
    var b = a[1].split('&');
        
        for ( i=0; i<b.length; i++ )
        {
          var c = b[i].split('=');
          
          if ( c.length == 2 )
          {
            var name  = c[0];
            var value = c[1];
          
            if ( name == 'lookup_form' )
                  lookup_form = value;
                
            else if ( name == 'lookup_field' )
                  lookup_field = value;
                
            else if ( name == 'lookup_text' )
                  lookup_text = value;
          }
        }
  }
  //echo lookup_form;
  if ( lookup_form != null )
  {
        if ( lookup_field != null )
      eval("window.opener.document." + lookup_form + "." + 
                   lookup_field + ".value='" + id + "'");
                   
        if ( lookup_text != null )         
      eval("window.opener.document." + lookup_form + "." + 
               lookup_text + ".value='" + text + "'");
  }
  
  close();
}

/**
 * vai para a paginal tal de um tabbed form
 */
function _MIOLO_TabbedForm_GotoPage(frmName,pageName)
{
    // alert('_MIOLO_TabbedForm_GotoPage("' + frmName + "','" + pageName + '")');
    var form = eval('document.'+frmName);
   
    if ( form != null )
    {
	form.frm_currpage_.value = pageName;
	form.frm_submit_.value   = 0;
	   
	if ( eval(frmName+'_onSubmit()') )
	{
	    form.submit();
	}
    }
    
    else
    {
        alert('MIOLO INTERNAL ERROR:\n\nForm ' + frmName + ' not found!');
    }
}

/**
 * Fun��o que simplesmente seleciona todos os itens, para que
 * ser�o incluidos ao enviar o formul�rio
 */
function _MIOLO_MultiTextField_onSubmit(frmName,mtfName)
{
    var form = eval('document.'+frmName);
    
    var list = form[mtfName+'[]'];
    
    if ( list != null && list.options != null )
    {
        for ( var i=0; i<list.length; i++ )
        {
            list.options[i].selected = true;
        }
    }
    
    return true;
}

/**
 * Fun��o que intercepta a tecla Enter, para que o conte�do do
 * campo de texto � adicionado a lista.
 */
function _MIOLO_MultiTextField_onKeyDown(source,frmObj,mtfName,event)
{
  // IE and compatibles use 'keyCode', NS and compatibles 'which'
  var key = ( document.all != null ) ? event.keyCode : event.which;
  
  if ( source.name == mtfName + '_text' )
  {
    if ( key == 13 ) // enter key
    {
      _MIOLO_MultiTextField_add(frmObj,mtfName);
      return false;
    }
  }

  else if ( source.name == mtfName + '[]' )
  {
    // alert(key);

    if ( key == 46 ) // delete key
    {
      _MIOLO_MultiTextField_remove(frmObj,mtfName);
      return false;
    }
  }
}

/**
 * Func��o que adiciona o conte�do do campo de texto a lista.
 */
function _MIOLO_MultiTextField_add(frmObj,mtfName)
{
  var list = frmObj[mtfName+'[]'];
  var tf   = frmObj[mtfName+'_text'];
  if ( tf.value != '' )
  {
    var i = list.length;
    list.options[i] = new Option(tf.value);
    for ( var j=0; j<=i; j++ )
      list.options[i].selected = (j==i);
    tf.value = '';
  }
}

/**
 * Func��o que exclui o item atualmente selecionado
 */
function _MIOLO_MultiTextField_remove(frmObj,mtfName)
{
  var list = frmObj[mtfName+'[]'];

  for ( var i=0; i<list.length; i++ )
  {
    if ( list.options[i].selected )
    {
      list.options[i] = null;

      if ( i >= list.length )
        i = list.length - 1;

      if ( i >= 0 )
        list.options[i].selected = true;

      break;
    }
  }
}

var _MIOLO_MultiTextField2_separator = '] [';

/**
 *  
 */
function _MIOLO_MultiTextField2_Split(value)
{
    return value.substring(1,value.length-1).split(_MIOLO_MultiTextField2_separator);
}

/**
 *  
 */
function _MIOLO_MultiTextField2_Join(fields)
{
    var value = '[';
    
    for ( var i=0; i<fields.length; i++ )
    {
        if ( i > 0 )
        {
            value += _MIOLO_MultiTextField2_separator;
        }
        
        value += fields[i];
    }
    
    value += ']';
    
    return value;
}

/**
 *  
 */
function _MIOLO_MultiTextField2_onSubmit(frmName,mtfName)
{
  return _MIOLO_MultiTextField_onSubmit(frmName,mtfName);
}

/**
 *  
 */
function _MIOLO_MultiTextField2_onKeyDown(source,frmObj,mtfName,event,numFields)
{
  // IE and compatibles use 'keyCode', NS and compatibles 'which'
  var key  = ( document.all != null ) ? event.keyCode : event.which;
  var name = mtfName + '_text';
  var len  = name.length;
  
  if ( source.name.substring(0,len) == name )
  {
    if ( key == 13 ) // enter key
    {
      _MIOLO_MultiTextField2_add(frmObj,mtfName,numFields);
      return false;
    }
  }

  else if ( source.name == mtfName + '[]' )
  {
    // alert(key);

    if ( key == 46 ) // delete key
    {
      _MIOLO_MultiTextField2_remove(frmObj,mtfName,numFields);
      return false;
    }
  }
}

/**
 *  
 */
function _MIOLO_MultiTextField2_onSelect(frmObj,mtfName,numFields)
{
    var list  = frmObj[mtfName+'[]'];
    
    var i = list.selectedIndex;
    
    if ( i != -1 )
    {
        var a = _MIOLO_MultiTextField2_Split(list.options[i].text);
        
        for ( var j=1; j<=numFields; j++ )
        {
            var tf = frmObj[mtfName+'_text'+j];
            
            tf.value = a[j-1];
        }
    }
    
    else
    {
        for ( var j=1; j<=numFields; j++ )
        {
            var tf = frmObj[mtfName+'_text'+j];
            
            tf.value = '';
        }
    }
}

/**
 *  
 */
function _MIOLO_MultiTextField2_getInput(frmObj,mtfName,numFields)
{
    var list   = frmObj[mtfName+'[]'];
    var fields = new Array(numFields);
    
    for ( var i=1; i<=numFields; i++ )
    {
        var tf = frmObj[mtfName+'_text'+i];
        
        fields[i-1] = '';
        
        if ( tf != null )
        {
            if ( i > 1 )
            {
                value += _MIOLO_MultiTextField2_separator;
            }
            
            fields[i-1] = tf.value;
            
            tf.value = '';
        }
    }
    
    return _MIOLO_MultiTextField2_Join(fields); 
}

/**
 *  
 */
function _MIOLO_MultiTextField2_add(frmObj,mtfName,numFields)
{
    var list  = frmObj[mtfName+'[]'];
    var i     = list.length;
    
    list.options[i] = new Option(_MIOLO_MultiTextField2_getInput(frmObj,mtfName,numFields));
    
    for ( var j=0; j<=i; j++ )
    {
        list.options[i].selected = (j==i);
    }
}

/**
 * Func��o que exclui o item atualmente selecionado
 */
function _MIOLO_MultiTextField2_remove(frmObj,mtfName,numFields)
{
    _MIOLO_MultiTextField_remove(frmObj,mtfName);	
}

/**
 * 
 */
function _MIOLO_MultiTextField2_modify(frmObj,mtfName,numFields)
{
    var list  = frmObj[mtfName+'[]'];
    
    var i = list.selectedIndex;
    
    if ( i != -1 )
    {
        list.options[i].text = _MIOLO_MultiTextField2_getInput(frmObj,mtfName,numFields);
    }
    
    else
    {
        alert('� preciso selecionar o item a ser modificado!');
    }
}

/**
 * 
 */
function _MIOLO_MultiTextField2_moveUp(frmObj,mtfName,numFields)
{
    var list  = frmObj[mtfName+'[]'];
    
    var i = list.selectedIndex;
    
    if ( i != -1 )
    {
	if ( i > 0 )
	{
	    var u = list.options[i-1].text;
	    
            list.options[i-1].text = list.options[i].text;
	    list.options[i-1].selected = true;
	    
	    list.options[i].text = u;
	    list.options[i].selected = false;
	    
	    list.selectedIndex = i - 1;
	}
    }
    
    else
    {
        alert('� preciso selecionar o item a ser modificado!');
    }
}

/**
 * 
 */
function _MIOLO_MultiTextField2_moveDown(frmObj,mtfName,numFields)
{
    var list  = frmObj[mtfName+'[]'];
    
    var i = list.selectedIndex;
    
    if ( i != -1 )
    {
	if ( i < list.options.length - 1 )
	{
	    var u = list.options[i+1].text;
	    
            list.options[i+1].text = list.options[i].text;
	    list.options[i+1].selected = true;
	    
	    list.options[i].text = u;
	    list.options[i].selected = false;
	    
	    list.selectedIndex = i + 1;
	}
    }
    
    else
    {
        alert('� preciso selecionar o item a ser modificado!');
    }
}

/**
 *
 */
function toggleLayer(name)
{
  if ( document.all != null )
  {
        // alert('document.all');
        
        var theLayer = document.all[name];
        
        if ( theLayer != null )
        {
      if ( theLayer.style.visibility != 'visible' )
                theLayer.style.visibility = 'visible';
          else
                theLayer.style.visibility = 'hidden';
        }
  }
  
  // Netscape e compativeis
  else if ( document.layers != null )
  {
        // alert('document.layers');
        
        var theLayer = document.layers[name];
        
        if ( theLayer != null )
        {
      if ( theLayer.visibility != 'show' )
                theLayer.visibility = 'show';
          else
                theLayer.visibility = 'hidden';
        }
  }
  
  // Konqueror e compativeis
  else if ( document.getElementById != null )
  {
        // alert('getElementById');
        
        var theLayer = document.getElementById(name);
        
    if ( theLayer != null )
        {
      if ( theLayer.style.visibility != 'visible' )
                theLayer.style.visibility = 'visible';
          else
                theLayer.style.visibility = 'hidden';
        }
  }
  
  /*
  else
        alert('Layer ' + name + ' not found!');
  */
}

