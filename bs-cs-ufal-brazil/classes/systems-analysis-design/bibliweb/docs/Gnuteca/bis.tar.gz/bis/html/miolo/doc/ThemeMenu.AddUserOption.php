<html>
<head>
  <title> MIOLO - AddOption </title>
  <link rel="stylesheet" href="doc.css"> 
</head>
<body>
<h3 align="right">Classe: ThemeMenu - Theme.class</h3>
<h2>AddUserOption($access,$label,$module='main',$action='',$item='')</h2>
<p>� utilizado para adicionar um item ao menu, de acordo com as permiss�es do usu�rio. 
Para criar um menu, utiliza-se <a href="CreateMenu.php">CreateMenu</a></p>
<p> O arquivo ???? cont�m a defini��o das constantes mais comuns utilizadas. � poss�vel criar 
outras permiss�es aos usu�rios. Para isso, � necess�rio inserir um registro na tabela cmn_access.</p>
<h3>Par�metros:</h3>  
<dl>
    <dt>$access</dt>
    <dd>Identificador do tipo de acesso requerido. </dd>
    <dt>$label</dt>
    <dd>Texto para exibi��o do link</dd>
    <dt>$module</dt>
    <dd>nome do m�dule</dd>
    <dt>$action</dt>
    <dd>Representa uma lista de nomes dos handlers (/module/nome_modulo/handlers/*.inc) 
        separados por ':' (dois pontos). Esses handlers ser�o executados na seq��ncia em 
        que aparecerem na lista, pela fun��o <a href="InvokeHandler.php">InvokeHandler</a></dd>
</dl>
<p>    
<pre>
<?php
highlight_string(
'<?php
  ...
  $menu = $theme->CreateMenu("Op��es de Cadastros");     
  $menu->AddUserOption(A_INSERIR,"Vestibular", $module, "main:novo");
  ...
?>');
?>
</pre>
</body>
</html>
