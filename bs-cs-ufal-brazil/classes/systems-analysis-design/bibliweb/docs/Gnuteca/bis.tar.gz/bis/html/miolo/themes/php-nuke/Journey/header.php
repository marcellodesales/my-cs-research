<?php

echo "<body onload=init() topmargin=0 leftmargin=0 bgcolor=#000000 text=#000000 link=#808000 vlink=#C0C0C0 alink=#800000 background=themes/Journey/experiment3-null.gif>
<br>";
if ($banners) {
    include("banners.php");
}
echo "<br>
<div align=center><center>

<table border=0 width=95% cellspacing=0 cellpadding=0 bgcolor=#FFFFFF>
  <tr>
    <td width=100%><table border=0 width=100% cellspacing=0 cellpadding=0 background=themes/Journey/top.gif>
      <tr>
        <td width=68% valign=bottom background=themes/Journey/top.gif><img src=themes/Journey/corner1.gif WIDTH=23 HEIGHT=121><a href=index.php><img src=themes/Journey/logo.gif WIDTH=301 HEIGHT=121 border=0></a><img src=themes/Journey/experiment3-null.gif width=55 height=56 align=top><a href=heartandsoul.php onMouseOver=turnOn('image1') onMouseOut=turnOff('image1')><img name=image1 src=themes/Journey/button-hs2.gif alt=\"Heart &amp; Soul\" border=0 WIDTH=60 HEIGHT=83></a><a href=index.php onMouseOver=turnOn('image2') onMouseOut=turnOff('image2')><img name=image2 src=themes/Journey/button-nw2.gif alt=Newsworthy border=0 WIDTH=60 HEIGHT=83></a><a href=journeylinks.php onMouseOver=turnOn('image3') onMouseOut=turnOff('image3')><img name=image3 src=themes/Journey/button-dc2.gif alt=Discover border=0 WIDTH=60 HEIGHT=83></a></td>
        <td width=32% valign=top background=themes/Journey/top.gif><p align=right><img src=themes/Journey/corner2.gif WIDTH=23 HEIGHT=121></td>
      </tr>
    </td>
  </tr>
</table>
    
    
<table border=0 width=100% cellspacing=0 cellpadding=0>
  <tr>
    <td width=100%><br>

<table border=0 cellpadding=4 cellspacing=0 width=98% align=center>
<tr><td>
</td></tr><tr><td valign=top width=100%>
<table border=0 cellspacing=0 cellpadding=2 width=100%>
<tr><td valign=top width=150>";

mainblock();
if (!$user) {
		$title = "Journey Login";
		$boxstuff .= "<form action=user.php method=post>";
		$boxstuff .= "<font size=1><center>".translate("Nickname")."<br>";
		$boxstuff .= "<input type=text name=uname size=12 maxlength=25><br>";
		$boxstuff .= "".translate("Password")."<br>";
		$boxstuff .= "<input type=password name=pass size=12 maxlength=20><br>";
		$boxstuff .= "<input type=hidden name=op value=login>";
		$boxstuff .= "<input type=submit value=".translate("Login")."></form>";
		$boxstuff .= "".translate("Don't have an account yet? You can")."";
		$boxstuff .= " <a href=user.php>".translate("create one")."</a>.";
		$boxstuff .= " ".translate("As registered")."";
		$boxstuff .= " ".translate("user you have some advantages like theme manager,")."";
		$boxstuff .= " ".translate("comments configuration and post comments with your name.")."";
		$boxstuff .= "</center>";
		themesidebox($title, $boxstuff);
}
global $admin;
if ($admin) { 
    adminblock();
}
leftblocks();
if ($Ephemerids==1) {
    ephemblock();
}
headlines();
online();

echo "<img src=images/pix.gif border=0 width=150 height=1></td><td width=100% valign=top>";
?>