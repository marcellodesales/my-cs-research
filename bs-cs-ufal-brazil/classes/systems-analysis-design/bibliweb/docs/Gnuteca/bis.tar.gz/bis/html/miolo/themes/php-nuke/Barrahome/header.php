<?php
global $admin;
echo "<body onload=init() bgcolor=006699 text=000000 link=000000 vlink=000000 topmargin=0 leftmargin=0 rightmargin=0 marginheight=0>
<br>";
if ($banners) {
    include("banners.php");
}
echo "<br>
<table border=0 cellpadding=4 cellspacing=0 width=100% align=center><tr><td>
<table border=0 cellspacing=0 cellpadding=1 width=100% bgcolor=000000><tr><td>
<table border=0 cellspacing=0 cellpadding=3 width=100% bgcolor=000000><tr><td>
<a href=$nuke_url><img src=themes/Barrahome/logo.gif Alt=\"".translate("Welcome to")." $sitename\" border=0></a>
</td><td align=right>
    <form action=search.php method=post><font size=3 color=FFFFFF>
    ".translate("Search")."
    <input type=text name=query>
    </form>
</tr><tr bgcolor=006699><td colspan=2 bgcolor=006699>
<font size=3 color=8B8B64>$slogan</td>
</td></tr></table></td></tr></table></td></tr><tr><td valign=top width=100%>
<table border=0 cellspacing=0 cellpadding=2 width=100%><tr><td valign=top width=150>";

mainblock();
adminblock();
leftblocks();
ephemblock();
headlines();
online();

echo "<img bcolor=006699 border=0 width=150 height=1></td><td width=100% valign=top>";
?>