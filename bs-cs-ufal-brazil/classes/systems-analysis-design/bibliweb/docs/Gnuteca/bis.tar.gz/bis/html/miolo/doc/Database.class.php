<html>
<head>
 <title> MIOLO - Classe Database</title>
 <link rel="stylesheet" href="doc.css">
</head>
<body>
<? include 'header.inc' ?>
<h2>Classe Database</h2>
<blockquote>
extends <a href="#.class.php">SuperClasse</a>
</blockquote>
<p>TODO: Escrever documenta��o da classe Database.</p>
<h3>M�todos:</h3>
<dl>
 <dt><a href="Database.Database.php">Database($host,$db,$user,$pass)
</a></dt>
 <dd>Descri��o do m�todo Database. </dd>
 <dt><a href="Database.Close.php">Close()
</a></dt>
 <dd>Descri��o do m�todo Close. </dd>
 <dt><a href="Database.GetErrors.php">GetErrors()
</a></dt>
 <dd>Descri��o do m�todo GetErrors. </dd>
 <dt><a href="Database.Execute.php">Execute($sql)
</a></dt>
 <dd>Descri��o do m�todo Execute. </dd>
 <dt><a href="Database.Execute.php">ExecuteBatch($sql_array)
</a></dt>
 <dd>Descri��o do m�todo Execute. </dd>
 <dt><a href="Database.ExecuteBatch.php">ExecuteBatch($sql_array)
</a></dt>
 <dd>Descri��o do m�todo ExecuteBatch. </dd>
 <dt><a href="Database.Query.php">Query($sql,$maxrows=0)
</a></dt>
 <dd>Descri��o do m�todo Query. </dd>
 <dt><a href="Database.Query.php">QueryChunk($sql, $maxrows, $offset, &$total)
</a></dt>
 <dd>Descri��o do m�todo Query. </dd>
 <dt><a href="Database.QueryChunk.php">QueryChunk($sql, $maxrows, $offset, &$total)
</a></dt>
 <dd>Descri��o do m�todo QueryChunk. </dd>
</dl>
<p>&nbsp;</p>
<? include 'footer.inc' ?>
</body>
</html>
