<?php

$TablebgColor_A = "#006699";
$TablebgColor_B = "#FFFFFF";
$LinksTableRowColor = "#FFFFFF";
$thename = "Kuro5hin";
$bgcolor1 = "#FFFFFF";
$bgcolor2 = "#006699";
$bgcolor3 = "#FFFFFF";
$bgcolor4 = "#006699";
$textcolor1 = "#FFFFFF";
$textcolor2 = "#000000";
$hr = 0; # 1 to have horizonal rule in comments instead of table bgcolor


function themeindex($aid, $informant, $datetime, $title, $counter, $topic, $thetext, $notes, $morelink, $topicname, $topicimage, $topictext) {
	global $tipath, $anonymous;
	if ("$aid" == "$informant") { ?>
		<p>
		<table width="100%" cellpadding=1 cellspacing=0 border=0 bgcolor=006699>
		<tbody>
		<tr>
		<td valign=top>
		 <table width="100%" cellpadding=1 cellspacing=0 border=0 bgcolor=006699>
		  <tbody>
		  <tr>
		   <td bgcolor=eeeeee><font size=4 color="#000000"><b>
		    <?php echo"$title"; ?></b></font>
		    <font color=#333333> (<a class=s_menu href="search.php?query=&topic=<?php echo"$topic"; ?>&author=">
		    <?php echo $topictext; ?></a>)</font><br>
		    <?php echo translate ("Posted by "); ?> <?php formatAidHeader($aid) ?> <?php echo translate("on"); ?> 
		    <?php echo"$datetime $timezone"; ?> - (<?php echo $counter; ?> <?php echo translate("reads"); ?>)</font><br>
		   </td>
		  </tr>
		  </tbody>
		 </table>
		</td>
		</tr>
		</tbody>
		</table>
		<a class=s_menu href="search.php?query=&topic=<?php echo"$topic"; ?>&author="><img src=<?php echo"$tipath$topicimage"; ?> border=0 Alt=<?php echo"\"$topictext\""; ?> align=right hspace=10 vspace=10 border=0></a>
		<br><?php echo"$thetext<br><br>$morelink"; ?><p>

<?php	} else {
		if($informant != "") $boxstuff = "<a class=s_menu href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
		else $boxstuff = "$anonymous ";
		$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes"; ?>
		<p>
		<table width="100%" cellpadding=1 cellspacing=0 border=0 bgcolor=006699>
		<tbody>
		<tr>
		<td valign=top>
		 <table width="100%" cellpadding=1 cellspacing=0 border=0 bgcolor=006699>
		  <tbody>
		  <tr>
		   <td bgcolor=eeeeee><font size=4 color="#000000"><b>
		    <?php echo"$title"; ?></b><font color=#333333>(<a class=s_menu href="search.php?query=&topic=<?php echo"$topic"; ?>&author=">
		    <?php echo $topictext; ?></a>)</font></font><br>
		    <?php echo translate ("Posted by "); ?> <?php formatAidHeader($aid) ?> <?php echo translate("on"); ?> 
		    <?php echo"$datetime $timezone"; ?> - (<?php echo $counter; ?> <?php echo translate("reads"); ?>)</font><br>
		   </td>
		  </tr>
		  </tbody>
		 </table>
		</td>
		</tr>
		</tbody>
		</table>
		<font color=000000>
		<a class=s_menu href="search.php?query=&topic=<?php echo"$topic"; ?>&author="><img src=<?php echo"$tipath$topicimage"; ?> border=0 Alt=<?php echo"\"$topictext\""; ?> align=right hspace=10 vspace=10 border=0></a>
		<br><?php echo"$thetext<br><br>$morelink"; ?><p>
<?php	}
}

function themearticle ($aid, $informant, $datetime, $title, $thetext) {
	global $admin, $sid, $tipath;
	if ("$aid" == "$informant") { ?>
		<p>
		<table width="100%" cellpadding=1 cellspacing=0 border=0 bgcolor=006699>
		<tbody>
		<tr>
		<td valign=top>
		 <table width="100%" cellpadding=1 cellspacing=0 border=0 bgcolor=006699>
		  <tbody>
		  <tr>
		   <td bgcolor=eeeeee><font size=4 color="#000000"><b>
		    <?php echo"$title"; ?></b><font color=#333333> (<a class=s_menu href="search.php?query=&topic=<?php echo"$topic"; ?>&author=">
		    <?php echo $topictext; ?></a>)</font></font><br>
		    <?php echo translate ("Posted by "); ?> <?php formatAidHeader($aid) ?> <?php echo translate("on"); ?> 
		    <?php echo"$datetime $timezone"; ?><br>
		   </td>
		  </tr>
		  </tbody>
		 </table>
		</td>
		</tr>
		</tbody>
		</table>
                <?php echo"$thetext"; ?>

<?php	} else {
		if($informant != "") $boxstuff = "<a class=s_menu href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
		else $boxstuff = "$anonymous ";
		$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes";
?>		
		<p>
		<table width="100%" cellpadding=1 cellspacing=0 border=0 bgcolor=006699>
		<tbody>
		<tr>
		<td valign=top>
		 <table width="100%" cellpadding=1 cellspacing=0 border=0 bgcolor=006699>
		  <tbody>
		  <tr>
		   <td bgcolor=eeeeee><font size=4 color="#000000"><b>
		    <?php echo"$title"; ?></b></font>
		    <font color=#333333></font><br>
		    <?PHP echo translate ("Posted by ") ?><?PHP formatAidHeader($aid)  ?><?PHP echo translate("on"); ?><?PHP echo"$datetime $timezone"; ?>
		    <?PHP if ($admin) {
            	    echo "&nbsp;&nbsp; $font2 [ <a class=s_menu href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a class=s_menu href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]";
            	    } ; ?> <br>
		   </td>
		  </tr>
		  </tbody>
		 </table>
		</td>
		</tr>
		</tbody>
		</table>
    		<br><br></font>
                <?php echo"$boxstuff"; ?>

<?php	}
}

function themesidebox($title, $content) {
echo "
<table border=0 cellspacing=0 cellpadding=1 width=200 bgcolor=006699>
<tr><td>
<table width=100% border=0 cellspacing=0 cellpadding=1>
<tr><td colspan=1 bgcolor=eeeeee>
<font color=004a6d size=2>$title</font>
</td></tr></td></tr>
</table>
<tr><td bgcolor=FFFFFF>
<font color=#333333 size=2>$content</font>
</td></tr></table><br>";




}


