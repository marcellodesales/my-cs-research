<?php

$thename = "KDE";
$lnkcolor = "FFFFFF";
$bgcolor1 = "#CCCCCC";
$bgcolor2 = "#666666";
$bgcolor3 = "#CCCCCC";
$textcolor1 = "#FFFFFF";
$textcolor2 = "#000000";
$hr = 1; # 1 to have horizonal rule in comments instead of table bgcolor

function themeindex ($aid, $informant, $time, $title, $counter, $topic, $thetext, $notes, $morelink, $topicname, $topicimage, $topictext) {
	global $tipath, $anonymous;
	if ("$aid" == "$informant") { ?>


<TABLE WIDTH="100%" CELLPADDING=0 CELLSPACING=0 BORDER=0>
    <TR>
    <TD ALIGN=right VALIGN=BOTTOM WIDTH="11" HEIGHT="11"><IMG SRC="themes/KDE/menutopleft.gif" width="11" height="11"></TD>
    <TD ALIGN=MIDDLE HEIGHT="11" VALIGN=BOTTOM><IMG SRC="themes/KDE/menutop.gif" width=100% height=1></TD>
    <TD ALIGN=left VALIGN=BOTTOM WIDTH="11" HEIGHT="11"><IMG SRC="themes/KDE/menutopright.gif" width="11" height="11"></TD></TR>
    <TR>
    <TD ALIGN=right VALIGN=BOTTOM WIDTH="11" HEIGHT="11" BACKGROUND="themes/KDE/menuleft.gif"><IMG SRC="themes/KDE/menutopleft.gif" width="11" height="11"></TD>
    <TD ALIGN=CENTER bgcolor="#6C6C6C" BACKGROUND="themes/KDE/menutitle.gif">
    <FONT size=3 color=white></center><?php echo"$title"; ?><BR><FONT SIZE=2><?php echo translate("Posted by "); ?><b><?php formatAidHeader($aid) ?></b> <?php echo translate("on"); ?> <?php echo"$time $timezone"; ?><br>(<?php echo $counter; ?> <?php echo translate("reads"); ?>)<br></FONT></TD>
    <TD ALIGN=left VALIGN=BOTTOM WIDTH="11" HEIGHT="11" BACKGROUND="themes/KDE/menuright.gif"><IMG SRC="themes/KDE/menutopright.gif" width="11" height="11"></TD></TR>
    <TR>
    <TD ALIGN=RIGHT BACKGROUND="themes/KDE/menuleft.gif" WIDTH="11">&nbsp;</TD>
    <TD ALIGN=left VALIGN=TOP BGCOLOR="#CFCFCF" BACKGROUND="themes/KDE/sketch.gif">
    <FONT size=2>
    <a href="search.php?query=&topic=<?php echo"$topic"; ?>&author="><img src=<?php echo"$tipath$topicimage"; ?> border=1 Alt=<?php echo"\"$topictext\""; ?> align=left hspace=10 vspace=10></a>
    <?php echo"$thetext<br><br>$morelink"; ?></TD>
    <TD ALIGN=LEFT BACKGROUND="themes/KDE/menuright.gif" WIDTH="11">&nbsp;</TD></TR>
    <TR>
    <TD ALIGN=right VALIGN=TOP WIDTH="11" HEIGHT="11"><IMG SRC="themes/KDE/menubottomleft.gif" width="11" height="11"></TD>
    <TD ALIGN=MIDDLE HEIGHT="11" VALIGN=TOP><IMG SRC="themes/KDE/menubottom.gif" width="100%" height=1></TD>
    <TD ALIGN=left VALIGN=TOP WIDTH="11" HEIGHT="11"><IMG SRC="themes/KDE/menubottomright.gif" width="11" height="11">
</TD></TR></TABLE>

<?php	} else {
		if($informant != "") $boxstuff = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
		else $boxstuff = "$anonymous ";
		$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes";
?>
<TABLE WIDTH="100%" CELLPADDING=0 CELLSPACING=0 BORDER=0>
    <TR>
    <TD ALIGN=right VALIGN=BOTTOM WIDTH="11" HEIGHT="11"><IMG SRC="themes/KDE/menutopleft.gif" width="11" height="11"></TD>
    <TD ALIGN=MIDDLE HEIGHT="11" VALIGN=BOTTOM><IMG SRC="themes/KDE/menutop.gif" width=100% height=1></TD>
    <TD ALIGN=left VALIGN=BOTTOM WIDTH="11" HEIGHT="11"><IMG SRC="themes/KDE/menutopright.gif" width="11" height="11"></TD></TR>
    <TR>
    <TD ALIGN=right VALIGN=BOTTOM WIDTH="11" HEIGHT="11" BACKGROUND="themes/KDE/menuleft.gif"><IMG SRC="themes/KDE/menutopleft.gif" width="11" height="11"></TD>
    <TD ALIGN=CENTER bgcolor="#6C6C6C" BACKGROUND="themes/KDE/menutitle.gif">
    <FONT size=3 color=white></center>
    <?php echo"$title"; ?><BR><FONT SIZE=2>
    <?php echo translate("Posted by "); ?><?php formatAidHeader($aid); ?> <?php echo translate("on"); ?> <?php echo"$time $timezone"; ?><br>(<?php echo $counter; ?> <?php echo translate("reads"); ?>)<br></FONT></TD>
    <TD ALIGN=left VALIGN=BOTTOM WIDTH="11" HEIGHT="11" BACKGROUND="themes/KDE/menuright.gif"><IMG SRC="themes/KDE/menutopright.gif" width="11" height="11"></TD></TR>
    <TR>
    <TD ALIGN=RIGHT BACKGROUND="themes/KDE/menuleft.gif" WIDTH="11">&nbsp;</TD>
    <TD ALIGN=left VALIGN=TOP BGCOLOR="#CFCFCF" BACKGROUND="themes/KDE/sketch.gif">
    <FONT size=2>
    <a href="search.php?query=&topic=<?php echo"$topic"; ?>&author="><img src=<?php echo"$tipath$topicimage"; ?> border=1 Alt=<?php echo"\"$topictext\""; ?> align=left hspace=10 vspace=10></a>
    <?php echo"$boxstuff<br><br>$morelink"; ?></TD>
    <TD ALIGN=LEFT BACKGROUND="themes/KDE/menuright.gif" WIDTH="11">&nbsp;</TD></TR>
    <TR>
    <TD ALIGN=right VALIGN=TOP WIDTH="11" HEIGHT="11"><IMG SRC="themes/KDE/menubottomleft.gif" width="11" height="11"></TD>
    <TD ALIGN=MIDDLE HEIGHT="11" VALIGN=TOP><IMG SRC="themes/KDE/menubottom.gif" width="100%" height=1></TD>
    <TD ALIGN=left VALIGN=TOP WIDTH="11" HEIGHT="11"><IMG SRC="themes/KDE/menubottomright.gif" width="11" height="11">
</TD></TR></TABLE>

<?php	}
}

function themearticle ($aid, $informant, $datetime, $title, $thetext, $topic, $topicname, $topicimage, $topictext) {
	global $admin, $sid, $tipath;
	if ("$aid" == "$informant") {
echo "
<TABLE WIDTH=100% CELLPADDING=0 CELLSPACING=0 BORDER=0>
    <TR>
    <TD ALIGN=right VALIGN=BOTTOM WIDTH=11 HEIGHT=11><IMG SRC=themes/KDE/menutopleft.gif width=11 height=11></TD>
    <TD ALIGN=MIDDLE HEIGHT=11 VALIGN=BOTTOM><IMG SRC=themes/KDE/menutop.gif width=100% height=1></TD>
    <TD ALIGN=left VALIGN=BOTTOM WIDTH=11 HEIGHT=11><IMG SRC=themes/KDE/menutopright.gif width=11 height=11></TD></TR>
    <TR>
    <TD ALIGN=right VALIGN=BOTTOM WIDTH=11 HEIGHT=11 BACKGROUND=themes/KDE/menuleft.gif><IMG SRC=themes/KDE/menutopleft.gif width=11 height=11></TD>
    <TD ALIGN=CENTER bgcolor=#6C6C6C BACKGROUND=themes/KDE/menutitle.gif>
    <FONT size=3 color=white></center>
    <b>$title</b><br><font size=1>".translate("Posted on ")." $datetime
";
    if ($admin) {
	echo "&nbsp;&nbsp; $font2 [ <a href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]";
    }
echo "
    </FONT></TD>
    <TD ALIGN=left VALIGN=BOTTOM WIDTH=11 HEIGHT=11 BACKGROUND=themes/KDE/menuright.gif><IMG SRC=themes/KDE/menutopright.gif width=11 height=11></TD></TR>
    <TR>
    <TD ALIGN=RIGHT BACKGROUND=themes/KDE/menuleft.gif WIDTH=11>&nbsp;</TD>
    <TD ALIGN=left VALIGN=TOP BGCOLOR=#CFCFCF BACKGROUND=themes/KDE/sketch.gif>
    <FONT size=2>
    <a href=search.php?query=&topic=$topic&author=><img src=$tipath$topicimage border=1 Alt=\"$topictext\" align=left hspace=10 vspace=10></a>
    $thetext</TD>
    <TD ALIGN=LEFT BACKGROUND=themes/KDE/menuright.gif WIDTH=11>&nbsp;</TD></TR>
    <TR>
    <TD ALIGN=right VALIGN=TOP WIDTH=11 HEIGHT=11><IMG SRC=themes/KDE/menubottomleft.gif width=11 height=11></TD>
    <TD ALIGN=MIDDLE HEIGHT=11 VALIGN=TOP><IMG SRC=themes/KDE/menubottom.gif width=100% height=1></TD>
    <TD ALIGN=left VALIGN=TOP WIDTH=11 HEIGHT=11><IMG SRC=themes/KDE/menubottomright.gif width=11 height=11>
</TD></TR></TABLE>
";

	} else {
		if($informant != "") $informant = "<a href=\"user.php?op=userinfo&uname=$informant\">$informant</a> ";
		else $boxstuff = "$anonymous ";
		$boxstuff .= "".translate("writes")." <i>\"$thetext\"</i> $notes";
echo "
<TABLE WIDTH=100% CELLPADDING=0 CELLSPACING=0 BORDER=0>
    <TR>
    <TD ALIGN=right VALIGN=BOTTOM WIDTH=11 HEIGHT=11><IMG SRC=themes/KDE/menutopleft.gif width=11 height=11></TD>
    <TD ALIGN=MIDDLE HEIGHT=11 VALIGN=BOTTOM><IMG SRC=themes/KDE/menutop.gif width=100% height=1></TD>
    <TD ALIGN=left VALIGN=BOTTOM WIDTH=11 HEIGHT=11><IMG SRC=themes/KDE/menutopright.gif width=11 height=11></TD></TR>
    <TR>
    <TD ALIGN=right VALIGN=BOTTOM WIDTH=11 HEIGHT=11 BACKGROUND=themes/KDE/menuleft.gif><IMG SRC=themes/KDE/menutopleft.gif width=11 height=11></TD>
    <TD ALIGN=CENTER bgcolor=#6C6C6C BACKGROUND=themes/KDE/menutitle.gif>
    <FONT size=3 color=white></center>
    <b>$title</b><br><font size=2>".translate("Contributed by ")." $informant ".translate("on")." $datetime</font>
    ";
    if ($admin) {
	echo "&nbsp;&nbsp; $font2 [ <a href=admin.php?op=EditStory&sid=$sid>".translate("Edit")."</a> | <a href=admin.php?op=RemoveStory&sid=$sid>".translate("Delete")."</a> ]";
    }
echo "
    </FONT></TD>
    <TD ALIGN=left VALIGN=BOTTOM WIDTH=11 HEIGHT=11 BACKGROUND=themes/KDE/menuright.gif><IMG SRC=themes/KDE/menutopright.gif width=11 height=11></TD></TR>
    <TR>
    <TD ALIGN=RIGHT BACKGROUND=themes/KDE/menuleft.gif WIDTH=11>&nbsp;</TD>
    <TD ALIGN=left VALIGN=TOP BGCOLOR=#CFCFCF BACKGROUND=themes/KDE/sketch.gif>
    <FONT size=2>
    <a href=search.php?query=&topic=$topic&author=><img src=$tipath$topicimage border=1 Alt=\"$topictext\" align=left hspace=10 vspace=10></a>
    $thetext</TD>
    <TD ALIGN=LEFT BACKGROUND=themes/KDE/menuright.gif WIDTH=11>&nbsp;</TD></TR>
    <TR>
    <TD ALIGN=right VALIGN=TOP WIDTH=11 HEIGHT=11><IMG SRC=themes/KDE/menubottomleft.gif width=11 height=11></TD>
    <TD ALIGN=MIDDLE HEIGHT=11 VALIGN=TOP><IMG SRC=themes/KDE/menubottom.gif width=100% height=1></TD>
    <TD ALIGN=left VALIGN=TOP WIDTH=11 HEIGHT=11><IMG SRC=themes/KDE/menubottomright.gif width=11 height=11>
</TD></TR></TABLE>
";

    }
}


function themesidebox($title, $content) {
    echo "
    <TABLE WIDTH=160 CELLPADDING=0 CELLSPACING=0 BORDER=0>
    <TR>
    <TD ALIGN=right VALIGN=BOTTOM WIDTH=11 HEIGHT=11><IMG SRC=themes/KDE/menutopleft.gif width=11 height=11></TD>
    <TD ALIGN=MIDDLE WIDTH=149 HEIGHT=11 VALIGN=BOTTOM><IMG SRC=themes/KDE/menutop.gif width=149 height=1 alt=></TD>
    <TD ALIGN=left VALIGN=BOTTOM WIDTH=100 HEIGHT=11><IMG SRC=themes/KDE/menutopright.gif width=11 height=11 alt=></TD></TR>
    <TR>
    <TD ALIGN=right VALIGN=BOTTOM WIDTH=11 HEIGHT=11 BACKGROUND=themes/KDE/menuleft.gif><IMG SRC=themes/KDE/menutopleft.gif width=11 height=11 alt=></TD>
    <TD ALIGN=CENTER bgcolor=6C6C6C BACKGROUND=themes/KDE/menutitle.gif>
	<FONT size=3 color=white>$title</FONT></TD>
    <TD ALIGN=left VALIGN=BOTTOM WIDTH=100 HEIGHT=11 BACKGROUND=themes/KDE/menuright.gif><IMG SRC=themes/KDE/menutopright.gif width=11 height=11 alt=></TD></TR>
    <TR>
    <TD ALIGN=RIGHT BACKGROUND=themes/KDE/menuleft.gif WIDTH=11>&nbsp;</TD>
    <TD ALIGN=left VALIGN=TOP BGCOLOR=#CFCFCF BACKGROUND=themes/KDE/grid.gif>
	<FONT size=2>$content<br></TD>
    <TD ALIGN=LEFT BACKGROUND=themes/KDE/menuright.gif WIDTH=11>&nbsp;</TD></TR>
    <TR>
    <TD ALIGN=right VALIGN=TOP WIDTH=11 HEIGHT=11><IMG SRC=themes/KDE/menubottomleft.gif width=11 height=11 alt=></TD>
    <TD ALIGN=MIDDLE WIDTH=149 HEIGHT=11 VALIGN=TOP><IMG SRC=themes/KDE/menubottom.gif width=149 height=1 alt=></TD>
    <TD ALIGN=left VALIGN=TOP WIDTH=11 HEIGHT=11><IMG SRC=themes/KDE/menubottomright.gif width=11 height=11 alt=>
    </TD></TR></TABLE>";
}
?>