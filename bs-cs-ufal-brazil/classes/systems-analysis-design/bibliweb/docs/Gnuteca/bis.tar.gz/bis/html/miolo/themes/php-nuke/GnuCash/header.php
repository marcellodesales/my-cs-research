<?php
echo "<body onload=init() bgcolor=8b7765 text=000000 link=000000 vlink=000000 topmargin=5 leftmargin=0 rightmargin=0 marginheight=5>
<br>";
if ($banners) {
    include("banners.php");
}
echo "<br>
<table border=0 width=100% cellpadding=0 cellspacing=0 align=center><tr><td align=left>
<a href=$nuke_url><img src=themes/GnuCash/logo.gif border=0 Alt=\"".translate("Welcome to")." $sitename\"></a>
</td><td background=themes/GnuCash/horbar.jpg width=100% align=right>
<div><font color=White><b>$slogan</b></div></td></tr></table></center><br><br>

<table border=0 cellpadding=4 cellspacing=0 width=100% align=center><tr><td bgcolor=8b7765>
<table border=0 cellspacing=0 cellpadding=2 width=100%><tr><td valign=top width=150 bgcolor=8b7765>";

mainblock();
adminblock();
leftblocks();
searchbox();
ephemblock();
headlines();
online();
echo "<img src=images/pix.gif border=0 width=150 height=1></td><td>&nbsp;&nbsp;</td><td width=100% valign=top>";
?>