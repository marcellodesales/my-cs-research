--
-- Selected TOC Entries:
--
\connect - postgres
--
-- TOC Entry ID 2 (OID 266386)
--
-- Name: sequencia_reserva Type: SEQUENCE Owner: postgres
--

CREATE SEQUENCE "sequencia_reserva" start 1 increment 1 maxvalue 2147483647 minvalue 1  cache 1 ;

--
-- TOC Entry ID 3 (OID 266386)
--
-- Name: sequencia_reserva Type: ACL Owner: 
--

REVOKE ALL on "sequencia_reserva" from PUBLIC;
GRANT ALL on "sequencia_reserva" to PUBLIC;
GRANT ALL on "sequencia_reserva" to "postgres";

--
-- TOC Entry ID 4 (OID 266405)
--
-- Name: seq_gtc_material_numerodaobra Type: SEQUENCE Owner: postgres
--

CREATE SEQUENCE "seq_gtc_material_numerodaobra" start 1 increment 1 maxvalue 2147483647 minvalue 1  cache 1 ;

--
-- TOC Entry ID 5 (OID 266405)
--
-- Name: seq_gtc_material_numerodaobra Type: ACL Owner: 
--

REVOKE ALL on "seq_gtc_material_numerodaobra" from PUBLIC;
GRANT ALL on "seq_gtc_material_numerodaobra" to PUBLIC;
GRANT ALL on "seq_gtc_material_numerodaobra" to "postgres";

--
-- TOC Entry ID 6 (OID 266424)
--
-- Name: sequencia_multa Type: SEQUENCE Owner: pablo
--

CREATE SEQUENCE "sequencia_multa" start 1 increment 1 maxvalue 2147483647 minvalue 1  cache 1 ;

--
-- TOC Entry ID 7 (OID 266424)
--
-- Name: sequencia_multa Type: ACL Owner: 
--

REVOKE ALL on "sequencia_multa" from PUBLIC;
GRANT ALL on "sequencia_multa" to PUBLIC;

\connect - postgres
--
-- TOC Entry ID 10 (OID 266443)
--
-- Name: gtc_etiqueta Type: TABLE Owner: postgres
--

CREATE TABLE "gtc_etiqueta" (
	"etiqueta" character(3),
	"subcampo" character(1),
	"mnemonico" character varying(10),
	"descricao" character varying(80),
	"observacao" text,
	"temrepeticoes" boolean,
	"temsubcampos" boolean,
	"estaativo" boolean,
	"emlistas" boolean,
	"emconsultas" boolean,
	"emdemonstracao" boolean,
	"obsoleto" boolean
);

--
-- TOC Entry ID 11 (OID 266443)
--
-- Name: gtc_etiqueta Type: ACL Owner: 
--

REVOKE ALL on "gtc_etiqueta" from PUBLIC;
GRANT ALL on "gtc_etiqueta" to PUBLIC;
GRANT ALL on "gtc_etiqueta" to "postgres";

--
-- TOC Entry ID 12 (OID 266479)
--
-- Name: gtc_politica Type: TABLE Owner: postgres
--

CREATE TABLE "gtc_politica" (
	"codigodogrupo" integer,
	"codigodogenero" integer,
	"diasdeemprestimo" integer,
	"limitedeemprestimo" integer,
	"limitederenovacao" integer,
	"limitedereserva" integer,
	"valordamulta" double precision,
	"diasdereserva" integer
);

--
-- TOC Entry ID 13 (OID 266479)
--
-- Name: gtc_politica Type: ACL Owner: 
--

REVOKE ALL on "gtc_politica" from PUBLIC;
GRANT ALL on "gtc_politica" to PUBLIC;
GRANT ALL on "gtc_politica" to "postgres";

--
-- TOC Entry ID 14 (OID 266496)
--
-- Name: gtc_direito Type: TABLE Owner: postgres
--

CREATE TABLE "gtc_direito" (
	"codigodogrupo" integer,
	"codigodaoperacao" integer,
	"codigodogenero" integer
);

--
-- TOC Entry ID 15 (OID 266496)
--
-- Name: gtc_direito Type: ACL Owner: 
--

REVOKE ALL on "gtc_direito" from PUBLIC;
GRANT ALL on "gtc_direito" to PUBLIC;
GRANT ALL on "gtc_direito" to "postgres";

--
-- TOC Entry ID 16 (OID 266508)
--
-- Name: gtc_operacao Type: TABLE Owner: postgres
--

CREATE TABLE "gtc_operacao" (
	"codigodaoperacao" integer,
	"descricao" character varying(40),
	"mnemonico" character varying(20)
);

--
-- TOC Entry ID 17 (OID 266508)
--
-- Name: gtc_operacao Type: ACL Owner: 
--

REVOKE ALL on "gtc_operacao" from PUBLIC;
GRANT ALL on "gtc_operacao" to PUBLIC;
GRANT ALL on "gtc_operacao" to "postgres";

--
-- TOC Entry ID 18 (OID 266520)
--
-- Name: gtc_composicao Type: TABLE Owner: postgres
--

CREATE TABLE "gtc_composicao" (
	"codigodareserva" integer,
	"numerodotombo" text,
	"foiconfirmada" boolean
);

--
-- TOC Entry ID 19 (OID 266520)
--
-- Name: gtc_composicao Type: ACL Owner: 
--

REVOKE ALL on "gtc_composicao" from PUBLIC;
GRANT ALL on "gtc_composicao" to PUBLIC;
GRANT ALL on "gtc_composicao" to "postgres";

--
-- TOC Entry ID 20 (OID 266547)
--
-- Name: gtc_estado Type: TABLE Owner: postgres
--

CREATE TABLE "gtc_estado" (
	"codigodoestado" integer,
	"descricao" character varying(40),
	"mnemonico" character varying(20)
);

--
-- TOC Entry ID 21 (OID 266547)
--
-- Name: gtc_estado Type: ACL Owner: 
--

REVOKE ALL on "gtc_estado" from PUBLIC;
GRANT ALL on "gtc_estado" to PUBLIC;
GRANT ALL on "gtc_estado" to "postgres";

--
-- TOC Entry ID 22 (OID 266559)
--
-- Name: gtc_situacao Type: TABLE Owner: postgres
--

CREATE TABLE "gtc_situacao" (
	"codigodasituacao" integer,
	"descricao" character varying(40),
	"mnemonico" character varying(20)
);

--
-- TOC Entry ID 23 (OID 266559)
--
-- Name: gtc_situacao Type: ACL Owner: 
--

REVOKE ALL on "gtc_situacao" from PUBLIC;
GRANT ALL on "gtc_situacao" to PUBLIC;
GRANT ALL on "gtc_situacao" to "postgres";

--
-- TOC Entry ID 24 (OID 266571)
--
-- Name: gtc_feriado Type: TABLE Owner: postgres
--

CREATE TABLE "gtc_feriado" (
	"datadoferiado" date,
	"descricao" character varying(40)
);

--
-- TOC Entry ID 25 (OID 266571)
--
-- Name: gtc_feriado Type: ACL Owner: 
--

REVOKE ALL on "gtc_feriado" from PUBLIC;
GRANT ALL on "gtc_feriado" to PUBLIC;
GRANT ALL on "gtc_feriado" to "postgres";

--
-- TOC Entry ID 26 (OID 266582)
--
-- Name: gtc_exemplar Type: TABLE Owner: postgres
--

CREATE TABLE "gtc_exemplar" (
	"numerodotombo" character varying(20),
	"codigodoexemplar" character varying(20),
	"numerodaobra" integer,
	"codigodoestado" integer
);

--
-- TOC Entry ID 27 (OID 266582)
--
-- Name: gtc_exemplar Type: ACL Owner: 
--

REVOKE ALL on "gtc_exemplar" from PUBLIC;
GRANT ALL on "gtc_exemplar" to PUBLIC;
GRANT ALL on "gtc_exemplar" to "postgres";

--
-- TOC Entry ID 28 (OID 266595)
--
-- Name: gtc_transicao Type: TABLE Owner: postgres
--

CREATE TABLE "gtc_transicao" (
	"codigodoestadopresente" integer,
	"codigodaoperacao" integer,
	"codigodoestadofuturo" integer
);

--
-- TOC Entry ID 29 (OID 266595)
--
-- Name: gtc_transicao Type: ACL Owner: 
--

REVOKE ALL on "gtc_transicao" from PUBLIC;
GRANT ALL on "gtc_transicao" to PUBLIC;
GRANT ALL on "gtc_transicao" to "postgres";

--
-- TOC Entry ID 30 (OID 266607)
--
-- Name: gtc_genero Type: TABLE Owner: postgres
--

CREATE TABLE "gtc_genero" (
	"codigodogenero" integer,
	"descricao" character varying(40)
);

--
-- TOC Entry ID 31 (OID 266607)
--
-- Name: gtc_genero Type: ACL Owner: 
--

REVOKE ALL on "gtc_genero" from PUBLIC;
GRANT ALL on "gtc_genero" to PUBLIC;
GRANT ALL on "gtc_genero" to "postgres";

--
-- TOC Entry ID 32 (OID 266618)
--
-- Name: gtc_reserva Type: TABLE Owner: postgres
--

CREATE TABLE "gtc_reserva" (
	"codigodareserva" integer DEFAULT nextval('sequencia_reserva'::text) NOT NULL,
	"codigodapessoa" integer,
	"datahoradareserva" timestamp with time zone,
	"datahoradasituacao" timestamp with time zone,
	"datahoraentrada" timestamp with time zone,
	"datahoralimite" timestamp with time zone,
	"codigodooperador" character varying(20),
	"codigodasituacao" integer,
	"foiavisado" boolean
);

--
-- TOC Entry ID 33 (OID 266618)
--
-- Name: gtc_reserva Type: ACL Owner: 
--

REVOKE ALL on "gtc_reserva" from PUBLIC;
GRANT ALL on "gtc_reserva" to PUBLIC;
GRANT ALL on "gtc_reserva" to "postgres";

--
-- TOC Entry ID 34 (OID 266637)
--
-- Name: gtc_emprestimo Type: TABLE Owner: postgres
--

CREATE TABLE "gtc_emprestimo" (
	"codigodoemprestimo" integer DEFAULT nextval('sequencia_emprestimo'::text) NOT NULL,
	"codigodapessoa" integer,
	"numerodotombo" text,
	"datahoradoemprestimo" timestamp with time zone,
	"datahoraprevisaodevolucao" timestamp with time zone,
	"datahoradadevolucao" timestamp with time zone,
	"codigodooperadoremprestimo" character varying(20),
	"codigodooperadordevolucao" character varying(20),
	"quantidadederenovacoes" integer,
	"data1" character varying(20),
	"data2" character varying(20)
);

--
-- TOC Entry ID 35 (OID 266637)
--
-- Name: gtc_emprestimo Type: ACL Owner: 
--

REVOKE ALL on "gtc_emprestimo" from PUBLIC;
GRANT ALL on "gtc_emprestimo" to PUBLIC;
GRANT ALL on "gtc_emprestimo" to "postgres";

--
-- TOC Entry ID 36 (OID 266673)
--
-- Name: gtc_paises Type: TABLE Owner: postgres
--

CREATE TABLE "gtc_paises" (
	"codigodopais" character varying(4) NOT NULL,
	"descricao" character varying(50)
);

--
-- TOC Entry ID 37 (OID 266673)
--
-- Name: gtc_paises Type: ACL Owner: 
--

REVOKE ALL on "gtc_paises" from PUBLIC;
GRANT SELECT on "gtc_paises" to PUBLIC;
GRANT ALL on "gtc_paises" to "postgres";

--
-- TOC Entry ID 38 (OID 266684)
--
-- Name: gtc_idiomas Type: TABLE Owner: postgres
--

CREATE TABLE "gtc_idiomas" (
	"codigodoidioma" character varying(4),
	"descricao" character varying(60)
);

--
-- TOC Entry ID 39 (OID 266684)
--
-- Name: gtc_idiomas Type: ACL Owner: 
--

REVOKE ALL on "gtc_idiomas" from PUBLIC;
GRANT SELECT on "gtc_idiomas" to PUBLIC;
GRANT ALL on "gtc_idiomas" to "postgres";

--
-- TOC Entry ID 40 (OID 266695)
--
-- Name: gtc_areageografica Type: TABLE Owner: postgres
--

CREATE TABLE "gtc_areageografica" (
	"codigodaareageografica" character varying(4),
	"descricao" character varying(60)
);

--
-- TOC Entry ID 41 (OID 266695)
--
-- Name: gtc_areageografica Type: ACL Owner: 
--

REVOKE ALL on "gtc_areageografica" from PUBLIC;
GRANT ALL on "gtc_areageografica" to PUBLIC;
GRANT ALL on "gtc_areageografica" to "postgres";

--
-- TOC Entry ID 42 (OID 266706)
--
-- Name: pga_queries Type: TABLE Owner: postgres
--

CREATE TABLE "pga_queries" (
	"queryname" character varying(64),
	"querytype" character(1),
	"querycommand" text,
	"querytables" text,
	"querylinks" text,
	"queryresults" text,
	"querycomments" text
);

--
-- TOC Entry ID 43 (OID 266706)
--
-- Name: pga_queries Type: ACL Owner: 
--

REVOKE ALL on "pga_queries" from PUBLIC;
GRANT ALL on "pga_queries" to PUBLIC;
GRANT ALL on "pga_queries" to "postgres";

--
-- TOC Entry ID 44 (OID 266737)
--
-- Name: pga_forms Type: TABLE Owner: postgres
--

CREATE TABLE "pga_forms" (
	"formname" character varying(64),
	"formsource" text
);

--
-- TOC Entry ID 45 (OID 266737)
--
-- Name: pga_forms Type: ACL Owner: 
--

REVOKE ALL on "pga_forms" from PUBLIC;
GRANT ALL on "pga_forms" to PUBLIC;
GRANT ALL on "pga_forms" to "postgres";

--
-- TOC Entry ID 46 (OID 266763)
--
-- Name: pga_scripts Type: TABLE Owner: postgres
--

CREATE TABLE "pga_scripts" (
	"scriptname" character varying(64),
	"scriptsource" text
);

--
-- TOC Entry ID 47 (OID 266763)
--
-- Name: pga_scripts Type: ACL Owner: 
--

REVOKE ALL on "pga_scripts" from PUBLIC;
GRANT ALL on "pga_scripts" to PUBLIC;
GRANT ALL on "pga_scripts" to "postgres";

--
-- TOC Entry ID 48 (OID 266789)
--
-- Name: pga_reports Type: TABLE Owner: postgres
--

CREATE TABLE "pga_reports" (
	"reportname" character varying(64),
	"reportsource" text,
	"reportbody" text,
	"reportprocs" text,
	"reportoptions" text
);

--
-- TOC Entry ID 49 (OID 266789)
--
-- Name: pga_reports Type: ACL Owner: 
--

REVOKE ALL on "pga_reports" from PUBLIC;
GRANT ALL on "pga_reports" to PUBLIC;
GRANT ALL on "pga_reports" to "postgres";

--
-- TOC Entry ID 50 (OID 266818)
--
-- Name: pga_schema Type: TABLE Owner: postgres
--

CREATE TABLE "pga_schema" (
	"schemaname" character varying(64),
	"schematables" text,
	"schemalinks" text
);

--
-- TOC Entry ID 51 (OID 266818)
--
-- Name: pga_schema Type: ACL Owner: 
--

REVOKE ALL on "pga_schema" from PUBLIC;
GRANT ALL on "pga_schema" to PUBLIC;
GRANT ALL on "pga_schema" to "postgres";

--
-- TOC Entry ID 52 (OID 266845)
--
-- Name: pga_layout Type: TABLE Owner: postgres
--

CREATE TABLE "pga_layout" (
	"tablename" character varying(64),
	"nrcols" smallint,
	"colnames" text,
	"colwidth" text
);

--
-- TOC Entry ID 53 (OID 266845)
--
-- Name: pga_layout Type: ACL Owner: 
--

REVOKE ALL on "pga_layout" from PUBLIC;
GRANT ALL on "pga_layout" to PUBLIC;
GRANT ALL on "pga_layout" to "postgres";

--
-- TOC Entry ID 54 (OID 266904)
--
-- Name: gtc_ficha Type: TABLE Owner: postgres
--

CREATE TABLE "gtc_ficha" (
	"categoria" character(2) NOT NULL,
	"nivel" character(1) NOT NULL,
	"campos" text NOT NULL
);

--
-- TOC Entry ID 55 (OID 266904)
--
-- Name: gtc_ficha Type: ACL Owner: 
--

REVOKE ALL on "gtc_ficha" from PUBLIC;
GRANT SELECT on "gtc_ficha" to PUBLIC;
GRANT ALL on "gtc_ficha" to "postgres";

--
-- TOC Entry ID 56 (OID 266931)
--
-- Name: gtc_opcao Type: TABLE Owner: postgres
--

CREATE TABLE "gtc_opcao" (
	"id" character varying(10) NOT NULL,
	"descricao" character varying(120) NOT NULL,
	"opcoes" text NOT NULL,
	Constraint "gtc_opcao_pkey" Primary Key ("id")
);

--
-- TOC Entry ID 57 (OID 266931)
--
-- Name: gtc_opcao Type: ACL Owner: 
--

REVOKE ALL on "gtc_opcao" from PUBLIC;
GRANT ALL on "gtc_opcao" to PUBLIC;
GRANT ALL on "gtc_opcao" to "postgres";

--
-- TOC Entry ID 58 (OID 266961)
--
-- Name: gtc_busca Type: TABLE Owner: postgres
--

CREATE TABLE "gtc_busca" (
	"numerodaobra" integer,
	"assunto" character varying(120),
	"autor" character varying(80),
	"titulo" character varying(240),
	"editora" character varying(80),
	"serie" character varying(80),
	"ano" character varying(16)
);

--
-- TOC Entry ID 59 (OID 266961)
--
-- Name: gtc_busca Type: ACL Owner: 
--

REVOKE ALL on "gtc_busca" from PUBLIC;
GRANT ALL on "gtc_busca" to PUBLIC;
GRANT ALL on "gtc_busca" to "postgres";

--
-- TOC Entry ID 60 (OID 266977)
--
-- Name: gtc_multa Type: TABLE Owner: postgres
--

CREATE TABLE "gtc_multa" (
	"codigodapessoa" integer,
	"codigodoemprestimo" integer,
	"datahora" timestamp with time zone,
	"valor" numeric(10,2),
	"observacao" text,
	"foipaga" boolean,
	"codigodamulta" integer
);

--
-- TOC Entry ID 61 (OID 266977)
--
-- Name: gtc_multa Type: ACL Owner: 
--

REVOKE ALL on "gtc_multa" from PUBLIC;
GRANT ALL on "gtc_multa" to PUBLIC;
GRANT ALL on "gtc_multa" to "postgres";

--
-- TOC Entry ID 88 (OID 267008)
--
-- Name: "etiqueta" (integer,character varying,character varying) Type: FUNCTION Owner: postgres
--

CREATE FUNCTION "etiqueta" (integer,character varying,character varying) RETURNS text AS 'select conteudo from gtc_material where numerodaobra = $1 and etiqueta = $2 and text(subcampo) = text($3)' LANGUAGE 'sql';

--
-- TOC Entry ID 8 (OID 267074)
--
-- Name: sequencia_emprestimo Type: SEQUENCE Owner: postgres
--

CREATE SEQUENCE "sequencia_emprestimo" start 1 increment 1 maxvalue 2147483647 minvalue 1  cache 1 ;

--
-- TOC Entry ID 9 (OID 267074)
--
-- Name: sequencia_emprestimo Type: ACL Owner: 
--

REVOKE ALL on "sequencia_emprestimo" from PUBLIC;
GRANT ALL on "sequencia_emprestimo" to PUBLIC;
GRANT ALL on "sequencia_emprestimo" to "postgres";

--
-- TOC Entry ID 62 (OID 2229321)
--
-- Name: gtc_material Type: TABLE Owner: postgres
--

CREATE TABLE "gtc_material" (
	"numerodaobra" integer,
	"etiqueta" character varying(3),
	"indicador1" character(1),
	"indicador2" character(1),
	"subcampo" character(1),
	"conteudo" text,
	"linha" integer
);

--
-- TOC Entry ID 63 (OID 2229321)
--
-- Name: gtc_material Type: ACL Owner: 
--

REVOKE ALL on "gtc_material" from PUBLIC;
GRANT ALL on "gtc_material" to PUBLIC;
GRANT ALL on "gtc_material" to "postgres";

--
-- TOC Entry ID 64 (OID 266582)
--
-- Name: "gtc_exemplar_tombo" Type: INDEX Owner: postgres
--

CREATE  INDEX "gtc_exemplar_tombo" on "gtc_exemplar" using btree ( "numerodotombo" "varchar_ops" );

--
-- TOC Entry ID 65 (OID 266582)
--
-- Name: "gtc_exemplar_exemplar" Type: INDEX Owner: postgres
--

CREATE  INDEX "gtc_exemplar_exemplar" on "gtc_exemplar" using btree ( "codigodoexemplar" "varchar_ops" );

--
-- TOC Entry ID 66 (OID 266582)
--
-- Name: "gtc_exemplar_obra" Type: INDEX Owner: postgres
--

CREATE  INDEX "gtc_exemplar_obra" on "gtc_exemplar" using btree ( "numerodaobra" "int4_ops" );

--
-- TOC Entry ID 67 (OID 266618)
--
-- Name: "gtc_reserva_codigo" Type: INDEX Owner: postgres
--

CREATE  INDEX "gtc_reserva_codigo" on "gtc_reserva" using btree ( "codigodareserva" "int4_ops" );

--
-- TOC Entry ID 68 (OID 266618)
--
-- Name: "gtc_reserva_pessoa" Type: INDEX Owner: postgres
--

CREATE  INDEX "gtc_reserva_pessoa" on "gtc_reserva" using btree ( "codigodapessoa" "int4_ops" );

--
-- TOC Entry ID 69 (OID 266637)
--
-- Name: "gtc_emprestimo_codigo" Type: INDEX Owner: postgres
--

CREATE  INDEX "gtc_emprestimo_codigo" on "gtc_emprestimo" using btree ( "codigodoemprestimo" "int4_ops" );

--
-- TOC Entry ID 70 (OID 266637)
--
-- Name: "gtc_emprestimo_pessoa" Type: INDEX Owner: postgres
--

CREATE  INDEX "gtc_emprestimo_pessoa" on "gtc_emprestimo" using btree ( "codigodapessoa" "int4_ops" );

--
-- TOC Entry ID 71 (OID 266637)
--
-- Name: "gtc_emprestimo_tombo" Type: INDEX Owner: postgres
--

CREATE  INDEX "gtc_emprestimo_tombo" on "gtc_emprestimo" using btree ( "numerodotombo" "text_ops" );

--
-- TOC Entry ID 72 (OID 266637)
--
-- Name: "gtc_emprestimo_dh_emp" Type: INDEX Owner: postgres
--

CREATE  INDEX "gtc_emprestimo_dh_emp" on "gtc_emprestimo" using btree ( "datahoradoemprestimo" "timestamp_ops" );

--
-- TOC Entry ID 73 (OID 266637)
--
-- Name: "gtc_emprestimo_dh_prevdev" Type: INDEX Owner: postgres
--

CREATE  INDEX "gtc_emprestimo_dh_prevdev" on "gtc_emprestimo" using btree ( "datahoraprevisaodevolucao" "timestamp_ops" );

--
-- TOC Entry ID 74 (OID 266637)
--
-- Name: "gtc_emprestimo_dh_dev" Type: INDEX Owner: postgres
--

CREATE  INDEX "gtc_emprestimo_dh_dev" on "gtc_emprestimo" using btree ( "datahoradadevolucao" "timestamp_ops" );

--
-- TOC Entry ID 75 (OID 266904)
--
-- Name: "gtc_ficha_categoria_key" Type: INDEX Owner: postgres
--

CREATE UNIQUE INDEX "gtc_ficha_categoria_key" on "gtc_ficha" using btree ( "categoria" "bpchar_ops", "nivel" "bpchar_ops" );

--
-- TOC Entry ID 76 (OID 266961)
--
-- Name: "gtc_busca_assunto" Type: INDEX Owner: postgres
--

CREATE  INDEX "gtc_busca_assunto" on "gtc_busca" using btree ( "assunto" "varchar_ops" );

--
-- TOC Entry ID 77 (OID 266961)
--
-- Name: "gtc_busca_autor" Type: INDEX Owner: postgres
--

CREATE  INDEX "gtc_busca_autor" on "gtc_busca" using btree ( "autor" "varchar_ops" );

--
-- TOC Entry ID 78 (OID 266961)
--
-- Name: "gtc_busca_titulo" Type: INDEX Owner: postgres
--

CREATE  INDEX "gtc_busca_titulo" on "gtc_busca" using btree ( "titulo" "varchar_ops" );

--
-- TOC Entry ID 79 (OID 266961)
--
-- Name: "gtc_busca_editora" Type: INDEX Owner: postgres
--

CREATE  INDEX "gtc_busca_editora" on "gtc_busca" using btree ( "editora" "varchar_ops" );

--
-- TOC Entry ID 80 (OID 266961)
--
-- Name: "gtc_busca_serie" Type: INDEX Owner: postgres
--

CREATE  INDEX "gtc_busca_serie" on "gtc_busca" using btree ( "serie" "varchar_ops" );

--
-- TOC Entry ID 81 (OID 266961)
--
-- Name: "gtc_busca_ano" Type: INDEX Owner: postgres
--

CREATE  INDEX "gtc_busca_ano" on "gtc_busca" using btree ( "ano" "varchar_ops" );

--
-- TOC Entry ID 82 (OID 266961)
--
-- Name: "gtc_busca_obra" Type: INDEX Owner: postgres
--

CREATE  INDEX "gtc_busca_obra" on "gtc_busca" using btree ( "numerodaobra" "int4_ops" );

--
-- TOC Entry ID 83 (OID 2229321)
--
-- Name: "gtc_material_numerodaobra" Type: INDEX Owner: postgres
--

CREATE  INDEX "gtc_material_numerodaobra" on "gtc_material" using btree ( "numerodaobra" "int4_ops" );

--
-- TOC Entry ID 84 (OID 2229321)
--
-- Name: "gtc_material_etiqueta" Type: INDEX Owner: postgres
--

CREATE  INDEX "gtc_material_etiqueta" on "gtc_material" using btree ( "etiqueta" "varchar_ops" );

--
-- TOC Entry ID 85 (OID 2229321)
--
-- Name: "gtc_material_no_etiq_subc" Type: INDEX Owner: postgres
--

CREATE  INDEX "gtc_material_no_etiq_subc" on "gtc_material" using btree ( "numerodaobra" "int4_ops", "etiqueta" "varchar_ops", "subcampo" "bpchar_ops" );

--
-- TOC Entry ID 86 (OID 2229321)
--
-- Name: "gtc_material_etiq_subc_cont" Type: INDEX Owner: postgres
--

CREATE  INDEX "gtc_material_etiq_subc_cont" on "gtc_material" using btree ( "etiqueta" "varchar_ops", "subcampo" "bpchar_ops", "conteudo" "text_ops" );

--
-- TOC Entry ID 87 (OID 2229321)
--
-- Name: "gtc_material_conteudo" Type: INDEX Owner: postgres
--

CREATE  INDEX "gtc_material_conteudo" on "gtc_material" using btree ( "conteudo" "text_ops" );

