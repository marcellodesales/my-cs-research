--
-- Selected TOC Entries:
--
\connect - postgres
--
-- TOC Entry ID 2 (OID 1476803)
--
-- Name: cmn_grupo Type: TABLE Owner: postgres
--

CREATE TABLE "cmn_grupo" (
	"codigodogrupo" integer,
	"descricao" character varying(40),
	"nivel" integer
);

--
-- TOC Entry ID 3 (OID 1476803)
--
-- Name: cmn_grupo Type: ACL Owner: 
--

REVOKE ALL on "cmn_grupo" from PUBLIC;
GRANT ALL on "cmn_grupo" to PUBLIC;
GRANT ALL on "cmn_grupo" to "postgres";

--
-- TOC Entry ID 4 (OID 1476815)
--
-- Name: cmn_vinculo Type: TABLE Owner: postgres
--

CREATE TABLE "cmn_vinculo" (
	"codigodapessoa" integer,
	"codigodogrupo" integer,
	"datavalidade" date
);

--
-- TOC Entry ID 5 (OID 1476815)
--
-- Name: cmn_vinculo Type: ACL Owner: 
--

REVOKE ALL on "cmn_vinculo" from PUBLIC;
GRANT ALL on "cmn_vinculo" to PUBLIC;
GRANT ALL on "cmn_vinculo" to "postgres";

--
-- TOC Entry ID 6 (OID 1476827)
--
-- Name: cmn_pessoas Type: TABLE Owner: postgres
--

CREATE TABLE "cmn_pessoas" (
	"id" integer DEFAULT nextval('seq_pessoas'::text) NOT NULL,
	"identificacao" character(1) DEFAULT '',
	"titulo_academico" character varying(50) DEFAULT '',
	"nome" character varying(80) DEFAULT '',
	"rua" character varying(50) DEFAULT '',
	"complemento" character varying(50) DEFAULT '',
	"bairro" character varying(40) DEFAULT '',
	"cep" character varying(9) DEFAULT '',
	"ref_cidade" integer DEFAULT 0,
	"fone_particular" character varying(50) DEFAULT '',
	"fone_profissional" character varying(50) DEFAULT '',
	"fone_celular" character varying(50) DEFAULT '',
	"fone_recado" character varying(50) DEFAULT '',
	"email" character varying(50) DEFAULT '',
	"email_alt" character varying(50) DEFAULT '',
	"estado_civil" character varying(20) DEFAULT '',
	"dt_cadastro" date DEFAULT date(now()),
	"tipo_pessoa" character(1) DEFAULT 'f',
	"obs" text,
	"dt_nascimento" date,
	"sexo" character(1) DEFAULT '',
	"credo" character varying(50),
	"nome_fantasia" character varying(100),
	"cod_inscricao_estadual" character varying(50),
	"rg_numero" character varying(20),
	"rg_orgao" character varying(5),
	"rg_cidade" integer DEFAULT 0,
	"rg_data" date,
	"ref_filiacao" integer DEFAULT 0,
	"ref_cobranca" integer DEFAULT 0,
	"ref_assistmed" integer DEFAULT 0,
	"ref_naturalidade" integer DEFAULT 0,
	"ref_nacionalidade" integer DEFAULT 0,
	"ref_segurado" integer DEFAULT 0,
	"cod_cpf_cgc" character varying(18),
	"titulo_eleitor" character varying(50),
	"placa_carro" character varying(10),
	"conta_laboratorio" character varying(50),
	"conta_provedor" character varying(50),
	"regc_livro" character varying(20),
	"regc_folha" character varying(20),
	"regc_local" character varying(20),
	"regc_nasc_casam" character varying(20),
	"ano_1g" smallint,
	"cidade_1g" integer DEFAULT '',
	"ref_curso_1g" integer DEFAULT 0,
	"escola_1g" integer DEFAULT 0,
	"ano_2g" smallint DEFAULT 0,
	"cidade_2g" integer DEFAULT 0,
	"ref_curso_2g" integer DEFAULT 0,
	"escola_2g" integer DEFAULT 0,
	"graduacao" integer DEFAULT 0,
	"cod_passivo" character varying(50),
	"senha" integer,
	"fl_dbfolha" boolean,
	"ref_pessoa_folha" integer,
	"fl_documentos" boolean,
	"fl_documentos_fora" boolean,
	"fl_quitacao_eleitoral" integer,
	"fl_segurado" boolean,
	"nome2" character varying(100),
	"fl_cartao" boolean,
	"deficiencia" integer,
	"cidade" character varying,
	"nacionalidade" character varying,
	"in_sagu" boolean,
	"cod_externo" integer,
	CONSTRAINT "pessoas_tipo_pessoa" CHECK (((tipo_pessoa = 'f'::bpchar) OR (tipo_pessoa = 'j'::bpchar)))
);

--
-- TOC Entry ID 7 (OID 1476827)
--
-- Name: cmn_pessoas Type: ACL Owner: 
--

REVOKE ALL on "cmn_pessoas" from PUBLIC;
GRANT ALL on "cmn_pessoas" to PUBLIC;
GRANT ALL on "cmn_pessoas" to "postgres";

--
-- TOC Entry ID 8 (OID 1476827)
--
-- Name: "cmn_pessoas_codigo" Type: INDEX Owner: postgres
--

CREATE  INDEX "cmn_pessoas_codigo" on "cmn_pessoas" using btree ( "id" "int4_ops" );

--
-- TOC Entry ID 9 (OID 1476827)
--
-- Name: "cmn_pessoas_nome" Type: INDEX Owner: postgres
--

CREATE  INDEX "cmn_pessoas_nome" on "cmn_pessoas" using btree ( "nome" "varchar_ops" );

