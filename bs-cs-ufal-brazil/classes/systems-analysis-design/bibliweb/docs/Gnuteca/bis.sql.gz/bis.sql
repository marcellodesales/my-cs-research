--
-- Selected TOC Entries:
--
\connect - postgres
DROP INDEX "cmn_access_user_key";
DROP TABLE "cmn_users";
DROP TABLE "cmn_access";
--
-- TOC Entry ID 8 (OID 26974)
--
-- Name: cmn_access Type: TABLE Owner: postgres
--

CREATE TABLE "cmn_access" (
	"module" character varying(20) NOT NULL,
	"login" character varying(20) NOT NULL,
	"action" character varying(50) NOT NULL,
	"fl_access" boolean DEFAULT 'f'::bool
);

--
-- TOC Entry ID 9 (OID 26974)
--
-- Name: cmn_access Type: ACL Owner: 
--

REVOKE ALL on "cmn_access" from PUBLIC;
GRANT SELECT on "cmn_access" to PUBLIC;
GRANT ALL on "cmn_access" to "postgres";

--
-- TOC Entry ID 10 (OID 26974)
--
-- Name: TABLE "cmn_access" Type: COMMENT Owner: 
--

COMMENT ON TABLE "cmn_access" IS 'Cadastro de Direitos de Acessos dos Usu�rios';

--
-- TOC Entry ID 11 (OID 35187)
--
-- Name: cmn_users Type: TABLE Owner: postgres
--

CREATE TABLE "cmn_users" (
	"login" character varying(20) NOT NULL,
	"nome" character varying(120) NOT NULL,
	"email" character varying(40),
	"fone" character varying(40),
	"setor" character varying(20),
	"predio" character varying(20),
	"sala" character varying(20),
	"aniversario" date,
	"cargo" character varying(40),
	Constraint "cmn_users_pkey" Primary Key ("login")
);

--
-- TOC Entry ID 12 (OID 35187)
--
-- Name: cmn_users Type: ACL Owner: 
--

REVOKE ALL on "cmn_users" from PUBLIC;
GRANT SELECT on "cmn_users" to PUBLIC;
GRANT ALL on "cmn_users" to "postgres";

--
-- Data for TOC Entry ID 18 (OID 26974)
--
-- Name: cmn_access Type: TABLE DATA Owner: postgres
--


INSERT INTO "cmn_access" VALUES ('vestibular','bis','acesso','t');
INSERT INTO "cmn_access" VALUES ('vestibular','bis','consultar','t');
INSERT INTO "cmn_access" VALUES ('vestibular','bis','inserir','t');
INSERT INTO "cmn_access" VALUES ('vestibular','bis','alterar','t');
INSERT INTO "cmn_access" VALUES ('vestibular','bis','excluir','t');
INSERT INTO "cmn_access" VALUES ('vestibular','bis','processar','t');
INSERT INTO "cmn_access" VALUES ('vestibular','vilson','acesso','t');
INSERT INTO "cmn_access" VALUES ('vestibular','vilson','consultar','t');
INSERT INTO "cmn_access" VALUES ('vestibular','vilson','inserir','t');
INSERT INTO "cmn_access" VALUES ('vestibular','vilson','alterar','t');
INSERT INTO "cmn_access" VALUES ('vestibular','vilson','excluir','t');
INSERT INTO "cmn_access" VALUES ('vestibular','vilson','processar','t');
INSERT INTO "cmn_access" VALUES ('vestibular','joao','acesso','t');
INSERT INTO "cmn_access" VALUES ('vestibular','joao','consultar','t');
INSERT INTO "cmn_access" VALUES ('vestibular','joao','inserir','t');
INSERT INTO "cmn_access" VALUES ('vestibular','joao','alterar','t');
INSERT INTO "cmn_access" VALUES ('vestibular','joao','excluir','t');
INSERT INTO "cmn_access" VALUES ('vestibular','joao','processar','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','bis','acesso','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','bis','consultar','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','bis','inserir','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','bis','alterar','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','bis','excluir','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','bis','processar','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','vilson','acesso','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','vilson','consultar','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','vilson','inserir','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','vilson','alterar','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','vilson','excluir','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','vilson','processar','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','pablo','acesso','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','pablo','consultar','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','pablo','inserir','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','pablo','alterar','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','pablo','excluir','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','pablo','processar','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','joao','acesso','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','joao','consultar','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','joao','inserir','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','joao','alterar','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','joao','excluir','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','joao','processar','t');
INSERT INTO "cmn_access" VALUES ('academico','bis','acesso','t');
INSERT INTO "cmn_access" VALUES ('academico','bis','consultar','t');
INSERT INTO "cmn_access" VALUES ('academico','bis','inserir','t');
INSERT INTO "cmn_access" VALUES ('academico','bis','alterar','t');
INSERT INTO "cmn_access" VALUES ('academico','bis','excluir','t');
INSERT INTO "cmn_access" VALUES ('academico','bis','processar','t');
INSERT INTO "cmn_access" VALUES ('academico','vilson','acesso','t');
INSERT INTO "cmn_access" VALUES ('academico','vilson','consultar','t');
INSERT INTO "cmn_access" VALUES ('academico','vilson','inserir','t');
INSERT INTO "cmn_access" VALUES ('academico','vilson','alterar','t');
INSERT INTO "cmn_access" VALUES ('academico','vilson','excluir','t');
INSERT INTO "cmn_access" VALUES ('academico','vilson','processar','t');
INSERT INTO "cmn_access" VALUES ('academico','pablo','acesso','t');
INSERT INTO "cmn_access" VALUES ('academico','pablo','consultar','t');
INSERT INTO "cmn_access" VALUES ('academico','pablo','inserir','t');
INSERT INTO "cmn_access" VALUES ('academico','pablo','alterar','t');
INSERT INTO "cmn_access" VALUES ('academico','pablo','excluir','t');
INSERT INTO "cmn_access" VALUES ('academico','pablo','processar','t');
INSERT INTO "cmn_access" VALUES ('academico','joao','acesso','t');
INSERT INTO "cmn_access" VALUES ('academico','joao','consultar','t');
INSERT INTO "cmn_access" VALUES ('academico','joao','inserir','t');
INSERT INTO "cmn_access" VALUES ('academico','joao','alterar','t');
INSERT INTO "cmn_access" VALUES ('academico','joao','excluir','t');
INSERT INTO "cmn_access" VALUES ('academico','joao','processar','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','ts','acesso','f');
INSERT INTO "cmn_access" VALUES ('vestibular','pablo','alterar','f');
INSERT INTO "cmn_access" VALUES ('vestibular','pablo','consultar','f');
INSERT INTO "cmn_access" VALUES ('vestibular','pablo','excluir','f');
INSERT INTO "cmn_access" VALUES ('vestibular','pablo','inserir','f');
INSERT INTO "cmn_access" VALUES ('vestibular','pablo','processar','f');
INSERT INTO "cmn_access" VALUES ('vestibular','pablo','acesso','f');
INSERT INTO "cmn_access" VALUES ('academico','ts','acesso','f');
INSERT INTO "cmn_access" VALUES ('academico','ts','alterar','t');
INSERT INTO "cmn_access" VALUES ('academico','ts','consultar','t');
INSERT INTO "cmn_access" VALUES ('academico','ts','excluir','t');
INSERT INTO "cmn_access" VALUES ('academico','ts','inserir','t');
INSERT INTO "cmn_access" VALUES ('academico','ts','processar','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','ts','alterar','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','ts','consultar','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','ts','excluir','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','ts','inserir','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','ts','processar','t');
INSERT INTO "cmn_access" VALUES ('vestibular','ts','acesso','t');
INSERT INTO "cmn_access" VALUES ('vestibular','ts','alterar','t');
INSERT INTO "cmn_access" VALUES ('vestibular','ts','consultar','t');
INSERT INTO "cmn_access" VALUES ('vestibular','ts','excluir','f');
INSERT INTO "cmn_access" VALUES ('vestibular','ts','inserir','t');
INSERT INTO "cmn_access" VALUES ('vestibular','ts','processar','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','joao','admin','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','guest','acesso','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','guest','consultar','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','pauloc','acesso','t');
INSERT INTO "cmn_access" VALUES ('gnuteca','pauloc','consultar','t');
--
-- Data for TOC Entry ID 19 (OID 35187)
--
-- Name: cmn_users Type: TABLE DATA Owner: postgres
--


INSERT INTO "cmn_users" VALUES ('ts','Thomas Spriestersbach','ts@interact2000.com.br','','','','',NULL,NULL);
INSERT INTO "cmn_users" VALUES ('joao','Jo�o Alex Fritsch','joaoalex@univates.br','','','','',NULL,NULL);
INSERT INTO "cmn_users" VALUES ('vilson','Vilson Cristiano G�rtner','vgartner@univates.br','','','','',NULL,'');
INSERT INTO "cmn_users" VALUES ('guest','Acesso P�blico',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "cmn_users" VALUES ('pablo','Pablo Dall''Oglio','pablo@univates.br',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "cmn_users" VALUES ('pauloc','Paulo Cattelan','cattelan@control.com.br','','','','',NULL,'');
--
-- TOC Entry ID 13 (OID 19414)
--
-- Name: "vestibular_pkey" Type: INDEX Owner: postgres
--

CREATE UNIQUE INDEX "vestibular_pkey" on "vestibular" using btree ( "id" "varchar_ops" );

--
-- TOC Entry ID 14 (OID 26974)
--
-- Name: "cmn_access_user_key" Type: INDEX Owner: postgres
--

CREATE UNIQUE INDEX "cmn_access_user_key" on "cmn_access" using btree ( "login" "varchar_ops", "module" "varchar_ops", "action" "varchar_ops" );

