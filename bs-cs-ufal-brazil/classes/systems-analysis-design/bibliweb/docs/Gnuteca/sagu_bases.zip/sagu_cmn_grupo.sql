--
-- Selected TOC Entries:
--
\connect - postgres
DROP TABLE "cmn_grupo";
--
-- TOC Entry ID 2 (OID 1476803)
--
-- Name: cmn_grupo Type: TABLE Owner: postgres
--

CREATE TABLE "cmn_grupo" (
	"codigodogrupo" integer,
	"descricao" character varying(40),
	"nivel" integer
);

--
-- TOC Entry ID 3 (OID 1476803)
--
-- Name: cmn_grupo Type: ACL Owner: 
--

REVOKE ALL on "cmn_grupo" from PUBLIC;
GRANT ALL on "cmn_grupo" to PUBLIC;
GRANT ALL on "cmn_grupo" to "postgres";

--
-- Data for TOC Entry ID 4 (OID 1476803)
--
-- Name: cmn_grupo Type: TABLE DATA Owner: postgres
--


INSERT INTO "cmn_grupo" VALUES (1,'Alunos',0);
INSERT INTO "cmn_grupo" VALUES (2,'Formandos',1);
INSERT INTO "cmn_grupo" VALUES (3,'Comunidade',2);
INSERT INTO "cmn_grupo" VALUES (4,'Funcion�rios',3);
INSERT INTO "cmn_grupo" VALUES (5,'Professores',4);
INSERT INTO "cmn_grupo" VALUES (6,'Operadores',5);
INSERT INTO "cmn_grupo" VALUES (7,'Adm. do Sistema',NULL);
INSERT INTO "cmn_grupo" VALUES (8,'Pos-Graduandos',1);
