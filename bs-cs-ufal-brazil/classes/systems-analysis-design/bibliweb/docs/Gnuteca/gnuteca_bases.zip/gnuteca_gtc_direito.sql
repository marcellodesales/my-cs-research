--
-- Selected TOC Entries:
--
\connect - postgres
DROP TABLE "gtc_direito";
--
-- TOC Entry ID 2 (OID 266496)
--
-- Name: gtc_direito Type: TABLE Owner: postgres
--

CREATE TABLE "gtc_direito" (
	"codigodogrupo" integer,
	"codigodaoperacao" integer,
	"codigodogenero" integer
);

--
-- TOC Entry ID 3 (OID 266496)
--
-- Name: gtc_direito Type: ACL Owner: 
--

REVOKE ALL on "gtc_direito" from PUBLIC;
GRANT ALL on "gtc_direito" to PUBLIC;
GRANT ALL on "gtc_direito" to "postgres";
GRANT ALL on "gtc_direito" to "pablo";

--
-- Data for TOC Entry ID 4 (OID 266496)
--
-- Name: gtc_direito Type: TABLE DATA Owner: postgres
--


INSERT INTO "gtc_direito" VALUES (1,2,1);
INSERT INTO "gtc_direito" VALUES (2,2,1);
INSERT INTO "gtc_direito" VALUES (3,2,1);
INSERT INTO "gtc_direito" VALUES (4,2,1);
INSERT INTO "gtc_direito" VALUES (5,2,1);
INSERT INTO "gtc_direito" VALUES (1,2,3);
INSERT INTO "gtc_direito" VALUES (2,2,3);
INSERT INTO "gtc_direito" VALUES (3,2,3);
INSERT INTO "gtc_direito" VALUES (4,2,3);
INSERT INTO "gtc_direito" VALUES (5,2,3);
INSERT INTO "gtc_direito" VALUES (1,3,1);
INSERT INTO "gtc_direito" VALUES (2,3,1);
INSERT INTO "gtc_direito" VALUES (3,3,1);
INSERT INTO "gtc_direito" VALUES (4,3,1);
INSERT INTO "gtc_direito" VALUES (5,3,1);
INSERT INTO "gtc_direito" VALUES (1,3,3);
INSERT INTO "gtc_direito" VALUES (2,3,3);
INSERT INTO "gtc_direito" VALUES (3,3,3);
INSERT INTO "gtc_direito" VALUES (4,3,3);
INSERT INTO "gtc_direito" VALUES (5,3,3);
INSERT INTO "gtc_direito" VALUES (1,4,1);
INSERT INTO "gtc_direito" VALUES (2,4,1);
INSERT INTO "gtc_direito" VALUES (3,4,1);
INSERT INTO "gtc_direito" VALUES (4,4,1);
INSERT INTO "gtc_direito" VALUES (5,4,1);
INSERT INTO "gtc_direito" VALUES (1,4,3);
INSERT INTO "gtc_direito" VALUES (2,4,3);
INSERT INTO "gtc_direito" VALUES (3,4,3);
INSERT INTO "gtc_direito" VALUES (4,4,3);
INSERT INTO "gtc_direito" VALUES (5,4,3);
