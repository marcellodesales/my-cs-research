--
-- Selected TOC Entries:
--
\connect - postgres
DROP TABLE "gtc_genero";
--
-- TOC Entry ID 2 (OID 266607)
--
-- Name: gtc_genero Type: TABLE Owner: postgres
--

CREATE TABLE "gtc_genero" (
	"codigodogenero" integer,
	"descricao" character varying(40)
);

--
-- TOC Entry ID 3 (OID 266607)
--
-- Name: gtc_genero Type: ACL Owner: 
--

REVOKE ALL on "gtc_genero" from PUBLIC;
GRANT ALL on "gtc_genero" to PUBLIC;
GRANT ALL on "gtc_genero" to "postgres";
GRANT ALL on "gtc_genero" to "pablo";

--
-- Data for TOC Entry ID 4 (OID 266607)
--
-- Name: gtc_genero Type: TABLE DATA Owner: postgres
--


INSERT INTO "gtc_genero" VALUES (1,'LIVRO');
INSERT INTO "gtc_genero" VALUES (2,'REFER�NCIA');
INSERT INTO "gtc_genero" VALUES (3,'MNC');
INSERT INTO "gtc_genero" VALUES (0,'RESERVADO PELO SISTEMA');
