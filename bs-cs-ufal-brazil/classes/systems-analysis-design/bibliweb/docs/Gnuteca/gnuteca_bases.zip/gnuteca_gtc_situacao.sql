--
-- Selected TOC Entries:
--
\connect - postgres
DROP TABLE "gtc_situacao";
--
-- TOC Entry ID 2 (OID 266559)
--
-- Name: gtc_situacao Type: TABLE Owner: postgres
--

CREATE TABLE "gtc_situacao" (
	"codigodasituacao" integer,
	"descricao" character varying(40),
	"mnemonico" character varying(20)
);

--
-- TOC Entry ID 3 (OID 266559)
--
-- Name: gtc_situacao Type: ACL Owner: 
--

REVOKE ALL on "gtc_situacao" from PUBLIC;
GRANT ALL on "gtc_situacao" to PUBLIC;
GRANT ALL on "gtc_situacao" to "postgres";
GRANT ALL on "gtc_situacao" to "pablo";

--
-- Data for TOC Entry ID 4 (OID 266559)
--
-- Name: gtc_situacao Type: TABLE DATA Owner: postgres
--


INSERT INTO "gtc_situacao" VALUES (1,'Solicitada','SOLICITADA');
INSERT INTO "gtc_situacao" VALUES (2,'Atendida','ATENDIDA');
INSERT INTO "gtc_situacao" VALUES (3,'Comunicada','COMUNICADA');
INSERT INTO "gtc_situacao" VALUES (4,'Confirmada','CONFIRMADA');
INSERT INTO "gtc_situacao" VALUES (5,'Vencida','VENCIDA');
INSERT INTO "gtc_situacao" VALUES (6,'Cancelada','CANCELADA');
