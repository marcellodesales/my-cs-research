--
-- Selected TOC Entries:
--
\connect - postgres
DROP TABLE "gtc_transicao";
--
-- TOC Entry ID 2 (OID 266595)
--
-- Name: gtc_transicao Type: TABLE Owner: postgres
--

CREATE TABLE "gtc_transicao" (
	"codigodoestadopresente" integer,
	"codigodaoperacao" integer,
	"codigodoestadofuturo" integer
);

--
-- TOC Entry ID 3 (OID 266595)
--
-- Name: gtc_transicao Type: ACL Owner: 
--

REVOKE ALL on "gtc_transicao" from PUBLIC;
GRANT ALL on "gtc_transicao" to PUBLIC;
GRANT ALL on "gtc_transicao" to "postgres";
GRANT ALL on "gtc_transicao" to "pablo";

--
-- Data for TOC Entry ID 4 (OID 266595)
--
-- Name: gtc_transicao Type: TABLE DATA Owner: postgres
--


INSERT INTO "gtc_transicao" VALUES (1,2,5);
INSERT INTO "gtc_transicao" VALUES (6,2,5);
INSERT INTO "gtc_transicao" VALUES (5,4,1);
