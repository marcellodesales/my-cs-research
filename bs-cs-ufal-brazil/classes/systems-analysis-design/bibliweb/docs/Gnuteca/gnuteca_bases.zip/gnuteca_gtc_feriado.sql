--
-- Selected TOC Entries:
--
\connect - postgres
DROP TABLE "gtc_feriado";
--
-- TOC Entry ID 2 (OID 266571)
--
-- Name: gtc_feriado Type: TABLE Owner: postgres
--

CREATE TABLE "gtc_feriado" (
	"datadoferiado" date,
	"descricao" character varying(40)
);

--
-- TOC Entry ID 3 (OID 266571)
--
-- Name: gtc_feriado Type: ACL Owner: 
--

REVOKE ALL on "gtc_feriado" from PUBLIC;
GRANT ALL on "gtc_feriado" to PUBLIC;
GRANT ALL on "gtc_feriado" to "postgres";
GRANT ALL on "gtc_feriado" to "pablo";

--
-- Data for TOC Entry ID 4 (OID 266571)
--
-- Name: gtc_feriado Type: TABLE DATA Owner: postgres
--


INSERT INTO "gtc_feriado" VALUES ('2001-01-01','Dia da Confraterniza��o Universal');
INSERT INTO "gtc_feriado" VALUES ('2001-05-01','Dia do Trabalho');
INSERT INTO "gtc_feriado" VALUES ('2001-11-02','Finados');
INSERT INTO "gtc_feriado" VALUES ('2001-11-15','Proclama��o da Rep�blica');
INSERT INTO "gtc_feriado" VALUES ('2001-12-25','Natal');
INSERT INTO "gtc_feriado" VALUES ('2001-12-31','V�spera de Ano Novo');
INSERT INTO "gtc_feriado" VALUES ('2001-10-12','Nossa Senhora Aparecida');
