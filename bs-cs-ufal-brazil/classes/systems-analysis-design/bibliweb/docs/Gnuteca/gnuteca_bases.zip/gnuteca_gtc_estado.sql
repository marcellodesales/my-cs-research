--
-- Selected TOC Entries:
--
\connect - postgres
DROP TABLE "gtc_estado";
--
-- TOC Entry ID 2 (OID 266547)
--
-- Name: gtc_estado Type: TABLE Owner: postgres
--

CREATE TABLE "gtc_estado" (
	"codigodoestado" integer,
	"descricao" character varying(40),
	"mnemonico" character varying(20)
);

--
-- TOC Entry ID 3 (OID 266547)
--
-- Name: gtc_estado Type: ACL Owner: 
--

REVOKE ALL on "gtc_estado" from PUBLIC;
GRANT ALL on "gtc_estado" to PUBLIC;
GRANT ALL on "gtc_estado" to "postgres";
GRANT ALL on "gtc_estado" to "pablo";

--
-- Data for TOC Entry ID 4 (OID 266547)
--
-- Name: gtc_estado Type: TABLE DATA Owner: postgres
--


INSERT INTO "gtc_estado" VALUES (1,'Dispon�vel','DISPONIVEL');
INSERT INTO "gtc_estado" VALUES (2,'Congelado','CONGELADO');
INSERT INTO "gtc_estado" VALUES (3,'Extraviado','EXTRAVIADO');
INSERT INTO "gtc_estado" VALUES (4,'Descartado','DESCARTADO');
INSERT INTO "gtc_estado" VALUES (5,'Emprestado','EMPRESTADO');
INSERT INTO "gtc_estado" VALUES (6,'Reservado','RESERVADO');
INSERT INTO "gtc_estado" VALUES (7,'Restaurando','RESTAURANDO');
