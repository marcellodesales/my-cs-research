--
-- Selected TOC Entries:
--
\connect - postgres
DROP TABLE "gtc_politica";
--
-- TOC Entry ID 2 (OID 266479)
--
-- Name: gtc_politica Type: TABLE Owner: postgres
--

CREATE TABLE "gtc_politica" (
	"codigodogrupo" integer,
	"codigodogenero" integer,
	"diasdeemprestimo" integer,
	"limitedeemprestimo" integer,
	"limitederenovacao" integer,
	"limitedereserva" integer,
	"valordamulta" double precision,
	"diasdereserva" integer
);

--
-- TOC Entry ID 3 (OID 266479)
--
-- Name: gtc_politica Type: ACL Owner: 
--

REVOKE ALL on "gtc_politica" from PUBLIC;
GRANT ALL on "gtc_politica" to PUBLIC;
GRANT ALL on "gtc_politica" to "postgres";
GRANT ALL on "gtc_politica" to "pablo";

--
-- Data for TOC Entry ID 4 (OID 266479)
--
-- Name: gtc_politica Type: TABLE DATA Owner: postgres
--


INSERT INTO "gtc_politica" VALUES (1,NULL,7,3,10,3,2,10);
INSERT INTO "gtc_politica" VALUES (4,NULL,6,3,10,3,2,10);
INSERT INTO "gtc_politica" VALUES (0,0,0,0,0,0,0,0);
INSERT INTO "gtc_politica" VALUES (1,3,2,3,99,3,2,2);
INSERT INTO "gtc_politica" VALUES (2,3,2,3,99,3,2,2);
INSERT INTO "gtc_politica" VALUES (3,1,3,3,1,1,0.5,1);
INSERT INTO "gtc_politica" VALUES (4,3,2,3,99,3,2,2);
INSERT INTO "gtc_politica" VALUES (5,3,2,3,99,3,2,2);
INSERT INTO "gtc_politica" VALUES (1,1,5,5,99,5,0.5,2);
INSERT INTO "gtc_politica" VALUES (2,1,10,5,99,5,0.5,2);
INSERT INTO "gtc_politica" VALUES (5,1,10,5,99,5,0.5,2);
INSERT INTO "gtc_politica" VALUES (4,1,10,5,99,5,0.5,2);
